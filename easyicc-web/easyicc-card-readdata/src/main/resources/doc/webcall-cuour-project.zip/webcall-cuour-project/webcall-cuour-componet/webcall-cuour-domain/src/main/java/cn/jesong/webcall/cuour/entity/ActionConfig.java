package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 动作配置
 * @author hanjianxin
 *
 */
@Entity
@Table(name = "js_card_action_config")
public class ActionConfig implements CompanySetting {
	/**
	 * id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_card_action_config_id_seq")
	@SequenceGenerator(name = "js_card_action_config_id_seq", sequenceName = "js_card_action_config_id_seq", allocationSize = 1)
	private int id;
	
	/**
	 * 公司id
	 */
	@Column(name = "company_id", nullable = false)
	private int companyId;
	
	/**
	 * 公司name
	 */
	@Column(name = "company_name")
	private String companyName;
	
	/**
	 * 结构体
	 */
	@Column(name = "cmd", nullable = false)
	private String cmd;
	
	/**
	 * 结构体
	 */
	@Column(name = "config", nullable = false)
	private String config;
	
	/**
	 * 结构体
	 */
	@Column(name = "tpl", nullable = false)
	private String tpl;
	
	/**
	 * 参数类型
	 */
	@Column(name = "param_type", nullable = false)
	private String paramType;
	
	/**
	 * 状态0：关闭,1：启用
	 */
	@Column(name = "status", nullable = false)
	private Integer status;
	
	/**
	 * 接口地址
	 */
	@Column(name = "interface_url", nullable = false)
	private String interfaceUrl;
	
	/**
	 * body数据类型
	 */
	@Column(name = "body_type", nullable = false)
	private String bodyType;
	
	/**
	 * 是否数据签名: 1:是，0：否
	 */
	@Column(name = "is_data_sign", nullable = false)
	private String isDataSign;
	
	/**
	 * 签名算法
	 */
	@Column(name = "sign_algorithm", nullable = false)
	private String signAlgorithm;
	
	/**
	 * 第三方平台
	 */
	@Column(name = "third_platform")
	private String thirdPlatform;
	
	/**
	 * 签名结构体
	 */
	@Column(name = "sign_body", nullable = false)
	private String signBody;
	
	/**
	 * 包含类型
	 */
	@Column(name = "contain_type")
	private String containType;
	
	/**
	 * 包含规则
	 */
	@Column(name = "contain_rule")
	private String containRule;
	
	public String getContainType() {
		return containType;
	}

	public void setContainType(String containType) {
		this.containType = containType;
	}

	public String getContainRule() {
		return containRule;
	}

	public void setContainRule(String containRule) {
		this.containRule = containRule;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public Integer getCompanyId() {
		return companyId;
	}
	
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public String getConfig() {
		return config;
	}

	public void setConfig(String config) {
		this.config = config;
	}

	public String getTpl() {
		return tpl;
	}

	public void setTpl(String tpl) {
		this.tpl = tpl;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getInterfaceUrl() {
		return interfaceUrl;
	}

	public void setInterfaceUrl(String interfaceUrl) {
		this.interfaceUrl = interfaceUrl;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}

	public String getIsDataSign() {
		return isDataSign;
	}

	public void setIsDataSign(String isDataSign) {
		this.isDataSign = isDataSign;
	}

	public String getSignAlgorithm() {
		return signAlgorithm;
	}

	public void setSignAlgorithm(String signAlgorithm) {
		this.signAlgorithm = signAlgorithm;
	}

	public String getSignBody() {
		return signBody;
	}

	public void setSignBody(String signBody) {
		this.signBody = signBody;
	}

	public String getThirdPlatform() {
		return thirdPlatform;
	}

	public void setThirdPlatform(String thirdPlatform) {
		this.thirdPlatform = thirdPlatform;
	}
	
	
}
