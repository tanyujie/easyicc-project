package cn.jesong.webcall.cuour.controller.setting;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.Scheduling;
import cn.jesong.webcall.cuour.service.setting.SchedulingService;


@Controller
@RequestMapping("/setting/scheduling")
public class SchedulingController extends SimpleController<Integer, Scheduling>{
	
	@Autowired
	private SchedulingService schedulingService;

	@Override
	protected String getPrefix() {
		return "/setting/scheduling";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, Scheduling> getHibernateService() {
		return schedulingService;
	}

	@Override
	protected void beforeCreateOrUpdate(Scheduling entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
		entity.setStartTime(entity.getStartTime()+":00");
		entity.setEndTime(entity.getEndTime()+":59");
	}

}

