package cn.jesong.webcall.cuour.controller.sale;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.service.setting.SchedulingUserService;

@Controller
@RequestMapping("/sale/scheduling")
public class PersonalSchedulingController {

	private final static String PREFIX = "/sale/scheduling";
	
	private final static SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
	
	@Autowired
	private SchedulingUserService schedulingUserService;
	
	@RequestMapping("/index")
	public String index(ModelMap model){
		return PREFIX + "/index";
	}
	
	@RequestMapping("/query")
	@ResponseBody
	public List<Map<String, Object>> query(@RequestParam(value = "startTime", required = true) String startTime) throws ParseException{
		return this.schedulingUserService.getPersonelSchedulings(OnLine.getCurrentUserDetails().getCompanyId(), 
				OnLine.getCurrentUserDetails().getUserId(), formatter2.parse(startTime));
	}
	
}
