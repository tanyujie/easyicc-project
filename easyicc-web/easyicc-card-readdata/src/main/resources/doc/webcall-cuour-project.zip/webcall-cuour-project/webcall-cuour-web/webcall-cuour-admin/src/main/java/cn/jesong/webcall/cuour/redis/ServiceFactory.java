package cn.jesong.webcall.cuour.redis;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.kinfe.util.properties.ConfigLoader;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedisPool;

public class ServiceFactory {

	private static ServiceFactory instance = new ServiceFactory();
	
	private final static Log _logger = LogFactory.getLog(ServiceFactory.class);
	
	private final static ShardedJedisPool jedisPool;
	
	static{
		Properties props = ConfigLoader.getInstance().load();
		JedisPoolConfig config = new JedisPoolConfig();
		config.setMaxActive(Integer.parseInt(props.getProperty("redis.pool.live.maxActive", "20")));
		config.setMaxIdle(Integer.parseInt(props.getProperty("redis.pool.live.maxIdle", "2")));
		
		_logger.info("redis连接池配置:maxActive="+config.getMaxActive()+"  maxIdle="+config.getMaxIdle());
		
		config.setMaxWait(Integer.parseInt(props.getProperty("redis.pool.maxWait", "1000")));
		List<JedisShardInfo> list = new ArrayList<JedisShardInfo>();
		int redisServerNum = Integer.parseInt(props.getProperty("redis.servers"));
		for(int i=0; i<redisServerNum; i++){
			String host = props.getProperty("redis.server."+i+".host");
			String port = props.getProperty("redis.server."+i+".port");
			JedisShardInfo info = new JedisShardInfo(host, port);
			String password = props.getProperty("redis.server."+i+".password", "");
			if(!password.equals("")){
				info.setPassword(password);
			}
			list.add(info);
		}
		jedisPool = new ShardedJedisPool(config, list);
	}
	
	private final static MessageCache messageCache = new MessageCache(jedisPool);
	
	private ServiceFactory(){
		
	}
	
	public static MessageCache getMessageCache(){
		return messageCache;
	}
	
	public static ServiceFactory getInstance(){
		return instance;
	}
}
