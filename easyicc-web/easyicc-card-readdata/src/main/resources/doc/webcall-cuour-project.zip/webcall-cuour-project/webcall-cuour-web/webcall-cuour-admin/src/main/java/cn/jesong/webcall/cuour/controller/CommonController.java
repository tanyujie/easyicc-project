package cn.jesong.webcall.cuour.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.entity.CardLog;
import cn.jesong.webcall.cuour.service.CardLogService;
import cn.jesong.webcall.cuour.service.ChatRecordService;
import cn.jesong.webcall.cuour.service.setting.BackTypeService;
import cn.jesong.webcall.cuour.service.setting.CardRuleService;
import cn.jesong.webcall.cuour.user.CuourUserDetail;
import cn.jesong.webcall.resource.ChatRecordDetail;

@Controller
@RequestMapping("/common")
public class CommonController {

	@Autowired
	private ChatRecordService chatRecordService;
	
	@Autowired
	private BackTypeService backTypeService;
	
	@Autowired
	private CardLogService cardLogService;
	
	@Autowired
	private CardRuleService cardRuleService;
	
	
	@RequestMapping("/card/detail")
	public String cardDetail(@RequestParam("cardId") int cardId, ModelMap model){
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		model.put("backTypes", this.backTypeService.getListByTemplate(params));
		return "/common/cardDetail";
	}
	
	@RequestMapping("/card/logs")
	@ResponseBody
	public List<CardLog> getCardLogs(@RequestParam("cardId") int cardId){
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		params.put("cardId", cardId);
		return this.cardLogService.getListByTemplate(params);
	}
	
	@RequestMapping("/chat/record")
	@ResponseBody
	public List<ChatRecordDetail> getChatRecordDetail(@RequestParam("visitorStaticId") String visitorStaticId, 
			@RequestParam("createTime") String createTime){
		List<ChatRecordDetail> list = new ArrayList<ChatRecordDetail>();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			createTime=dateFormat.format(new Date(Long.valueOf(createTime)));
			list = this.chatRecordService.getChatRecordDetail(
					OnLine.getCurrentUserDetails().getCompanyId(), visitorStaticId, createTime);
			CuourUserDetail ud = (CuourUserDetail)OnLine.getCurrentUserDetails();
			if(ud.hasDataPermission("3d5c4d88-032f-409f-bf74-1b2f429d1216", "hideTelephone", "1")){
				for(ChatRecordDetail listChat : list){
					if(listChat.getSenderType()==1){
						//listChat.getMessage().replaceAll("([A-Za-z0-9_]{3})[A-Za-z0-9_@.\\-]{1,}","$1****");
						listChat.setMessage(listChat.getMessage().replaceAll("([0-9]{3}-?)[0-9]{4}([0-9]{3,6})","$1****$2"));
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	@RequestMapping("/chat/record2")
	@ResponseBody
	public List<ChatRecordDetail> getChatRecordDetail2(@RequestParam("visitorStaticId") String visitorStaticId, 
			@RequestParam("createTime") String createTime){
		List<ChatRecordDetail> list = new ArrayList<ChatRecordDetail>();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			createTime=dateFormat.format(new Date(Long.valueOf(createTime)));
			CuourUserDetail ud = (CuourUserDetail)OnLine.getCurrentUserDetails();
			list = this.chatRecordService.getChatRecordDetail(ud.getCompanyId(), visitorStaticId, createTime);
			if(!list.isEmpty()){
				//CardRule rule = this.cardRuleService.get(ud.getCompanyId());
				//long now = new Date().getTime();
				for(ChatRecordDetail rd : list){
					if(rd.getMessage() != null){
					//if(rd.getCreateTime() == null || now - rd.getCreateTime().getTime() < rule.getMobileHideTime() * 60 * 1000){
						Pattern pattern = Pattern.compile("[1][34578][0-9]{9}");
						Matcher matcher = pattern.matcher(rd.getMessage());
						if(matcher.find()){
							String mobile = matcher.group();
							String mobile2 = mobile.substring(0, 3) + "****" + mobile.substring(7, mobile.length());
							rd.setMessage(rd.getMessage().replaceAll(mobile, mobile2));
						}
					//}
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return  list;
	}
	
	
}
