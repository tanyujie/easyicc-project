package cn.jesong.webcall.cuour.entity;

public class NotifyConfig {
	
	private String notifyOpenId;
	private String notifyUserNickName;
	private String notifyIsOpen;
	private String notifySendOpportunity;
	
	public String getNotifyOpenId() {
		return notifyOpenId;
	}
	public void setNotifyOpenId(String notifyOpenId) {
		this.notifyOpenId = notifyOpenId;
	}
	public String getNotifyUserNickName() {
		return notifyUserNickName;
	}
	public void setNotifyUserNickName(String notifyUserNickName) {
		this.notifyUserNickName = notifyUserNickName;
	}
	public String getNotifyIsOpen() {
		return notifyIsOpen;
	}
	public void setNotifyIsOpen(String notifyIsOpen) {
		this.notifyIsOpen = notifyIsOpen;
	}
	public String getNotifySendOpportunity() {
		return notifySendOpportunity;
	}
	public void setNotifySendOpportunity(String notifySendOpportunity) {
		this.notifySendOpportunity = notifySendOpportunity;
	}
	
	
}
