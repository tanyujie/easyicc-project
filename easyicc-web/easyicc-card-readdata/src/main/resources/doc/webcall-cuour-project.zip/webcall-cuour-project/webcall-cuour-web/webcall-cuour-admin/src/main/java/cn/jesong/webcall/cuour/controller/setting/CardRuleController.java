package cn.jesong.webcall.cuour.controller.setting;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.service.setting.CardRuleService;
import cn.jesong.webcall.cuour.service.setting.SchoolService;
import cn.jesong.webcall.cuour.service.setting.SubjectService;


@Controller
@RequestMapping("/setting/rule")
public class CardRuleController {
	
	private final static String PREFIX = "/setting/rule";

	@Autowired
	private CardRuleService ruleService;
	
	@Autowired
	private SchoolService schoolService;
	
	@Autowired
	private SubjectService subjectService;
	
	@RequestMapping("/index")
	public String index(ModelMap model){
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		model.put("schools", this.schoolService.getListByTemplate(params));
		model.put("subjects", this.subjectService.getListByTemplate(params));
		return PREFIX + "/index";
	}
	
	@RequestMapping("/data")
	@ResponseBody
	public CardRule loadData(){
		CardRule rule = this.ruleService.get(OnLine.getCurrentUserDetails().getCompanyId());
		if(rule == null){
			rule = new CardRule();
		}
		return rule;
	}
	
	@RequestMapping("/update")
	public void update(CardRule rule, HttpServletResponse response) throws IOException{
		rule.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
		this.ruleService.saveOrUpdate(rule);
		RespResult.getSuccess().writeToResponse(response);
	}
	
}
