package cn.jesong.webcall.cuour.service;

import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;
import java.util.List;

/**
 * 分配算法
 * @author Administrator
 *
 */
public interface AllocationSaleUserInterface {

	/**
	 * 分配销售客服
	 * @param card
	 * @param allocationUsers 可分配销售客服list
	 * @param redisService redis
	 * @return
	 */
	public SaleUser allocationSaleUser(Card card, List<SaleUser> allocationUsers);

}
