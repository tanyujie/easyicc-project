package cn.jesong.webcall.cuour.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Card;

@Service
public class CardDockingService {

	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/**
	 * 设置无效
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int setNotValidate(int companyId, String staticId) {
		int count = 0;//is_valid = 0, is_expired = 0, is_back=0,  allocation_status = ?
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set is_valid = 0, is_expired = 0, is_back=0,  allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 重新分配
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int resetAllocation(int companyId, String staticId) {
		int count = 0;
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set is_expired = 0, is_back=0,  allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 退回
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int returnAllocation(int companyId, String staticId) {
		int count = 0;
		// update js_visitor_info set allocation_status = ?, 
		// is_back = 1, is_expired = 0, back_type = ?, back_desp = ?,  
		// user_id = ?, modify_identity = ?, back_user_id = ?, back_time = ?
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			Date now = new Date();
			String sql = "update js_visitor_info set is_back=1, is_expired = 0," +
					" modify_identity = ?, back_time = ?," +
					" allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			//int count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, backType, desp, 
			//"", UUID.randomUUID().toString(), c.getUserId(), now, cardId, c.getModifyIdentity());
			count = this.jdbcTemplate.update(sql, UUID.randomUUID().toString(), now,
					Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 超期回收
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int expiredAllocation(int companyId, String staticId) {
		int count = 0;
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set is_expired=1, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 等待分配
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int waitAllocation(int companyId, String staticId) {
		int count = 0;
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set is_expired=0, is_back = 0,back_user_id=null, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 已处理
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int finishedAllocation(int companyId, String staticId) {
		int count = 0;
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set is_valid=1, back_user_id=null, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 重复线索
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int repeatAllocation(int companyId, String staticId) {
		int count = 0;
		if (companyId > 0 && staticId != null && !"".equals(staticId)) {
			String sql = "update js_visitor_info set allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			count = this.jdbcTemplate.update(sql, Card.STATUS_REPEAT, staticId, companyId);
		}
		return count;
	}
	
	//未处理
	//hql.append("and (a.allocation_status = ? or a.allocation_status = ? ) and a.back_user_id is null");
//	params.add(Card.STATUS_SYSTEM_ALLOCATIONED);
	//params.add(Card.STATUS_USE_ALLOCATIONED);
	
	//再分配未处理
	//hql.append("and a.allocation_status = ? and  a.back_user_id is not null");
	//params.add(Card.STATUS_USE_ALLOCATIONED);
	
	//再分配已处理
	//hql.append("and a.allocation_status = ? and a.is_valid = 1 and a.back_user_id is not null");
	//params.add(Card.STATUS_FINISHED);
	
	//hql.append(" and a.allocation_status = ? ");
	//params.add(Card.STATUS_REPEAT);
	
	/**
	 * 设置无效-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int setNotValidateBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_FINISHED, staticId, companyId});
			}
			String sql = "update js_visitor_info set is_valid = 0, is_expired = 0, is_back=0,  allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
			//count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 重新分配-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int resetAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId});
			}
			String sql = "update js_visitor_info set is_expired = 0, is_back=0,  allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
		}
		return count;
	}
	
	/**
	 * 退回-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int returnAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			Date now = new Date();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_WAIT_USE_ALLOCATION, now,UUID.randomUUID().toString(), staticId, companyId});
			}
			String sql = "update js_visitor_info set is_back=1,is_expired = 0, allocation_status = ?,back_time = ?,modify_identity = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
			
			
//			String sql = "update js_visitor_info set is_back=1, is_expired = 0," +
//					" modify_identity = ?, back_time = ?," +
//					" allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			//int count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, backType, desp, 
			//"", UUID.randomUUID().toString(), c.getUserId(), now, cardId, c.getModifyIdentity());
//			count = this.jdbcTemplate.update(sql, UUID.randomUUID().toString(), now,
//					Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
		}
		return count;
	}
	
	/**
	 * 超期回收-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int expiredAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId});
			}
			String sql = "update js_visitor_info set is_expired=1,is_back = 0, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
		//	count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
		}
		return count;
	}
	
	/**
	 * 等待分配-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int waitAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId});
			}
			String sql = "update js_visitor_info set is_expired=0, is_back = 0,back_user_id=null, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
		//	count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, staticId, companyId);
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
		}
		return count;
	}
	
	/**
	 * 已处理-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int finishedAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_FINISHED, staticId, companyId});
			}
			String sql = "update js_visitor_info set is_valid=1, back_user_id=null, allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			//count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, staticId, companyId);
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
		}
		return count;
	}
	
	/**
	 * 重复线索-批量
	 * 
	 * @param companyId
	 * @param staticId
	 * @return
	 */
	public int repeatAllocationBatch(int companyId, List<String> staticIds) {
		int count = 0;
		if (companyId > 0 && staticIds != null && staticIds.size() > 0) {
			List<Object[]> batchArgs = new ArrayList<Object[]>();
			for(String staticId : staticIds) {
				batchArgs.add(new Object[]{Card.STATUS_REPEAT, staticId, companyId});
			}
			String sql = "update js_visitor_info set allocation_status = ? where VISITOR_STATIC_ID = ? and company_id = ?";
			//count = this.jdbcTemplate.update(sql, Card.STATUS_REPEAT, staticId, companyId);
			int[] args = this.jdbcTemplate.batchUpdate(sql, batchArgs);
			count = args.length;
		}
		return count;
	}
	
}
