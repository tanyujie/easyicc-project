package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.resource.ChatRecordDetail;

@Service
public class ChatRecordService {

	@Resource(name="jdbcTemplateX")
	private JdbcTemplate jdbcTempalteX;
	
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTempalte;
	
	public List<ChatRecordDetail> getChatRecordDetail(int companyId, String visitorStaticId, String createTime) throws Exception {
		
		//String table = DateUtil.stampToDate(createTime);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		/*long lt = new Long(createTime);
        Date date = new Date(lt);*/
        Date date = dateFormat.parse(createTime);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		String endTime=dateFormat.format(calendar.getTime());
		calendar.add(calendar.MONTH, -1);
		String startTime=dateFormat.format(calendar.getTime());
		String TableDate[]= getDate(startTime,endTime);
		List<String> tableNames=new ArrayList<String>();
		tableNames.add("JS_CHAT_RECORD_DETAIL");
		tableNames.add("JS_CHAT_RECORD");
		Map<String,Object> paraMap=jointTableName(tableNames,String.valueOf(companyId),TableDate[1]);
		String table1=paraMap.get("Table1").toString();
		String table2=paraMap.get("Table2").toString();
			
		
		String sql = "select a.* from  " +table1 + "  a where exists( "+
				 "	select 1 from  " +table2 + " b where b.company_id =? "+
				 "	and  a.chat_id = b.chat_id and b.visitor_static_id = ? "+
				 "	) order by create_time asc";
		
		return this.jdbcTempalteX.query(sql, new Object[]{companyId, visitorStaticId}, new RowMapper<ChatRecordDetail>(){

			@Override
			public ChatRecordDetail mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				ChatRecordDetail r = new ChatRecordDetail();
				r.setRecorderId(rs.getInt("recorder_id"));
				r.setCreateTime(new Date(rs.getTimestamp("create_time").getTime()));
				r.setChatId(rs.getInt("chat_id"));
				r.setMessage(rs.getString("message"));
				r.setType(rs.getString("type"));
				r.setSenderType(rs.getInt("sender_type"));
				r.setFromId(rs.getString("from_id"));
				return r;
			}
		});
	}
	
	public List<ChatRecordDetail> getChatRecordDetail(int companyId, Integer chatId, Date createTime) throws Exception {
		
		//String table = DateUtil.stampToDate(createTime);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(createTime);
		String endTime=dateFormat.format(calendar.getTime());
		calendar.add(calendar.MONTH, -1);
		String startTime=dateFormat.format(calendar.getTime());
		String TableDate[]= getDate(startTime,endTime);
		List<String> tableNames=new ArrayList<String>();
		tableNames.add("JS_CHAT_RECORD_DETAIL");
		Map<String,Object> paraMap=jointTableName(tableNames,String.valueOf(companyId),TableDate[1]);
		String table1=paraMap.get("Table1").toString();
		
		
		String sql = "select a.* from " +table1 + " a where a.company_id =? "+
				 "	 and  a.chat_id =  ? "+
				 "	 order by create_time asc";
		
		return this.jdbcTempalteX.query(sql, new Object[]{companyId, chatId}, new RowMapper<ChatRecordDetail>(){

			@Override
			public ChatRecordDetail mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				ChatRecordDetail r = new ChatRecordDetail();
				r.setRecorderId(rs.getInt("recorder_id"));
				r.setCreateTime(new Date(rs.getTimestamp("create_time").getTime()));
				r.setChatId(rs.getInt("chat_id"));
				r.setMessage(rs.getString("message"));
				r.setType(rs.getString("type"));
				r.setSenderType(rs.getInt("sender_type"));
				r.setFromId(rs.getString("from_id"));
				return r;
			}
		});
	}
	
	
	/*构建表名*/
	
	public String[] getDate (String startTime,String endTime) throws ParseException
	{

		String[] result = new String[2];

		String[] splitx = startTime.substring(0,7).split("-");
		String[] splity = endTime.substring(0,7).split("-");

		boolean x = !splitx[1].contains("0") && Integer.valueOf(splitx[1]) <= 9;
		boolean y = !splity[1].contains("0") && Integer.valueOf(splity[1]) <= 9;

		if (x && y)
		{
			result[0] = splitx[0] + 0 + splitx[1];
			result[1] = splity[0] + 0 + splity[1];
		}
		else
			if (x)
			{
				result[0] = splitx[0] + 0 + splitx[1];
				result[1] = splity[0] + splity[1];
			}
			else
				if (y)
				{
					result[0] = splitx[0] + splitx[1];
					result[1] = splity[0] + 0 + splity[1];
				}
				else
				{
					result[0] = splitx[0] + splitx[1];
					result[1] = splity[0] + splity[1];
				}

		return result;
	}
	
	/**
	 * 构建表名
	 */
	public Map<String,Object> jointTableName (List<String> tableNames,String companyId,String TableDate)
	{
		Map<String,Object> paramMap=new HashedMap<String, Object>();
		Integer tableIndex=0;
		for (int i = 0;i < tableNames.size();i++)
		{
			StringBuffer sb = new StringBuffer();
			sb.append(tableNames.get(i));
			sb.append("_");
			sb.append(TableDate);
			StringBuffer sbc = new StringBuffer();
			sbc.append("C_");
			sbc.append(companyId);
			sb.append(" partition(\"C_");
			sb.append(companyId);
			sb.append("\")");
			paramMap.put("Table" + (++tableIndex),sb.toString());
			
		}

		return paramMap;
	}
}
