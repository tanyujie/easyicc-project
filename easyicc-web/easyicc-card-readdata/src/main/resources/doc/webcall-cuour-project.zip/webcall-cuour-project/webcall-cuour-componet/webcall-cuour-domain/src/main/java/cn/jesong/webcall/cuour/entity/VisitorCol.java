package cn.jesong.webcall.cuour.entity;

import java.io.Serializable;

public class VisitorCol implements Serializable {
    private static final long serialVersionUID = 1L;
    private String colName;
    private String text;
    private int type;

    public VisitorCol() {
    }

    public String getColName() {
        return this.colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getType() {
        return this.type;
    }

}
