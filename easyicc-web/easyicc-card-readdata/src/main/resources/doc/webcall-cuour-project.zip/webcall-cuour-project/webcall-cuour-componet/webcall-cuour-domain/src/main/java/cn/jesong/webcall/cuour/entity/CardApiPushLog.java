package cn.jesong.webcall.cuour.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "js_card_api_push_log")
public class CardApiPushLog {
	
	@Id
	@GenericGenerator(name = "card_id", strategy = "assigned")
	@GeneratedValue(generator = "card_id")
	@Column(name = "card_id")
	private Integer cardId;
	
	@Column(name = "chat_id")
	private Integer chatId;
	
	@Column(name = "push_count")
	private int pushCount;
	
	@Column(name = "status")
	private Integer status;
	
	@Column(name = "response_str")
	private String responseStr;
	
	@Column(name = "first_error_time")
	private Date firstErrorTime;
	
	@Column(name = "last_error_time")
	private Date lastErrorTime;
	
	@Column(name = "push_time")
	private Date pushTime;
	
	@Column(name = "company_id")
	private Integer companyId;
	
	@Column(name = "visitor_static_id")
	private String visitorStaticId;

	public Integer getCardId() {
		return cardId;
	}

	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}

	public Integer getChatId() {
		return chatId;
	}

	public void setChatId(Integer chatId) {
		this.chatId = chatId;
	}

	public int getPushCount() {
		return pushCount;
	}

	public void setPushCount(int pushCount) {
		this.pushCount = pushCount;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getResponseStr() {
		return responseStr;
	}

	public void setResponseStr(String responseStr) {
		this.responseStr = responseStr;
	}

	public Date getFirstErrorTime() {
		return firstErrorTime;
	}

	public void setFirstErrorTime(Date firstErrorTime) {
		this.firstErrorTime = firstErrorTime;
	}

	public Date getLastErrorTime() {
		return lastErrorTime;
	}

	public void setLastErrorTime(Date lastErrorTime) {
		this.lastErrorTime = lastErrorTime;
	}

	public Date getPushTime() {
		return pushTime;
	}

	public void setPushTime(Date pushTime) {
		this.pushTime = pushTime;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getVisitorStaticId() {
		return visitorStaticId;
	}

	public void setVisitorStaticId(String visitorStaticId) {
		this.visitorStaticId = visitorStaticId;
	}
	

}
