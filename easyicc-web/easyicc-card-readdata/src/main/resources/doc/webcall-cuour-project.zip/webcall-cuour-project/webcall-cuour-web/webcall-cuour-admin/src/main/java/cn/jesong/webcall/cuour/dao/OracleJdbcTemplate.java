package cn.jesong.webcall.cuour.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import cn.eutils.web.platform.ui.Page;


public class OracleJdbcTemplate extends JdbcTemplate{

	public <T> Page<T> pageQuery(String sql, final Object params[], int pageNo, int pageSize, RowMapper<T> rowMapper){
		Page<T> page = new Page<T>();
		String countsql = "select count(*) as total from("+sql+")";
		int total = this.queryForObject(countsql, params, Integer.class);
		page.setTotal(total);
		long temp=1;
		long to=pageNo*pageSize;
		temp=(pageNo-1)*pageSize;
		if(pageNo>1){
			temp++;
		}
		if(total > 0){
			String querySql = "select v1.* from (select v.*,rownum as r from ("+sql+") v ) v1 where v1.r between "+temp+" and " + to;
			List<T> list = this.query(querySql, params, rowMapper);
			page.setRows(list);
		}else{
			page.setRows(new ArrayList<T>());
		}
		return page;
	}
	
}
