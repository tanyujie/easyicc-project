package cn.jesong.webcall.cuour.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;

public class ExportUtil {

	public static void export(List<Map> lists, String title,
			String[] keys, String[] heads, OutputStream os) throws IOException{
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet();
		createTitle(wb, sheet, title, heads.length);
		createHeader(wb, sheet, heads);
		createData(wb, sheet, lists, keys);
		wb.write(os);
		
	}    
	
	public static void export(List<Map> lists, String title,
			String[] keys, String[] heads, FileOutputStream os ) throws IOException{
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet();
		createTitle(wb, sheet, title, heads.length);
		createHeader(wb, sheet, heads);
		createData(wb, sheet, lists, keys);
		wb.write(os);
		
	}    
	
	
	private static void createData(HSSFWorkbook wb, HSSFSheet sheet, List<Map> list, String[] keys){
		for(int i = 0; i < list.size(); i++){
			Map<String, String> obj = list.get(i);
			HSSFRow row = sheet.createRow((short)(i+2));
			for(int j=0; j<keys.length; j++){
				String key = keys[j].replace("%", "");
				String value =  obj.get(key) == null ? "" : String.valueOf(obj.get(key));
				if(keys[j].indexOf("%") != -1 && value.length() > 0) value += "%";
				createData(wb, sheet, row, j,value);
			}
		}
	}
	
	private static void createData(HSSFWorkbook wb, HSSFSheet sheet, HSSFRow row, int index, String value){
		HSSFCell cell = row.createCell(index);
		
		setCellValue(cell, value);
		//cell.setCellStyle(createDataStyle(wb));
	}
	
	private static void setCellValue(HSSFCell cell, String value) {
		//cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(new HSSFRichTextString(value));
	}
	/**
	 * 创建表头
	 * @param sheet
	 * @param form
	 */
	private static void createHeader(HSSFWorkbook wb, HSSFSheet sheet, String[] heads){
		HSSFRow row = sheet.createRow(1);
		for(int i = 0; i < heads.length; i++){
			createHeader(wb, sheet, row, (short)(i), heads[i]);
		}
	}
	private static void createHeader(HSSFWorkbook wb, HSSFSheet sheet, HSSFRow row, int index, String headName){
		int headLength = length(headName);
		sheet.setColumnWidth(index, 256 * headLength + 1000);
		HSSFCell cell = row.createCell(index);
		setCellValue(cell, headName);
		//cell.setCellStyle(createTitleStyle(wb)); 
	}
	private static int length(String value) {
        int valueLength = 0;
        String chinese = "[\u0391-\uFFE5]";
        for (int i = 0; i < value.length(); i++) {
            String temp = value.substring(i, i + 1);
            if (temp.matches(chinese)) {
                valueLength += 2;
            } else {
                valueLength += 1;
            }
        }
        return valueLength;
    }
	   
	/**
	 * 创建标题
	 * @param sheet
	 * @param title
	 * @param cols
	 */
	private static void createTitle(HSSFWorkbook wb, HSSFSheet sheet, String title, int cols){
		HSSFRow headRow = sheet.createRow(0);
		HSSFCell cell = headRow.createCell(0); 
		headRow.setHeight((short)400); 
		// 定义单元格为字符串类型 
		setCellValue(cell, title);
		// 指定合并区域 
		sheet.addMergedRegion(new CellRangeAddress(
	            0, //first row (0-based)
	            0, //last row  (0-based)
	            0, //first column (0-based)
	            cols-1  //last column  (0-based)
	    ));
		cell.setCellStyle(createHeaderStyle(wb)); 
	}
	/**
	 * 创建数据样式
	 * @return
	 */
	private static HSSFCellStyle createDataStyle(HSSFWorkbook wb){
		HSSFCellStyle cellStyle = wb.createCellStyle(); 
		cellStyle.setAlignment(CellStyle.ALIGN_LEFT); // 指定单元格居中对齐 
		cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);// 指定单元格垂直居中对齐 
		cellStyle.setWrapText(true);// 指定单元格自动换行 
		HSSFFont font = wb.createFont(); 
		font.setBoldweight(Font.BOLDWEIGHT_NORMAL); 
		font.setFontName("宋体"); 
		font.setFontHeight((short) 200); 
		cellStyle.setFont(font); 
		return cellStyle;
	}
	/**
	 * 创建表头样式
	 * @return
	 */
	private static HSSFCellStyle createTitleStyle(HSSFWorkbook wb){
		HSSFCellStyle cellStyle = wb.createCellStyle(); 
		cellStyle.setAlignment(CellStyle.ALIGN_CENTER); // 指定单元格居中对齐 
		cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);// 指定单元格垂直居中对齐 
		cellStyle.setWrapText(true);// 指定单元格自动换行 
		HSSFFont font = wb.createFont(); 
		font.setBoldweight(Font.BOLDWEIGHT_BOLD); 
		font.setFontName("宋体"); 
		font.setFontHeight((short) 250); 
		cellStyle.setFont(font); 
		return cellStyle;
	}
	/**
	 * 创建标题样式
	 * @return
	 */
	private static HSSFCellStyle createHeaderStyle(HSSFWorkbook wb){
		HSSFCellStyle cellStyle = wb.createCellStyle(); 
		cellStyle.setAlignment(CellStyle.ALIGN_CENTER); // 指定单元格居中对齐 
		cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);// 指定单元格垂直居中对齐 
		cellStyle.setWrapText(true);// 指定单元格自动换行 
		// 设置单元格字体 
		HSSFFont font = wb.createFont(); 
		font.setBoldweight(Font.BOLDWEIGHT_BOLD); 
		//font.setFontName("黑体"); 
		//font.setFontHeight((short) 300); 
		cellStyle.setFont(font); 
		return cellStyle;
	}
	/**
	 * 模板导出
	 */
	public static String createListExcel(List<Map> data, InputStream tempIs, String filePath,int configRowIndex,int configColIndex) throws IOException {
		String fileId = String.valueOf(new Date().getTime());
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(filePath+File.separator+fileId+".xls");
			//读取模板 打开HSSFWorkbook
			POIFSFileSystem fs = new POIFSFileSystem(tempIs);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);
			//取得配置信息行
			HSSFRow row = sheet.getRow(configRowIndex);
			Map<String, Cell> config = getConfig(row,configColIndex);
			for (int i = 0; i < data.size(); i++) {
				HSSFRow hr = sheet.getRow(configRowIndex + i) == null ? sheet.createRow(configRowIndex + i) : sheet.getRow(configRowIndex + i);
				Map map = data.get(i);
				for (Object key : map.keySet()) {
					if(config.get("${" + key.toString().toLowerCase() + "}") == null) continue;
					Cell configCell = config.get("${" + key.toString().toLowerCase() + "}");
					HSSFCell hc = hr.createCell(configCell.getColumnIndex());
					hc.setCellStyle(configCell.getCellStyle());
					setCellValueTemplate(hc, String.valueOf(map.get(key)));
				}
			}
			
			for(String key : config.keySet()){
				if(key.indexOf("$") != - 1) {
					Cell configCell = config.get(key);
					configCell.setCellType(Cell.CELL_TYPE_STRING);
					configCell.setCellValue("");
				}
			}
			
			wb.write(os);
			if(tempIs != null) tempIs.close();
			if(os != null) os.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(tempIs != null) tempIs.close();
			if(os != null) os.close();
		}
		return fileId;

	}
	
	/**
	 * 模板导出
	 */
	public static String createListExcelZip(List<Map> data, InputStream tempIs, String filePath,int configRowIndex,int configColIndex) throws IOException {
		String fileId = String.valueOf(new Date().getTime());
		ZipOutputStream zip  = null;
		try {
			FileOutputStream os = new FileOutputStream(filePath+File.separator+fileId+".zip");
			//读取模板 打开HSSFWorkbook
			POIFSFileSystem fs = new POIFSFileSystem(tempIs);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);
			//取得配置信息行
			HSSFRow row = sheet.getRow(configRowIndex);
			Map<String, Cell> config = getConfig(row,configColIndex);
			for (int i = 0; i < data.size(); i++) {
				HSSFRow hr = sheet.getRow(configRowIndex + i) == null ? sheet.createRow(configRowIndex + i) : sheet.getRow(configRowIndex + i);
				Map map = data.get(i);
				for (Object key : map.keySet()) {
					if(config.get("${" + key.toString().toLowerCase() + "}") == null) continue;
					Cell configCell = config.get("${" + key.toString().toLowerCase() + "}");
					HSSFCell hc = hr.createCell(configCell.getColumnIndex());
					hc.setCellStyle(configCell.getCellStyle());
					setCellValueTemplate(hc, String.valueOf(map.get(key)));
				}
			}
			
			for(String key : config.keySet()){
				if(key.indexOf("$") != - 1) {
					Cell configCell = config.get(key);
					configCell.setCellType(Cell.CELL_TYPE_STRING);
					configCell.setCellValue("");
				}
			}
			zip = new ZipOutputStream(os);
			ZipEntry entry = new ZipEntry(fileId+".xls");
			zip.putNextEntry(entry);
			wb.write(zip);
			zip.flush();
			if(tempIs != null) tempIs.close();
			if(zip != null) zip.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(tempIs != null) tempIs.close();
			if(zip != null) zip.close();
		}
		return fileId;

	}
	
	
	

	private static Map<String, Cell> getConfig(HSSFRow row, int configColIndex) {
		Map<String, Cell> config = new HashMap<String, Cell>();
		for (int i = configColIndex; i < row.getLastCellNum(); i++) {
			HSSFCell cell = row.getCell(i);
			if(cell == null) break;
			config.put(cell.getStringCellValue().toLowerCase(), cell);
		}
		return config;
	}

	public static void setCellValueTemplate(HSSFCell cell, String value) {
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(new HSSFRichTextString(value));
	}
	
}
