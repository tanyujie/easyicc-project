package cn.jesong.webcall.cuour.service;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.Card;

/**
 * 名片扩展接口
 * @author hanjianxin
 *
 */
@Service
public interface CardExtendService {
	
	public void action(ActionConfig ac, Card card);
	
	public ActionConfig getActionConfig(int companyId) throws Exception;
	
}
