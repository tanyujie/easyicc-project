package cn.jesong.webcall.cuour.controller.setting;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.Subject;
import cn.jesong.webcall.cuour.service.setting.SubjectService;


@Controller
@RequestMapping("/setting/subject")
public class SubjectController extends SimpleController<Integer, Subject>{
	
	@Autowired
	private SubjectService subjectService;

	@Override
	protected String getPrefix() {
		return "setting/subject";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, Subject> getHibernateService() {
		return subjectService;
	}
	
	@Override
	protected void beforeCreateOrUpdate(Subject entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
	}

	/*
	 * 
	 * 手动绑定项目
     */
	@RequestMapping(value="/blinding", method=RequestMethod.POST)
	public RespResult blinding(HttpServletResponse response) throws IOException{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId(); 
		try{
			subjectService.blinding(companyId);
			return RespResult.getSuccess();
		}catch(Exception e){
			return RespResult.getError(e);
		}
	}
}
