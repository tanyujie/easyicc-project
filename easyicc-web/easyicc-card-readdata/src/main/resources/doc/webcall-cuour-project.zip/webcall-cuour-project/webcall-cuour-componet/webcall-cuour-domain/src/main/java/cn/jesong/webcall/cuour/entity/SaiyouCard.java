package cn.jesong.webcall.cuour.entity;

import java.io.Serializable;

public class SaiyouCard implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String staticId;
	private String crm_name; //	名片所属者(咨询师姓名)
	private String crmzdy_80974413;	//	String	性别
	private String crmzdy_80974415; // 手机号
	private String crmzdy_80974418; //	String	QQ
	private String crmzdy_88070094; //	String	微信
	private String crmzdy_80974439; //	Datetime 回电时间
	private String crmzdy_80979020; //	String	备注
	private String crmzdy_80974422; //	String	学历
	private String crmzdy_80974432; //	String	层级
	private String crmzdy_88232360; //	String	业务组
	private String crmzdy_88232371; //	String	搜索词
	private String crmzdy_88167326; //	String	意向校区
	private String crmzdy_81253707; //	String	项目
	private String crmzdy_80974437; //	String	学员意向班型
	private String crmzdy_88232284; //	String	名片创建者
	private String crmzdy_88232342; //	Datetime	名片创建时间
	private String crm_holder;      //	String	名片所属者
	private String crmzdy_88232295; //	Datetime	名片分配时间
	private String crmzdy_80979018; //	String	处理状态
	private String crmzdy_88232306; //	String	优先级 对应 EXTCOLUMN1字段
	private String crmzdy_88232317; //	String	详细对话内容
	
	public String getCrm_name() {
		return crm_name;
	}
	public void setCrm_name(String crm_name) {
		this.crm_name = crm_name;
	}
	public String getCrmzdy_80974413() {
		return crmzdy_80974413;
	}
	public void setCrmzdy_80974413(String crmzdy_80974413) {
		this.crmzdy_80974413 = crmzdy_80974413;
	}
	public String getCrmzdy_80974415() {
		return crmzdy_80974415;
	}
	public void setCrmzdy_80974415(String crmzdy_80974415) {
		this.crmzdy_80974415 = crmzdy_80974415;
	}
	public String getCrmzdy_80974418() {
		return crmzdy_80974418;
	}
	public void setCrmzdy_80974418(String crmzdy_80974418) {
		this.crmzdy_80974418 = crmzdy_80974418;
	}
	public String getCrmzdy_88070094() {
		return crmzdy_88070094;
	}
	public void setCrmzdy_88070094(String crmzdy_88070094) {
		this.crmzdy_88070094 = crmzdy_88070094;
	}
	public String getCrmzdy_80974439() {
		return crmzdy_80974439;
	}
	public void setCrmzdy_80974439(String crmzdy_80974439) {
		this.crmzdy_80974439 = crmzdy_80974439;
	}
	public String getCrmzdy_80979020() {
		return crmzdy_80979020;
	}
	public void setCrmzdy_80979020(String crmzdy_80979020) {
		this.crmzdy_80979020 = crmzdy_80979020;
	}
	public String getCrmzdy_80974422() {
		return crmzdy_80974422;
	}
	public void setCrmzdy_80974422(String crmzdy_80974422) {
		this.crmzdy_80974422 = crmzdy_80974422;
	}
	public String getCrmzdy_80974432() {
		return crmzdy_80974432;
	}
	public void setCrmzdy_80974432(String crmzdy_80974432) {
		this.crmzdy_80974432 = crmzdy_80974432;
	}
	public String getCrmzdy_88232360() {
		return crmzdy_88232360;
	}
	public void setCrmzdy_88232360(String crmzdy_88232360) {
		this.crmzdy_88232360 = crmzdy_88232360;
	}
	public String getCrmzdy_88232371() {
		return crmzdy_88232371;
	}
	public void setCrmzdy_88232371(String crmzdy_88232371) {
		this.crmzdy_88232371 = crmzdy_88232371;
	}
	public String getCrmzdy_88167326() {
		return crmzdy_88167326;
	}
	public void setCrmzdy_88167326(String crmzdy_88167326) {
		this.crmzdy_88167326 = crmzdy_88167326;
	}
	public String getCrmzdy_81253707() {
		return crmzdy_81253707;
	}
	public void setCrmzdy_81253707(String crmzdy_81253707) {
		this.crmzdy_81253707 = crmzdy_81253707;
	}
	public String getCrmzdy_80974437() {
		return crmzdy_80974437;
	}
	public void setCrmzdy_80974437(String crmzdy_80974437) {
		this.crmzdy_80974437 = crmzdy_80974437;
	}
	public String getCrmzdy_88232284() {
		return crmzdy_88232284;
	}
	public void setCrmzdy_88232284(String crmzdy_88232284) {
		this.crmzdy_88232284 = crmzdy_88232284;
	}
	public String getCrmzdy_88232342() {
		return crmzdy_88232342;
	}
	public void setCrmzdy_88232342(String crmzdy_88232342) {
		this.crmzdy_88232342 = crmzdy_88232342;
	}
	public String getCrm_holder() {
		return crm_holder;
	}
	public void setCrm_holder(String crm_holder) {
		this.crm_holder = crm_holder;
	}
	public String getCrmzdy_88232295() {
		return crmzdy_88232295;
	}
	public void setCrmzdy_88232295(String crmzdy_88232295) {
		this.crmzdy_88232295 = crmzdy_88232295;
	}
	public String getCrmzdy_80979018() {
		return crmzdy_80979018;
	}
	public void setCrmzdy_80979018(String crmzdy_80979018) {
		this.crmzdy_80979018 = crmzdy_80979018;
	}
	public String getCrmzdy_88232306() {
		return crmzdy_88232306;
	}
	public void setCrmzdy_88232306(String crmzdy_88232306) {
		this.crmzdy_88232306 = crmzdy_88232306;
	}
	public String getCrmzdy_88232317() {
		return crmzdy_88232317;
	}
	public void setCrmzdy_88232317(String crmzdy_88232317) {
		this.crmzdy_88232317 = crmzdy_88232317;
	}
	public String getStaticId() {
		return staticId;
	}
	public void setStaticId(String staticId) {
		this.staticId = staticId;
	}
	
	
}
