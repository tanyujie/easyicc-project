package cn.jesong.webcall.cuour.secret;

public abstract class SecretFactory {

	private static SecretFactory md5Factory = new LocalMd5Factory();

	private static SecretFactory ecFactory = new LocalECFactory();

	private static SecretFactory tqFactory = new LocalTQFactory();

	public static SecretFactory getInstance(String type) {

		System.out.println("SecretFactory.getInstance(" + type + ")");
		if ("saiyoucrm".toLowerCase().equals(type)) {
			return md5Factory;
		} else if ("EC".toLowerCase().equals(type)) {
			return ecFactory;
		} else if ("TQ".toLowerCase().equals(type)) {
			return tqFactory;
		}
		return null;
	}

	public abstract CardAuxiliaryInterface getGenerator();

}
