package cn.jesong.webcall.cuour.entity;

import cn.jesong.webcall.resource.VisitorInfo;

import java.util.Date;

public class CuourCard extends VisitorInfo{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String backDesp;
    
    //回电说明
    private String finishDesp;
    
    private int isValid = 1;
    
    private int isBack = 0;
    
    private int isExpired = 0;
    
    //退回类型
    private int backType = 0;
    
    private int allocationStatus = 0;
    
    private String modifyIdentity = "0";
    
    private Date allocationTime;
    
    private String backUserId;
    
    private Date backTime;
    
    
    
	public Date getAllocationTime() {
		return allocationTime;
	}

	public void setAllocationTime(Date allocationTime) {
		this.allocationTime = allocationTime;
	}

	public String getBackUserId() {
		return backUserId;
	}

	public void setBackUserId(String backUserId) {
		this.backUserId = backUserId;
	}

	public Date getBackTime() {
		return backTime;
	}

	public void setBackTime(Date backTime) {
		this.backTime = backTime;
	}

	public String getBackDesp() {
		return backDesp;
	}

	public void setBackDesp(String backDesp) {
		this.backDesp = backDesp;
	}

	public String getFinishDesp() {
		return finishDesp;
	}

	public void setFinishDesp(String finishDesp) {
		this.finishDesp = finishDesp;
	}

	public int getIsValid() {
		return isValid;
	}

	public void setIsValid(int isValid) {
		this.isValid = isValid;
	}

	public int getIsBack() {
		return isBack;
	}

	public void setIsBack(int isBack) {
		this.isBack = isBack;
	}

	public int getAllocationStatus() {
		return allocationStatus;
	}

	public void setAllocationStatus(int allocationStatus) {
		this.allocationStatus = allocationStatus;
	}

	public String getModifyIdentity() {
		return modifyIdentity;
	}

	public void setModifyIdentity(String modifyIdentity) {
		this.modifyIdentity = modifyIdentity;
	}

	public int getBackType() {
		return backType;
	}

	public void setBackType(int backType) {
		this.backType = backType;
	}

	public int getIsExpired() {
		return isExpired;
	}

	public void setIsExpired(int isExpired) {
		this.isExpired = isExpired;
	}
    
    
	
}
