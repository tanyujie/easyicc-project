package cn.jesong.webcall.cuour.event;

import org.springframework.context.ApplicationEvent;


/**
 * 配置改变事件
 * @author xieyulin
 *
 */
public class SettingChangeEvent extends ApplicationEvent{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int companyId;

	public SettingChangeEvent(int companyId) {
		super(companyId);
		this.companyId = companyId;
	}

	public int getCompanyId(){
		return this.companyId;
	}
	
}
