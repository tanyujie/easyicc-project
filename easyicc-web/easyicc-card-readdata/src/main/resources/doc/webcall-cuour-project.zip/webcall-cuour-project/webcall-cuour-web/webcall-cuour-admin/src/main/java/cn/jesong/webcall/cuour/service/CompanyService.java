package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Company;
/**
 * 公司service
 * @author hanjianxin
 *
 */
@Service
public class CompanyService {
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * 获取动作配置
	 * @param companyId
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List<Company> getCompanys() throws Exception {
		String sql = " SELECT * FROM JS_COMPANY ORDER BY COMPANY_ID ASC ";
		List<Company> list = this.jdbcTemplate.query(sql, new Object[]{}, new CompanyRowMapper());
		
		return list;
	}
	
	/**
	 * 获取动作配置
	 * @param companyId
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public String getCompanyName(int companyId) throws Exception {
		String sql = " SELECT * FROM JS_COMPANY WHERE COMPANY_ID=? ";
		String cname = "";
		List<Company> list = this.jdbcTemplate.query(sql, new Object[]{companyId}, new CompanyRowMapper());
		if(list != null && list.size() > 0) {
			Company c = list.get(0);
			cname = c.getCompanyName();
		}
		return cname;
	}
	
	class CompanyRowMapper implements RowMapper<Company>{
		@Override
		public Company mapRow(ResultSet rs, int rowNum) throws SQLException {
			Company bean = new Company();
			bean.setCompanyId(rs.getInt("COMPANY_ID"));
			bean.setCompanyName(rs.getString("COMPANY_NAME"));
			bean.setAgent(rs.getString("AGENT"));
			bean.setCity(rs.getString("CITY"));
			bean.setCountry(rs.getString("COUNTRY"));
			bean.setDomain(rs.getString("DOMAIN"));
			bean.setFax(rs.getString("FAX"));
			bean.setIndustry(rs.getString("INDUSTRY"));
			bean.setPhoneNumber(rs.getString("PHONE_NUMBER"));
			bean.setProvince(rs.getString("PROVINCE"));
			bean.setStreet(rs.getString("STREET"));
			bean.setSupplier(rs.getString("SUPPLIER"));
			bean.setWebSite(rs.getString("WEB_SITE"));
			bean.setZipCode(rs.getString("ZIP_CODE"));
			
			return bean;
		}
	}
}
