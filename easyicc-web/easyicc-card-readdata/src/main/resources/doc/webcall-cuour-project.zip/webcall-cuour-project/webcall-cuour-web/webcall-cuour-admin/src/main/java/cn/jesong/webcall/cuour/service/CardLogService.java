package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;


import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.eutils.web.platform.db.SQLEso;
import cn.eutils.web.platform.db.SQLInfo;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.dao.OracleJdbcTemplate;
import cn.jesong.webcall.cuour.entity.CardLog;

@Service
public class CardLogService extends HibernateDAO<Integer, CardLog>{
	
	@Resource(name="jdbcTemplate")
	private OracleJdbcTemplate template;

	@Override
	protected Class<CardLog> getEntityClass() {
		return CardLog.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from CardLog where / companyId = {companyId} /  / and cardId = {cardId} / order by allocationTime asc";
	}
	
	public Page<CardLog> pageQuery(PageConfig config, Map<String, Object> params){
		String sql = "from CardLog where / companyId = {companyId} /  / and userId = {userId} /  / and allocationType = {allocationType} /" +
				" / and allocationTime > {startTime} / / and allocationTime < {endTime} /";
		SQLEso eso = SQLInfo.parseSQLEso(sql, params);
		return this.pageQuery(eso.getSQL(), config.getPageNo(), config.getPageSize(), eso.getParams());
	}
	
	public Page<Map<String, Object>> pageQuery2(int companyId, PageConfig config, Map<String, Object> params){
		String sql = "select a.*, b.mobile, c.real_name, d.real_name as operator_real_name "+
					 "	from js_cuour_card_log a "+
					 "	inner join js_visitor_info b on a.card_id = b.id "+
					 "	inner join js_user c on a.user_id = c.user_id "+
					 "	left join js_user d on a.operator_user_id = d.user_id "+
					 "	where a.company_id=?  "+
					 " 		/ and a.allocation_time > {startTime} / "+
					 "		/ and a.allocation_time < {endTime} /" +
					 "		/ and a.allocation_type = {allocationType} /" +
					 "		/ and a.user_id = {userId} /" +
					 "		/ and a.operator_user_id = {operatorUserId} /" +
					 "		/ and b.mobile like {mobile} /";
		SQLEso eso = SQLInfo.parseSQLEso(sql, params, new Object[]{companyId});
		return this.template.pageQuery(eso.getSQL(), eso.getParams(), config.getPageNo(), config.getPageSize(), new RowMapper<Map<String, Object>>(){
			@Override
			public Map<String, Object> mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				Map<String, Object> info = new HashMap<String, Object>();
				info.put("id", rs.getInt("id"));
				info.put("companyId", rs.getInt("company_id"));
				info.put("cardId", rs.getInt("card_id"));
				info.put("userId", rs.getString("user_id"));
				info.put("allocationType", rs.getInt("allocation_type"));
				info.put("allocationTime", new Date(rs.getTimestamp("allocation_time").getTime()));
				info.put("operatorUserId", rs.getString("operator_user_id"));
				info.put("mobile", rs.getString("mobile"));
				info.put("realName", rs.getString("real_name"));
				info.put("operatorRealName", rs.getString("operator_real_name"));
				return info;
			}
		});
	}

	
	
}


