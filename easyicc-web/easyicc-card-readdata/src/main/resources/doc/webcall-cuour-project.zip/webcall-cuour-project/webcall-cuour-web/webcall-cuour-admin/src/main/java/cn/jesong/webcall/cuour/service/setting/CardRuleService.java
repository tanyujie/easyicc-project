package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class CardRuleService extends SettingService<Integer, CardRule>{

	@Override
	protected Class<CardRule> getEntityClass() {
		return CardRule.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from CardRule where / companyId = {companyId} /";
	}

}
