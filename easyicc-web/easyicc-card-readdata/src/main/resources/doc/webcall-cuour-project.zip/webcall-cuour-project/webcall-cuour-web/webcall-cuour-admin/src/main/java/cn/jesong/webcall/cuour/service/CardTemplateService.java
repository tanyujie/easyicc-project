package cn.jesong.webcall.cuour.service;//package cn.jesong.webcall.cn.jesong.webcall.cuour.service;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.RowMapper;
//import org.springframework.stereotype.Service;
//
//import cn.jesong.webcall.cn.jesong.webcall.cuour.entity.CardTemplate;
///**
// * 名片分配模板service
// * @author hanjianxin
// *
// */
//@Service
//public class CardTemplateService {
//
//	@Autowired
//	private JdbcTemplate jdbcTemplate;
//	
//	/**
//	 * 获取动作配置
//	 * @param companyId
//	 * @param type
//	 * @return
//	 * @throws Exception
//	 */
//	public CardTemplate getCardTemplate(int tempId) throws Exception {
//		String sql = "select * from js_card_template where id = ?";
//		List<CardTemplate> list = this.jdbcTemplate.query(sql, new Object[]{tempId}, new CardTemplateRowMapper());
//		if(list != null) {
//			return list.get(0);
//		} else {
//			return new CardTemplate();
//		}
//	}
//	
//	/**
//	 * 添加动作配置
//	 * @param ac
//	 * @return
//	 * @throws Exception
//	 */
//	public int insert(CardTemplate bean) throws Exception {
//		int count = 0;
//		if (bean != null) {
//			String sql = "INSERT INTO js_card_template (URL, BODY, PARAM_TYPE, STATUS) VALUES (?, ?, ?, ?)";
//			count = this.jdbcTemplate.update(sql, bean.getUrl(), bean.getBody(), bean.getParamType(), bean.getStatus());
//		}
//		return count;
//	}
//	
//	class CardTemplateRowMapper implements RowMapper<CardTemplate>{
//		@Override
//		public CardTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
//			CardTemplate bean = new CardTemplate();
//			bean.setId(rs.getInt("ID"));
//			bean.setUrl(rs.getString("URL"));
//			bean.setBody(rs.getString("BODY"));
//			bean.setParamType(rs.getString("PARAM_TYPE"));
//			bean.setStatus(rs.getInt("STATUS"));
//			
//			return bean;
//		}
//	}
//	
//}
