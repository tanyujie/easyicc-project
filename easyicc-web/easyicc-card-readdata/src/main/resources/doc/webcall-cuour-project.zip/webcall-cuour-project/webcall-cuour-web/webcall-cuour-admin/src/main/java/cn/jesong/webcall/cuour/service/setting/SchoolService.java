package cn.jesong.webcall.cuour.service.setting;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.School;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SchoolService extends SettingService<Integer, School>{
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	protected Class<School> getEntityClass() {
		return School.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from School where / companyId = {companyId} / order by id desc";
	}

	public Boolean blinding(int companyId){
		String sql = "update JS_VISITOR_COL_SELF set col_type = ?, refer_table = ? where company_id = ? and col_name= ? ";
		int len = this.jdbcTemplate.update(sql, 4, "js_cuour_school", companyId, "extColumn9");
		return len > 0 ?  true : false;
	}
}
