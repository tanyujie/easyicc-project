package cn.jesong.webcall.cuour.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * 名片分配规则
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_cuour_card_rule")
public class CardRule implements CompanySetting{

	@Id
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 是否启用分配
	 */
	@Column(name = "use_allocation", nullable = false)
	private int useAllocation = 0;
	
	/**
	 * 分配时间间隔
	 */
	@Column(name = "time_interval", nullable = true)
	private Integer timeInterval = 60;
	
	/**
	 * 间隔时间内分配数量
	 */
	@Column(name = "allocation_size", nullable = true)
	private int allocationSize = 2;
	
	/**
	 * 每天最多分配数量
	 */
	@Column(name = "max_allocation_size", nullable = true)
	private int maxAllocationSize = 10;
	
	/**
	 * 超期回收开关
	 */
	@Column(name = "expired_recover", nullable = true)
	private int expiredRecover;
	
	/**
	 * 超时回收时间
	 */
	@Column(name = "expired_hour", nullable = true)
	private int expiredHour;
	
	/**
	 * 重置时间
	 */
	@Column(name = "reset_time", nullable = true)
	private String resetTime;
	
	/**
	 * 手机号码隐藏时间
	 */
	@Column(name = "mobile_hide_time", nullable = true)
	private int mobileHideTime;
	
	@Column(name = "server_name", nullable = false)
	private String serverName;
	
	/**
	 * 分配延迟(分)
	 */
	@Column(name = "allocation_delay", nullable = false)
	private int allocationDelay = 0;
	
	/**
	 * 默认项目
	 */
	@Column(name = "default_subject_id", nullable = false)
	private int defaultSubjectId = 0;
	
	/**
	 * 默认校区
	 */
	@Column(name = "default_school_id", nullable = false)
	private int defaultSchoolId = 0;
	
	/**
	 * 必须在线才能分配
	 */
	@Column(name = "need_online", nullable = false)
	private int needOnLine = 1;
	
	/**
	 * 必须排班才能分配
	 */
	@Column(name = "need_scheeduling", nullable = false)
	private int needScheeduling = 1;
	
	/**
	 * 分配模式 0按校区/项目 1 分配给创建者
	 */
	@Column(name = "allocation_model", nullable = false)
	private int allocationModel = 0;
	
	/**
	 * 微信推送是否开启  0开启  1关闭
	 */
	@Column(name = "IS_WECHAT_OPEN", nullable = false)
	private int isWechatOpen = 0;
	
	/**
	 * 在线分配模式   0 在线分配(只有在线的状态可以进行名片的分配) 1 在线分配(在线.忙碌.离开的状态可以进行名片的分配)
	 */
	@Column(name = "IS_ONLINE_ALLOCTION", nullable = false)
	private int isOnlineAllocation = 0;
	

	/**
	 * 是否开启上报头条功能（默认开启）
	 */
	@Column(name = "NEED_SUMBIT_TOUTIAO", nullable = false)
	private int needSumbitToutiao = 1;
	
	/**
	 * 同手机号新建的名片 多久时间内不再分配  时间类型默认是小时  1：小时 2：天
	 */
	@Column(name = "NO_DISTRIBUTE_TIME_TYPE", nullable = false)
	private Integer noDistributeTimeType = 1;
	/**
	 * 同手机号新建的名片 多久时间内不再分配  默认是3小时 
	 */
	@Column(name = "NO_DISTRIBUTE_TIME", nullable = false)
	private Integer noDistributeTime = 3;
	
	public int getNeedSumbitToutiao() {
		return needSumbitToutiao;
	}

	public void setNeedSumbitToutiao(int needSumbitToutiao) {
		this.needSumbitToutiao = needSumbitToutiao;
	}

	/**
	 * 分配算法 0权重;1轮循
	 */
	@Column(name = "algorithm", nullable = false)
	private int algorithm = 0;
	
	public int getIsWechatOpen() {
		return isWechatOpen;
	}

	public void setIsWechatOpen(int isWechatOpen) {
		this.isWechatOpen = isWechatOpen;
	}

	public int getIsOnlineAllocation() {
		return isOnlineAllocation;
	}

	public void setIsOnlineAllocation(int isOnlineAllocation) {
		this.isOnlineAllocation = isOnlineAllocation;
	}
	
	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public int getUseAllocation() {
		return useAllocation;
	}

	public void setUseAllocation(int useAllocation) {
		this.useAllocation = useAllocation;
	}

	public Integer getTimeInterval() {
		return timeInterval;
	}

	public void setTimeInterval(Integer timeInterval) {
		this.timeInterval = timeInterval;
	}

	public int getAllocationSize() {
		return allocationSize;
	}

	public void setAllocationSize(int allocationSize) {
		this.allocationSize = allocationSize;
	}

	public int getMaxAllocationSize() {
		return maxAllocationSize;
	}

	public void setMaxAllocationSize(int maxAllocationSize) {
		this.maxAllocationSize = maxAllocationSize;
	}

	public int getExpiredRecover() {
		return expiredRecover;
	}

	public void setExpiredRecover(int expiredRecover) {
		this.expiredRecover = expiredRecover;
	}

	public int getExpiredHour() {
		return expiredHour;
	}

	public void setExpiredHour(int expiredHour) {
		this.expiredHour = expiredHour;
	}

	public String getResetTime() {
		return resetTime;
	}

	public void setResetTime(String resetTime) {
		this.resetTime = resetTime;
	}

	public int getMobileHideTime() {
		return mobileHideTime;
	}

	public void setMobileHideTime(int mobileHideTime) {
		this.mobileHideTime = mobileHideTime;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public int getAllocationDelay() {
		return allocationDelay;
	}

	public void setAllocationDelay(int allocationDelay) {
		this.allocationDelay = allocationDelay;
	}

	public int getDefaultSubjectId() {
		return defaultSubjectId;
	}

	public void setDefaultSubjectId(int defaultSubjectId) {
		this.defaultSubjectId = defaultSubjectId;
	}

	public int getDefaultSchoolId() {
		return defaultSchoolId;
	}

	public void setDefaultSchoolId(int defaultSchoolId) {
		this.defaultSchoolId = defaultSchoolId;
	}

	public int getNeedOnLine() {
		return needOnLine;
	}

	public void setNeedOnLine(int needOnLine) {
		this.needOnLine = needOnLine;
	}

	public int getNeedScheeduling() {
		return needScheeduling;
	}

	public void setNeedScheeduling(int needScheeduling) {
		this.needScheeduling = needScheeduling;
	}

	public int getAllocationModel() {
		return allocationModel;
	}

	public void setAllocationModel(int allocationModel) {
		this.allocationModel = allocationModel;
	}

	public int getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(int algorithm) {
		this.algorithm = algorithm;
	}

	public Integer getNoDistributeTimeType() {
		return noDistributeTimeType;
	}

	public void setNoDistributeTimeType(Integer noDistributeTimeType) {
		this.noDistributeTimeType = noDistributeTimeType;
	}

	public Integer getNoDistributeTime() {
		return noDistributeTime;
	}

	public void setNoDistributeTime(Integer noDistributeTime) {
		this.noDistributeTime = noDistributeTime;
	}

	
}
