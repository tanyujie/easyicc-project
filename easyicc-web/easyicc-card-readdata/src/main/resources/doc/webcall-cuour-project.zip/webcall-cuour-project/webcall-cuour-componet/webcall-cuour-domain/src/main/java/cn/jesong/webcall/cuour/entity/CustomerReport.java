package cn.jesong.webcall.cuour.entity;

import java.math.BigDecimal;

public class CustomerReport {

	private String createUserId;
	
	private String realName;
	
	private int chatTotal;
	
	private int effectTotal;
	
	private int cardTotal;
	
	private int validTotal;
	
	private int backTotal;
	
	private double cardRatio;
	
	private double backRatio;
	
	public CustomerReport(String createUserId, String realName, int effectTotal, int chatTotal, int cardTotal, int validTotal, int backTotal){
		this.createUserId = createUserId;
		this.realName = realName;
		this.effectTotal = effectTotal;
		this.chatTotal = chatTotal;
		this.cardTotal = cardTotal;
		this.validTotal = validTotal;
		this.backTotal = backTotal;
		if(effectTotal > 0 && this.cardTotal >0){
			this.cardRatio = (new BigDecimal(this.cardTotal*100)).divide(new BigDecimal(this.effectTotal), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
		}
		if(this.cardTotal > 0 && this.backTotal > 0){
			this.backRatio = (new BigDecimal(this.backTotal*100)).divide(new BigDecimal(this.cardTotal), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
		}
	}
	
	

	public String getRealName() {
		return realName;
	}



	public String getCreateUserId() {
		return createUserId;
	}

	public int getChatTotal() {
		return chatTotal;
	}

	public int getCardTotal() {
		return cardTotal;
	}

	public int getValidTotal() {
		return validTotal;
	}

	public int getBackTotal() {
		return backTotal;
	}

	public double getCardRatio() {
		return cardRatio;
	}

	public double getBackRatio() {
		return backRatio;
	}



	public int getEffectTotal() {
		return effectTotal;
	}
	
	
	
}
