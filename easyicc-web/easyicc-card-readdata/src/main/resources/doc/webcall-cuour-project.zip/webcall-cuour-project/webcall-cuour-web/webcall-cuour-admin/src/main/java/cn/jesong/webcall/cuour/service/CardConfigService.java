package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import cn.jesong.webcall.db.rmi.IResourceMgr;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.eutils.web.platform.db.SQLEso;
import cn.eutils.web.platform.db.SQLInfo;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.CardLog;
import cn.jesong.webcall.cuour.entity.CuourCard;
import cn.jesong.webcall.cuour.entity.VisitorCol;
import cn.jesong.webcall.cuour.entity.VisitorColSelfItem;
import cn.jesong.webcall.cuour.entity.VisitorColSelfSon;
import cn.jesong.webcall.db.rmi.client.ResourceMgrClient;
import cn.jesong.webcall.resource.VisitorColSelf;

@Service
public class CardConfigService {
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate template;

	

	@SuppressWarnings("unchecked")
	public List<VisitorColSelfSon> getShowVisitorCols(int companyId) throws Exception{
       // IResourceMgr iResourceMgr = ResourceMgrClient.getInstance().getResourceMgr(companyId);
	   // List<VisitorColSelf> list = (List<VisitorColSelf>)iResourceMgr
	  //    .find("from VisitorColSelf where companyId = ? order by sortIndex", new Object[] { companyId });
		
		String sql = "select * from js_visitor_col_self where company_id = ? order by sort_index";
		List<VisitorColSelfSon> list = this.template.query(sql, new Object[]{companyId}, new VisitorColSelfRowMapper());
		
		
		List<VisitorColSelfSon> rtnList = new ArrayList<VisitorColSelfSon>();
		for(VisitorColSelfSon col : list){
			
			if(col.getHidden() == 1){
				String coleName = col.getColName();
				String sql4Col = "select * from js_visitor_col where col_name = ? ";
				List<VisitorCol> list1 = this.template.query(sql4Col, new Object[]{coleName}, new VisitorColRowMapper());
				if (list1 != null && !list1.isEmpty()) {
				    for(VisitorCol visitorCol:list1){
				        if(visitorCol.getColName().equals(visitorCol.getColName())){
                            col.setVisitorCol(visitorCol);
                            break;
                        }
                    }

				}
				Integer selfId = col.getId();
				String sql4Item = "select * from js_visitor_col_self_item where self_id = ? ";
				List<VisitorColSelfItem> list2 = this.template.query(sql4Item, new Object[]{selfId}, new VisitorColSelfItemRowMapper());
				Set<VisitorColSelfItem> items = new HashSet<>(list2);
				col.setItems(items);;
				rtnList.add(col);
			}
		}
		return rtnList;
	}
	
	public Page<CuourCard> pageCanDisposeVisitorCard(PageConfig pageConfig, Map<String, Object> map) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select * from js_visitor_info a where (allocation_status="+Card.STATUS_SYSTEM_ALLOCATIONED+" or allocation_status="+Card.STATUS_USE_ALLOCATIONED+" or allocation_status="+Card.STATUS_SALE_ALLOCATIONED+") / and company_id = {companyId} /");
		hql.append(" / and user_id={userId} / ")
		   .append("/ and a.create_time >= {startTime}  / ")
		   .append("/ and a.create_time <= {endTime}   /");
		hql.append(" order by create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map);
		Page<CuourCard> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<CuourCard>(pageConfig, new VisitorInfoRowMapper()));
		return page;
	}
	
	public CuourCard getVisitorInfo(int cardId){
		String sql = "select * from js_visitor_info where id = ?";
		List<CuourCard> list = this.template.query(sql, new Object[]{cardId}, new VisitorInfoRowMapper());
		if(list != null){
			return list.get(0);
		}else{
			return null;
		}
	}
	
	public Page<CuourCard> pageCardByCreateId(String createUserId, PageConfig pageConfig, Map<String, Object> map) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.* from js_visitor_info a where a.create_user_id = ? / and a.company_id = {companyId} /");
		hql.append("/ and a.name like {name} / ")
		   .append("/ and a.tel like {tel} / ")
		   .append("/ and a.email like {email} / ")
		   .append("/ and a.note like {note} / ")
		   .append("/ and a.reseve_key like {reseveKey} / ")
		   .append("/ and a.sex = {sex} / ")
		   .append("/ and a.repName like {repName} / ")
		   .append("/ and a.mobile like {mobile} / ")
		   .append("/ and a.qq like {qq} / ")
		   .append("/ and a.msn like {msn} / ")
		   .append("/ and a.url like {url} / ")
		   .append("/ and a.area like {area} /")
		   .append("/ and a.create_time >= {startTime} / ")
		   .append("/ and a.create_time <= {endTime} / ")
		   .append("/ and a.company_name like {companyName} / ")
		   .append("/ and a.ext_column1 like {extColumn1} / ")
		   .append("/ and a.ext_column2 like {extColumn2} / ")
		   .append("/ and a.ext_column3 like {extColumn3} / ")
		   .append("/ and a.ext_column4 like {extColumn4} / ")
		   .append("/ and a.ext_column5 like {extColumn5} / ")
		   .append("/ and a.ext_column6 like {extColumn6} / ")
		   .append("/ and a.ext_column7 like {extColumn7} / ")
		   .append("/ and a.ext_column8 = {extColumn8} / ")//咨询项目
		   .append("/ and a.ext_column9 = {extColumn9} / ")//校区
		   .append("/ and a.ext_column10 like {extColumn10} / ");
		hql.append("order by a.create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map, new Object[]{createUserId});
		Page<CuourCard> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<CuourCard>(pageConfig, new VisitorInfoRowMapper()));
		return page;
	}
	
	
	/*public Page<CuourCard> pageCanAllocationVisitorCard(PageConfig pageConfig, Map<String, Object> map) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.* from js_visitor_info a where a.allocation_status="+Card.STATUS_WAIT_USE_ALLOCATION+" / and a.company_id = {companyId} /");
		hql.append("/ and a.name like {name} / ")
		   .append("/ and a.tel like {tel} / ")
		   .append("/ and a.email like {email} / ")
		   .append("/ and a.note like {note} / ")
		   .append("/ and a.reseve_key like {reseveKey} / ")
		   .append("/ and a.sex = {sex} / ")
		   .append("/ and a.repName like {repName} / ")
		   .append("/ and a.mobile like {mobile} / ")
		   .append("/ and a.qq like {qq} / ")
		   .append("/ and a.msn like {msn} / ")
		   .append("/ and a.url like {url} / ")
		   .append("/ and a.area like {area} /")
		   .append("/ and a.create_time >= {startTime} / ")
		   .append("/ and a.create_time <= {endTime} / ")
		   .append("/ and a.company_name like {companyName} / ")
		   .append("/ and a.ext_column1 like {extColumn1} / ")
		   .append("/ and a.ext_column2 like {extColumn2} / ")
		   .append("/ and a.ext_column3 like {extColumn3} / ")
		   .append("/ and a.ext_column4 like {extColumn4} / ")
		   .append("/ and a.ext_column5 like {extColumn5} / ")
		   .append("/ and a.ext_column6 like {extColumn6} / ")
		   .append("/ and a.ext_column7 like {extColumn7} / ")
		   .append("/ and a.ext_column8 = {extColumn8} / ")//咨询项目
		   .append("/ and a.ext_column9 = {extColumn9} / ")//校区
		   .append("/ and a.ext_column10 like {extColumn10} / ")
		   .append("/ and a.is_back = {isBack} / ")
		   .append("/ and a.back_type = {backType} /")
		   .append("/ and a.is_expired = {isExpired} / ")
		   .append("/ and exists (select 1 from js_cuour_card_log b where a.id = b.card_id and b.user_id like {backUserId} and allocation_type = "+CardLog.ALLOCATION_TYPE_BACK+")/");
		hql.append("order by a.create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map);
		Page<CuourCard> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<CuourCard>(pageConfig, new VisitorInfoRowMapper()));
		return page;
	}*/
	
	public Page<CuourCard> pageVisitorCard(PageConfig pageConfig, Map<String, Object> map, int status) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.* from js_visitor_info a where  a.allocation_status > 0 ");
		List<Object> params = new ArrayList<Object>();
		if(status == 1){//退回
			hql.append(" and a.allocation_status = ? and a.is_back = 1 ");
			params.add(Card.STATUS_WAIT_USE_ALLOCATION);
		}else if(status == 2){//超期回收
			hql.append(" and a.allocation_status = ? and a.is_expired = 1 ");
			params.add(Card.STATUS_WAIT_USE_ALLOCATION);
		}else if(status == 3){//等待分配
			hql.append(" and a.allocation_status = ? and a.is_expired = 0 and a.is_back = 0 and a.back_user_id is null");
			params.add(Card.STATUS_WAIT_USE_ALLOCATION);
		}else if(status == 4){//已处理
			hql.append(" and a.allocation_status = ? and a.is_valid = 1 and a.back_user_id is null");
			params.add(Card.STATUS_FINISHED);
		}else if(status == 5){//未处理
			hql.append("and (a.allocation_status = ? or a.allocation_status = ? ) and a.back_user_id is null");
			params.add(Card.STATUS_SYSTEM_ALLOCATIONED);
			params.add(Card.STATUS_USE_ALLOCATIONED);
		}else if(status == 6){//设置无效
			hql.append(" and a.allocation_status = ? and a.is_valid = 0 ");
			params.add(Card.STATUS_FINISHED);
		}else if(status == 7){//再分配未处理
			hql.append("and a.allocation_status = ? and  a.back_user_id is not null");
			params.add(Card.STATUS_USE_ALLOCATIONED);
		}else if(status == 8){//再分配已处理
			hql.append("and a.allocation_status = ? and a.is_valid = 1 and a.back_user_id is not null");
			params.add(Card.STATUS_FINISHED);
		}else if(status == 9){
			hql.append(" and a.allocation_status = ? ");
			params.add(Card.STATUS_REPEAT);
		}else{
			//1, 2, 3, 6, 9
			hql.append(" and (a.allocation_status = ? or (a.allocation_status = ? and a.is_valid = 0) or  a.allocation_status = ?) ");
			params.add(Card.STATUS_WAIT_USE_ALLOCATION);
			params.add(Card.STATUS_FINISHED);
			params.add(Card.STATUS_REPEAT);
		}
		hql.append("/ and a.company_id = {companyId} /")
		   .append("/ and a.name like {name} / ")
		   .append("/ and a.tel like {tel} / ")
		   .append("/ and a.email like {email} / ")
		   .append("/ and a.note like {note} / ")
		   .append("/ and a.reseve_key like {reseveKey} / ")
		   .append("/ and a.sex = {sex} / ")
		   .append("/ and a.repName like {repName} / ")
		   .append("/ and a.mobile like {mobile} / ")
		   .append("/ and a.qq like {qq} / ")
		   .append("/ and a.msn like {msn} / ")
		   .append("/ and a.url like {url} / ")
		   .append("/ and a.area like {area} /")
		   .append("/ and a.create_time >= {startTime} / ")
		   .append("/ and a.create_time <= {endTime} / ")
		   .append("/ and a.company_name like {companyName} / ")
		   .append("/ and a.ext_column1 like {extColumn1} / ")
		   .append("/ and a.ext_column2 like {extColumn2} / ")
		   .append("/ and a.ext_column3 like {extColumn3} / ")
		   .append("/ and a.ext_column4 like {extColumn4} / ")
		   .append("/ and a.ext_column5 like {extColumn5} / ")
		   .append("/ and a.ext_column6 like {extColumn6} / ")
		   .append("/ and a.ext_column7 like {extColumn7} / ")
		   .append("/ and a.ext_column8 = {extColumn8} / ")//咨询项目
		   .append("/ and a.ext_column9 = {extColumn9} / ")//校区
		   .append("/ and a.ext_column10 like {extColumn10} / ")
		   .append("/ and a.back_type = {backType} /")
		   .append("/ and exists (select 1 from js_cuour_card_log b where a.id = b.card_id and b.user_id like {backUserId} and allocation_type = "+CardLog.ALLOCATION_TYPE_BACK+")/")
		   .append("order by a.create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map, params.toArray(new Object[params.size()]));
		Page<CuourCard> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<CuourCard>(pageConfig, new VisitorInfoRowMapper()));
		return page;
	}
	
	public Page<CuourCard> pageVisitorCardByCardId(PageConfig pageConfig, Map<String, Object> map,int companyId, int cardId) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.* from js_visitor_info a where a.company_id = ? and a.id=? ");
		List<Object> params = new ArrayList<Object>();
		params.add(companyId);
		params.add(cardId);
		
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map, params.toArray(new Object[params.size()]));
		Page<CuourCard> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<CuourCard>(pageConfig, new VisitorInfoRowMapper()));
		return page;
	}
	
	class  PageResultSetExtractor <T> implements ResultSetExtractor<Page<T>>{
		
		private PageConfig pageConfig;
		
		private RowMapper<T> rowMapper;
		
		public PageResultSetExtractor(PageConfig pageConfig, RowMapper<T> rowMapper){
			this.pageConfig = pageConfig;
			this.rowMapper = rowMapper;
		}

		@Override
		public Page<T> extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			int currentRow = 1;  
			Page<T> page = new Page<T>();
			List<T> rows = new ArrayList<T>();
			int startRow = (pageConfig.getPageNo() - 1) * pageConfig.getPageSize() + 1;
			while(rs.next()){
				if(currentRow < startRow + pageConfig.getPageSize() && currentRow >= startRow){
					rows.add(rowMapper.mapRow(rs, currentRow)); 
				}
				currentRow++;  
			}
            page.setRows(rows);
            page.setTotal(currentRow-1);
			return page;
		}
	}
	
	class VisitorInfoRowMapper implements RowMapper<CuourCard>{

		@Override
		public CuourCard mapRow(ResultSet rs, int rowNum) throws SQLException {
			CuourCard v = new CuourCard();
			v.setId(rs.getInt("id"));
			v.setVisitorStaticId(rs.getString("visitor_static_id"));
			v.setCompanyId(rs.getInt("company_id"));
			v.setName(rs.getString("name"));
			v.setTel(rs.getString("tel"));
			v.setEmail(rs.getString("email"));
			v.setNote(rs.getString("note"));
			v.setReseveKey(rs.getString("reseve_key"));
			v.setSex(rs.getString("sex"));
			v.setRepName(rs.getString("repname"));
			v.setMobile(rs.getString("mobile"));
			v.setQq(rs.getString("qq"));
			v.setMsn(rs.getString("msn"));
			v.setUrl(rs.getString("url"));
			v.setCompanyName(rs.getString("company_name"));
			v.setArea(rs.getString("area"));
			v.setUserId(rs.getString("user_id"));
			v.setCreateTime(rs.getTimestamp("create_time"));
			v.setExtColumn1(rs.getString("ext_column1"));
			v.setExtColumn2(rs.getString("ext_column2"));
			v.setExtColumn3(rs.getString("ext_column3"));
			v.setExtColumn4(rs.getString("ext_column4"));
			v.setExtColumn5(rs.getString("ext_column5"));
			v.setExtColumn6(rs.getString("ext_column6"));
			v.setExtColumn7(rs.getString("ext_column7"));
			v.setExtColumn8(rs.getString("ext_column8"));
			v.setExtColumn9(rs.getString("ext_column9"));
			v.setExtColumn10(rs.getString("ext_column10"));
			v.setFirstURL(rs.getString("first_url"));
			v.setChatURL(rs.getString("chat_url"));
			v.setBackDesp(rs.getString("back_desp"));
			v.setFinishDesp(rs.getString("finish_desp"));
			v.setIsValid(rs.getInt("is_valid"));
			v.setIsBack(rs.getInt("is_back"));
			v.setIsExpired(rs.getInt("is_expired"));
			v.setBackType(rs.getInt("back_type"));
			v.setAllocationStatus(rs.getInt("allocation_status"));
			v.setModifyIdentity(rs.getString("modify_identity"));
			v.setCreateUserId(rs.getString("create_user_id"));
			
			v.setAllocationTime(rs.getTimestamp("allocation_time"));
			v.setBackUserId(rs.getString("back_user_id"));
			v.setBackTime(rs.getTimestamp("back_time"));
			v.setChatId(rs.getInt("chat_id"));
			
			return v;
		}
		
	}
	
	class VisitorColSelfRowMapper implements RowMapper<VisitorColSelfSon>{

		@Override
		public VisitorColSelfSon mapRow(ResultSet rs, int rowNum) throws SQLException {
			VisitorColSelfSon v = new VisitorColSelfSon();
			v.setId(rs.getInt("id"));
			v.setCompanyId(rs.getInt("company_id"));
			v.setSelfText(rs.getString("self_text"));
			v.setColType(rs.getInt("col_type"));
			v.setHidden(rs.getInt("hidden"));
			v.setSortIndex(rs.getInt("sort_index"));
			v.setEditable(rs.getInt("editable"));
			v.setReferTable(rs.getString("refer_table"));
			v.setRequired(rs.getInt("required"));
			v.setFormatter(rs.getString("formatter"));
			v.setColName(rs.getString("col_name"));
			
			return v;
		}
		
	}
	
	class VisitorColRowMapper implements RowMapper<VisitorCol>{

		@Override
		public VisitorCol mapRow(ResultSet rs, int rowNum) throws SQLException {
			VisitorCol v = new VisitorCol();
			v.setColName(rs.getString("col_name"));
			v.setText(rs.getString("text"));
			
			return v;
		}
		
	}
	
	class VisitorColSelfItemRowMapper implements RowMapper<VisitorColSelfItem>{

		@Override
		public VisitorColSelfItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			VisitorColSelfItem v = new VisitorColSelfItem();
			v.setId(rs.getInt("id"));
			v.setSelfId(rs.getInt("self_id"));
			v.setItemName(rs.getString("item_name"));
			
			return v;
		}
		
	}
	
}
