package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 用户排班班次
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_scheduling_user")
public class SchedulingUser implements CompanySetting{
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_scheduling_user_id_seq")
	@SequenceGenerator(name = "js_scheduling_user_id_seq", sequenceName = "js_scheduling_user_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 排班时间
	 */
	@Column(name = "scheduling_time", nullable = false)
	private String schedulingTime;
	
	/**
	 * 排班班次ID
	 */
	@Column(name = "scheduling_id", nullable = false)
	private Integer schedulingId;
	
	/**
	 * 排班用户
	 */
	@Column(name = "user_id", nullable = false)
	private String userId;
	
	/**
	 * 排班类型(1 销售排班 2客服排班)
	 */
	@Column(name = "scheduling_type", nullable = false)
	private int schedulingType = 1;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getSchedulingTime() {
		return schedulingTime;
	}

	public void setSchedulingTime(String schedulingTime) {
		this.schedulingTime = schedulingTime;
	}

	public Integer getSchedulingId() {
		return schedulingId;
	}

	public void setSchedulingId(Integer schedulingId) {
		this.schedulingId = schedulingId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getSchedulingType() {
		return schedulingType;
	}

	public void setSchedulingType(int schedulingType) {
		this.schedulingType = schedulingType;
	}
	
}
