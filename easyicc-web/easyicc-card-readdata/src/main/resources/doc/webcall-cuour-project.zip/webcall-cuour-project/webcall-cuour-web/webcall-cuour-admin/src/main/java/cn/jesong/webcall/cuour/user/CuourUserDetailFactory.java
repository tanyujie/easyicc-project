package cn.jesong.webcall.cuour.user;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import cn.eutils.web.platform.permission.user.IUserDetail;
import cn.eutils.web.platform.permission.user.UserDetailFactory;
import cn.jesong.webcall.resource.User;

@Repository
public class CuourUserDetailFactory implements UserDetailFactory {
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Override
	public IUserDetail createUserDetail(User user) {
		List<String> roles = this.jdbcTemplate.query("select role_id from js_user_role where user_id=?", new Object[]{user.getUserId()}, new RowMapper<String>(){
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString("role_id");
			}
		});
		
		List<String> menuIds = this.jdbcTemplate.query(
			"select menu_id from js_sys_menu a "+
			"	where exists( "+
			"      select 1 from js_user_role b "+
			"      inner join js_sys_role_menu c on c.role_id = b.role_id "+
			"      where b.user_id=? and a.menu_id = c.menu_id "+
			") and a.menu_type=30", 
			new Object[]{user.getUserId()}, new RowMapper<String>(){
				@Override
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					return rs.getString("menu_id");
				}
			}
		);
		
		List<Map<String, String>> dataRoles = this.jdbcTemplate.query(
				"select a.menu_id, data_id, data_value from js_sys_role_data a where exists( "+ 
				"	select 1 from js_user_role b where a.role_id = b.role_id and b.user_id = ? "+
				")", new Object[]{user.getUserId()}, new RowMapper<Map<String, String>>(){

					@Override
					public Map<String, String> mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						Map<String, String> map = new HashMap<String, String>();
						map.put("menu_id", rs.getString("menu_id"));
						map.put("data_id", rs.getString("data_id"));
						map.put("data_value", rs.getString("data_value"));
						return map;
					}
				});
		
		return new CuourUserDetail(user, roles, menuIds, dataRoles);
	}

}
