package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;
import java.util.Date;

/**
 * 名片接口
 * @author hanjianxin
 *
 */
@Entity
@Table(name = "js_cuour_card_interface")
public class CardInterface implements CompanySetting {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_cuour_card_interface_id_seq")
	@SequenceGenerator(name = "js_cuour_card_interface_id_seq", sequenceName = "js_cuour_card_interface_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "token", nullable = false)
	private String token;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "url", nullable = false)
	private String url;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "param", nullable = false)
	private String param;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "create_time", nullable = false)
	private Date createTime;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "update_time", nullable = false)
	private Date updateTime;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "is_use_subject", nullable = false)
	private int isUseSubject;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "IS_USE_SCHOOL", nullable = false)
	private int isUseSchool;
	
	/**
	 * 销售类型名称
	 */
	@Column(name = "is_delete", nullable = false)
	private int isDelete;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}

	public int getIsUseSubject() {
		return isUseSubject;
	}

	public void setIsUseSubject(int isUseSubject) {
		this.isUseSubject = isUseSubject;
	}

	public int getIsUseSchool() {
		return isUseSchool;
	}

	public void setIsUseSchool(int isUseSchool) {
		this.isUseSchool = isUseSchool;
	}

}
