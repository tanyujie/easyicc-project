package cn.jesong.webcall.cuour.cache;

import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.cache.entity.SchedulingTime;
import cn.jesong.webcall.cuour.entity.CardRule;

import java.util.List;

public interface CacheDataLoader {

	
	/**
	 * 获取分配规则
	 * @param companyId
	 * @return
	 */
	public CardRule getCardRule(int companyId);
	
	/**
	 * 获取销售人员
	 * @param companyId
	 * @param time
	 * @return
	 */
	public List<SaleUser> getSaleUser(int companyId, String time, Boolean b);
	
	/**
	 * 获取排班信息
	 * @param companyId
	 * @param time
	 * @return
	 */
	public List<SchedulingTime> getSchedulingTimes(int companyId, String time);
	
	/**
	 * 获取已分配的名片
	 * @param companyId
	 * @param time
	 * @return
	 */
	//public List<Card> getAllocationedCards(int companyId, String time);
	
	
}
