package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;
import java.util.Date;


/**
 * 名片分配日志
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_cuour_card_log")
public class CardLog {
	
	public final static int ALLOCATION_TYPE_SYSTEM = 1;
	
	public final static int ALLOCATION_TYPE_USER = 2;
	
	public final static int ALLOCATION_TYPE_BACK = 3;
	
	public final static int ALLOCATION_TYPE_FINISHED = 4;
	
	public final static int ALLOCATION_TYPE_EXPIRED = 5;
	
	public final static int ALLOCATION_TYPE_SALE = 6;
	
	public final static int ALLOCATION_TYPE_SALE_FINIHSED = 7;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_cuour_card_log_id_seq")
	@SequenceGenerator(name = "js_cuour_card_log_id_seq", sequenceName = "js_cuour_card_log_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private int companyId;
	
	/**
	 * 名片ID
	 */
	@Column(name = "card_id", nullable = false)
	private int cardId;
	
	
	/**
	 * 用户ID
	 */
	@Column(name = "user_id", nullable = false)
	private String userId;
	
	/**
	 * 分配类型
	 */
	@Column(name = "allocation_type", nullable = false)
	private int allocationType;
	
	/**
	 * 分配时间
	 */
	@Column(name = "allocation_time", nullable = false)
	private Date allocationTime = new Date();
	
	/**
	 * 操作用户ID
	 */
	@Column(name = "operator_user_id", nullable = true)
	private String operatorUserId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getCardId() {
		return cardId;
	}

	public void setCardId(int cardId) {
		this.cardId = cardId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(int allocationType) {
		this.allocationType = allocationType;
	}

	public Date getAllocationTime() {
		return allocationTime;
	}

	public void setAllocationTime(Date allocationTime) {
		this.allocationTime = allocationTime;
	}

	public String getOperatorUserId() {
		return operatorUserId;
	}

	public void setOperatorUserId(String operatorUserId) {
		this.operatorUserId = operatorUserId;
	}
	
	
	
}
