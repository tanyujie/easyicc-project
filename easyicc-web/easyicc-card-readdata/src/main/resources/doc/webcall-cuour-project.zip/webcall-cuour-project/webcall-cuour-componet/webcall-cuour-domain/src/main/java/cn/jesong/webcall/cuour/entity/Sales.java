package cn.jesong.webcall.cuour.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 销售人员
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_cuour_sales")
public class Sales implements CompanySetting{

	/**
	 * 客服ID
	 */
	@Id
    @Column(name = "user_id", nullable = false)
	private String userId;
	
	/**
	 * 所属公司
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 校区ID
	 */
	@Column(name = "school_id", nullable = false)
	private Integer schoolId;
	
	/**
	 * 项目ID
	 */
	@Column(name = "subject_id", nullable = false)
	private Integer subjectId;
	
	/**
	 * 业务分组ID
	 */
	@Column(name = "business_group_id", nullable = false)
	private Integer businessGroupId;
	
	/**
	 * 销售类型ID
	 */
	@Column(name = "sales_type_id", nullable = false)
	private Integer salesTypeId;
	
	/**
	 * 当天最大分配量
	 */
	@Column(name = "max_card_size", nullable = false)
	private int maxCardSize;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public Integer getBusinessGroupId() {
		return businessGroupId;
	}

	public void setBusinessGroupId(Integer businessGroupId) {
		this.businessGroupId = businessGroupId;
	}

	public Integer getSalesTypeId() {
		return salesTypeId;
	}

	public void setSalesTypeId(Integer salesTypeId) {
		this.salesTypeId = salesTypeId;
	}

	public int getMaxCardSize() {
		return maxCardSize;
	}

	public void setMaxCardSize(int maxCardSize) {
		this.maxCardSize = maxCardSize;
	}

}
