package cn.jesong.webcall.cuour.common;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import com.sun.image.codec.jpeg.JPEGCodec;
//import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class ImageUtil {
	protected final transient Log log = LogFactory.getLog(getClass());

//	public static void outLogo(byte[] source, OutputStream out, int dwidth,
//			int dheight) throws Exception {
//		BufferedInputStream stream = new BufferedInputStream(
//				(new ByteArrayInputStream(source)), 8092);// 控制流速
//		Image src = javax.imageio.ImageIO.read(stream);
//		int width = src.getWidth(null);
//		int height = src.getHeight(null);
//		int towidth, toheight;
//		if (width > dwidth || height > dheight) {
//			if (((float) width / dwidth) >= ((float) height / dheight)) {
//				towidth = dwidth;
//				toheight = (height * dwidth) / width;
//			} else {
//				toheight = dheight;
//				towidth = (width * dheight) / height;
//			}
//		} else {
//			towidth = width;
//			toheight = height;
//		}
//
//		BufferedImage tag = new BufferedImage(towidth, toheight,
//				BufferedImage.TYPE_INT_RGB);
//		tag.getGraphics().drawImage(src, 0, 0, towidth, toheight, null);
//		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
//		encoder.encode(tag);
//	}

	/**
	 * 将 图片 缩放成 一定的尺寸
	 * 
	 * @param outputStream
	 * @param in
	 * @param dwidth
	 * @param dheight
	 * @throws IOException
	 */
	public static void smallImage(OutputStream outputStream, InputStream in,
			int dwidth, int dheight) throws IOException {

		Image img = ImageIO.read(in);
		int width = img.getWidth(null);
		int height = img.getHeight(null);
		int towidth, toheight;
		if (width > dwidth || height > dheight) {
			if (((float) width / dwidth) >= ((float) height / dheight)) {
				towidth = dwidth;
				toheight = (height * dwidth) / width;
			} else {
				toheight = dheight;
				towidth = (width * dheight) / height;
			}
		} else {
			towidth = width;
			toheight = height;
		}
		BufferedImage tag = new BufferedImage(towidth, toheight,
				BufferedImage.TYPE_INT_RGB);
		tag.getGraphics().drawImage(
				img.getScaledInstance(towidth, toheight, Image.SCALE_SMOOTH),
				0, 0, null);
//		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(outputStream);
//		encoder.encode(tag);
//		ImageIO.write(tag, "", outputStream);
		
		
		
		ImageIO.write(tag, "JPEG", outputStream);
	}

	public static InputStream smallImage(InputStream in, String extName,
			int dwidth, int dheight) throws IOException {
		Image img = ImageIO.read(in);
		int width = img.getWidth(null);
		int height = img.getHeight(null);
		int towidth, toheight;
		if (width > dwidth || height > dheight) {
			if (((float) width / dwidth) >= ((float) height / dheight)) {
				towidth = dwidth;
				toheight = (height * dwidth) / width;
			} else {
				toheight = dheight;
				towidth = (width * dheight) / height;
			}
		} else {
			towidth = width;
			toheight = height;
		}
		BufferedImage tag = new BufferedImage(towidth, toheight,
				BufferedImage.TYPE_INT_RGB);
		tag.getGraphics().drawImage(img.getScaledInstance(towidth, toheight, Image.SCALE_FAST),0, 0, null);
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ImageIO.write(tag, extName, os);
		InputStream is = new ByteArrayInputStream(os.toByteArray());
		return is;
	}

	public static byte[] toByteArray(InputStream input) throws IOException {
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		byte[] buffer = new byte[4096];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		return output.toByteArray();
	}
}