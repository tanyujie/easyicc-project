package cn.jesong.webcall.distribution.api.common;

public enum ResultTypeEnum {


    /** 成功 */
    SUCCESS(0),
    /** 警告 */
    WARN(301),
    /**无权限 */
    NO_AUTH(401),
    /**无权限 */
    NO_LOGIN(403),
    /** 错误 */
    ERROR(500);
    private  int code;


    ResultTypeEnum(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
