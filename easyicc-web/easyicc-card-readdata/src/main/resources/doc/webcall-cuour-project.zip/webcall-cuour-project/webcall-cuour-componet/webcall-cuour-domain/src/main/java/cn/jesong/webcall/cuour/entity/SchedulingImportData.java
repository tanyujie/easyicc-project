package cn.jesong.webcall.cuour.entity;

import java.util.ArrayList;
import java.util.List;

public class SchedulingImportData {
	
	private int companyId;

	private String[] dates;
	
	private List<SchedulingWeek> schedulings = new ArrayList<SchedulingWeek>();
	
	public SchedulingImportData(int companyId,  String[] dates){
		if(dates == null || dates.length != 7){
			throw new RuntimeException("排班数据长度不对");
		}
		this.companyId = companyId;
		this.dates = dates;
	}
	
	public void addSchedulingWeek(SchedulingWeek week){
		this.schedulings.add(week);
	}

	public int getCompanyId() {
		return companyId;
	}

	public String[] getDates() {
		return dates;
	}

	public List<SchedulingWeek> getSchedulings() {
		return schedulings;
	}
	
	
	
	
	
}
