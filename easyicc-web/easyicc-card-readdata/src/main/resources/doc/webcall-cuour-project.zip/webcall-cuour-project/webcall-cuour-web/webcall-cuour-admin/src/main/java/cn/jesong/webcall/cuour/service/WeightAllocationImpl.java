package cn.jesong.webcall.cuour.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.jesong.webcall.core.client.CoreClient;

import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.logic.UserMgrException;
import cn.jesong.webcall.object.UserSession;

/**
 * 权重分配算法
 * 
 * @author Administrator
 *
 */
@Service
public class WeightAllocationImpl implements AllocationSaleUserInterface {

	private final static Log _logger = LogFactory.getLog(WeightAllocationImpl.class);

	/**
	 * 权重分配算法 根据权重返回分配销售id
	 * 
	 * @param allocationUsers
	 * @return
	 */
	@Override
	public SaleUser allocationSaleUser(Card card, List<SaleUser> allocationUsers) {
		// 将可分配客服List<SaleUser>进行权重排序
		Collections.sort(allocationUsers, new Comparator<SaleUser>() {
			@Override
			public int compare(SaleUser o1, SaleUser o2) {
				// 已分配数/权重
				if (o1.getAllocationWeight() > 0 && o2.getAllocationWeight() > 0) {
					if (o1.getAllocationCount() == 0 && o2.getAllocationCount() == 0) {
						if (o1.getAllocationWeight() > o2.getAllocationWeight()) {
							return -1;
						} else if (o1.getAllocationWeight() < o2.getAllocationWeight()) {
							return 1;
						}
					} else {
						double b1 = (new BigDecimal(o1.getValidCount()))
								.divide(new BigDecimal(o1.getAllocationWeight()), 2, BigDecimal.ROUND_HALF_UP)
								.doubleValue();
						double b2 = (new BigDecimal(o2.getValidCount()))
								.divide(new BigDecimal(o2.getAllocationWeight()), 2, BigDecimal.ROUND_HALF_UP)
								.doubleValue();
						return b1 > b2 ? 1 : -1;
					}
				} else {
					if (o1.getAllocationCount() > o2.getAllocationCount()) {
						return 1;
					} else if (o1.getAllocationCount() < o2.getAllocationCount()) {
						return -1;
					}
				}
				return 0;
			}
		});
		return allocationUsers.get(0);
	}
}
