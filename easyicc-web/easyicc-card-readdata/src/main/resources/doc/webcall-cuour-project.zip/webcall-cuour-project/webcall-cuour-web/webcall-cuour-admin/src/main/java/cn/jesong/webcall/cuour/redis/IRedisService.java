package cn.jesong.webcall.cuour.redis;

public interface IRedisService {
	
	public void set(String key, String value);
	
	public void set(String key, String value, Integer time);

	public String get(String key);

	public void remove(String key);

}
