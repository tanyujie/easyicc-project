package cn.jesong.webcall.pushdata.api.domain;

import cn.jesong.webcall.pushdata.api.common.ResultTypeEnum;

import java.io.Serializable;

/**
 * 分配系统返回结果
 */
public class DistributionResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer code;
    private String msg;
    private Object data;


    /**
     * 状态类型
     */
    public enum Type {
        /** 成功 */
        SUCCESS(0),
        /** 警告 */
        WARN(301),
        /**无权限 */
        NO_AUTH(401),
        /**无权限 */
        NO_LOGIN(403),
        /** 错误 */
        ERROR(500);

        private final int value;

        Type(int value) {
            this.value = value;
        }

        public int value() {
            return this.value;
        }
    }
    public DistributionResult(){

    }
    public DistributionResult(ResultTypeEnum typeEnum,String msg, Object data){
        this.code = typeEnum.getCode();
        this.msg = msg;
        this.data = data;
    }
    public  static DistributionResult success(String msg, Object data) {
        return new DistributionResult(ResultTypeEnum.SUCCESS,msg,data);
    }
    public  static DistributionResult success(String msg) {
        return new DistributionResult(ResultTypeEnum.SUCCESS,msg,null);
    }
    public static DistributionResult success() {
        return new DistributionResult(ResultTypeEnum.SUCCESS,"操作成功",null);
    }

    public  static DistributionResult error(String msg, Object data) {
        return new DistributionResult(ResultTypeEnum.ERROR,msg,data);
    }
    public  static DistributionResult error(String msg) {
        return new DistributionResult(ResultTypeEnum.ERROR,msg,null);
    }
    public static DistributionResult error() {
        return new DistributionResult(ResultTypeEnum.ERROR,"操作失败",null);
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
