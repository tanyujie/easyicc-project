package cn.jesong.webcall.cuour.log.dao;

import cn.jesong.webcall.cuour.entity.CardApiPushLog;

public interface CardLogDao {

	CardApiPushLog getLog(Integer id);

	void saveLog(CardApiPushLog log);

	void saveOrUpdateLog(CardApiPushLog cardApiPushLog);

}
