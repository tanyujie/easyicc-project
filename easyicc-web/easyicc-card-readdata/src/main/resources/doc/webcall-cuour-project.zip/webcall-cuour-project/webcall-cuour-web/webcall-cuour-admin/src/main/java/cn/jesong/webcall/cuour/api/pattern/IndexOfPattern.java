package cn.jesong.webcall.cuour.api.pattern;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public class IndexOfPattern implements IApiPattern{

	@Override
	public boolean isMatching(ActionConfig config, String result) {
		boolean ret = false;
		if(result != null && config != null){
			String containRule = config.getContainRule();
			if(containRule != null && containRule.trim().length() > 0){
				if(result.indexOf(containRule) >= 0){
					ret = true;
				}
			}
			
		}
		return ret;
	}
}
