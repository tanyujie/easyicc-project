package cn.jesong.webcall.cuour.controller.setting;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.common.CmdConstant;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.service.ActionConfigService;
/**
 * 第三方接口配置
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/setting/thirdParty")
public class ThirdPartyController extends
				SimpleController<Integer, ActionConfig>  {
	
	private final static String PREFIX = "/setting/thirdParty";
	
	@Autowired
	private ActionConfigService acService;
	
	@RequestMapping("/indexThirdParty")
	public String indexThirdParty(ModelMap model) throws Exception {
		try {
			int companyId = OnLine.getCurrentUserDetails().getCompanyId();
			ActionConfig ac = acService.getActionConfig(companyId);
			model.put("actionConfig", ac);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return PREFIX + "/index";
	}
	
	/**
	 * 名片接口列表
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/queryPage")
	@ResponseBody
	public Page<ActionConfig> queryPage(HttpServletRequest request) {
		Page<ActionConfig> page = new Page<ActionConfig>();
		try {
			Object params = this.getQueryParams(request);
			if (params == null) {
				params = new HashMap<String, Object>();
			}
			page = this.getHibernateService()
					.pageQueryByTemplate(PageConfig.createPageConfig(request),
							params);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return page;
	}
	
//	@RequestMapping(value = "/createInterface", method = RequestMethod.GET)
//	public String createInterface(ModelMap model) {
//		try {
//		//	List<Company> list = cService.getCompanys();
//		//	model.put("companys", list);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//		return PREFIX + "/form";
//	}

	/**
	 * 新增名片接口
	 * 
	 * @param ci
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/createInterface", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> createInterface(ActionConfig ac, HttpServletRequest request) throws IOException {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			if (ac != null) {
				if(ac.getId() > 0) {
					ac.setParamType(ac.getBodyType());
					//ac.setCmd(CmdConstant.CMD_SEND_AFTER);
					acService.update(ac);
					map.put("result", "success");
					
					
				} else {
					int companyId = OnLine.getCurrentUserDetails().getCompanyId();
					ac.setCompanyId(companyId);
					ac.setParamType(ac.getBodyType());
					//ac.setCmd(CmdConstant.CMD_SEND_AFTER);
					acService.insert(ac);
					map.put("result", "success");
				}
				
			//	this.service.saveCardInterface(cif);
			}
			//RespResult.getSuccess().writeToResponse(response);
		} catch (Exception e) {
			map.put("result", "error");
			e.printStackTrace();
		}
		
		return map;
	}
	
	/**
	 * 更新页面
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/updateInterface", method = RequestMethod.GET)
	public String updateInterface(HttpServletRequest request, ModelMap model) {
		int id = Integer.parseInt(request.getParameter("id") == null ? "0"
				: request.getParameter("id"));
		String status = request.getParameter("status") == null ? "0"
				: request.getParameter("status");
		String isDataSign = request.getParameter("isDataSign") == null ? "1"
				: request.getParameter("isDataSign");
		
		try {
			ActionConfig entity = this.getHibernateService().get(id);
		//	List<Company> list = cService.getCompanys();
		//	model.put("companys", list);
			model.put("entity", entity);
			model.put("id", "" + id);
			model.put("cid", "" + entity.getCompanyId());
			model.put("status", status);
			model.put("isDataSign", isDataSign);
			this.updatePageInit(entity, request, model);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return this.getPrefix() + "/" + this.getEditPage();
	}

	/**
	 * 更新
	 * 
	 * @param entity
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/updateInterface", method = RequestMethod.POST)
	public void updateInterface(ActionConfig ac, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		try {
			// int id = Integer.parseInt(request.getParameter("id") == null ?
			// "0" : request.getParameter("id"));
//			String id = request.getSession().getAttribute("id") == null ? ""
//					: (String) request.getSession().getAttribute("id");
//			
//			
//			String hql = "update ActionConfig set status=?,companyId=?,companyName=?,cmd=?,tpl=?,paramType=?,interfaceUrl=? where id=?";
			acService.update(ac);
		//	request.getSession().removeAttribute("id");
			RespResult.getSuccess().writeToResponse(response);
		} catch (Exception e) {
			RespResult.getError(e).writeToResponse(response);
		}
	}
	
	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/deleteInterface")
	@ResponseBody
	public RespResult deleteInterface(HttpServletRequest request) {
		try {
			int id = Integer.parseInt(request.getParameter("id") == null ? "0"
					: request.getParameter("id"));
			String hql = "delete from ActionConfig where id=?";
			this.getHibernateService().executeUpdate(hql, id);
			return RespResult.getSuccess();
		} catch (Exception e) {
			return RespResult.getError(e);
		}
	}
	
	@Override
	protected String getPrefix() {
		return "/setting/thirdParty";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
	//	params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		params.put("cmd", CmdConstant.CMD_SEND_DATA);
		return params;
	}

	@Override
	protected HibernateDAO<Integer, ActionConfig> getHibernateService() {
		return acService;
	}
}
