package cn.jesong.webcall.cuour.secret;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LocalTQFactory extends SecretFactory {

	private final static Log _logger = LogFactory.getLog(LocalTQFactory.class);

	private static CardAuxiliaryInterface auxiliary;

	public LocalTQFactory() {
		auxiliary = new CardTQImpl();
	}

	@Override
	public CardAuxiliaryInterface getGenerator() {
		return this.auxiliary;
	}

}
