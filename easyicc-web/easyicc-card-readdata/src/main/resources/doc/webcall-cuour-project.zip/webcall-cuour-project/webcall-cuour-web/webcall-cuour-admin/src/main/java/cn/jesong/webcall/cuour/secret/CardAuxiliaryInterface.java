package cn.jesong.webcall.cuour.secret;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public interface CardAuxiliaryInterface {
	
	public String generatorKeyStr(ActionConfig config) throws Exception;
	
}
