package cn.jesong.webcall.cuour.common;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import cn.jesong.webcall.cuour.weixin.bean.AccessToken;
import cn.jesong.webcall.cuour.weixin.bean.UserInfo;
import cn.jesong.webcall.cuour.weixin.oauth.Oauth;
import cn.jesong.webcall.cuour.weixin.util.HttpKit;

import com.alibaba.fastjson.JSONObject;
public class CommonOauth {

	private static final String USER_INFO_URI = "https://api.weixin.qq.com/sns/userinfo";
	public static long time = 60 * 60 * 1000; // 1.5小时
	public static String errorInfo = "";

	public static String getUserCodeUrl(String jsonStr) {
		Oauth auth = new Oauth();
		String code = "";
		try {
			code = auth.getCode();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return code;
	}

	/**
	 * 获得 用户 访问的令牌对象
	 * 
	 * @param code
	 * @return
	 */
	public static AccessToken getUserAccessToken(String code) {
		AccessToken accessToken = null;
		try {
			Oauth auth = new Oauth();
			String jsonStr = auth.getToken(code);
			accessToken = parseAccessToken(jsonStr);
			if(accessToken == null || accessToken.getOpenid() == null || "".equals(accessToken.getOpenid())) {
				for(int i = 0; i < 3; i++) {
					Thread.sleep(1000);
					jsonStr = "";
					jsonStr = auth.getToken(code);
					accessToken = parseAccessToken(jsonStr);
					if(accessToken != null && accessToken.getOpenid() != null && !"".equals(accessToken.getOpenid())) {
						break;
					}
				}
			}
		} catch (Exception e) {
			System.out.println("getUserAccessToken：openid获取失败");
		}
		return accessToken;
	}

	public static AccessToken parseAccessToken(String jsonStr) throws Exception {
		AccessToken accessToken = null;
		if (StringUtils.isNotEmpty(jsonStr)) {
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if (obj.get("errcode") != null) {
				accessToken = null;
			} else {
				accessToken = JSONObject.toJavaObject(obj, AccessToken.class);
			}
		}
		return accessToken;
	}

	public static UserInfo getUserInfo(String accessToken, String openid) throws Exception {
		Map<String, String> params = new HashMap<String, String>();
		params.put("access_token", accessToken);
		params.put("openid", openid);
		String jsonStr = HttpKit.get(USER_INFO_URI, params);
		if (StringUtils.isNotEmpty(jsonStr)) {
			JSONObject obj = JSONObject.parseObject(jsonStr);
			if (obj.get("errcode") != null) {
				throw new Exception(obj.getString("errmsg"));
			}
			UserInfo user = JSONObject.toJavaObject(obj, UserInfo.class);
			return user;
		}
		return null;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		StringBuffer jsonSb = new StringBuffer(100);
		jsonSb
				.append("{\"access_token\":\"OezXcEiiBSKSxW0eoylIeLoUQfHLA2Hg6lev4w0RkjFmQjW2Ng0sJzBsNAM4auBGwQFNeVGlofDjTkiuty7xiM9c_WfDh8BKeHfBKZ3kBb8h6nhH8BLITXCmRDe3Mz3oHCVl4X9EBCRmLwUJeVUmiw\",");
		jsonSb
				.append("			\"expires_in\":7200,\"refresh_token\":\"OezXcEiiBSKSxW0eoylIeLoUQfHLA2Hg6lev4w0RkjFmQjW2Ng0sJzBsNAM4auBG_9JvhPPuDYYziDwr5QsjCNoD0q1CJSZCsiArVBodxJVS81IMZGY3mBi5bNyGNoWSMEZiWKo3A1oijYPhHnVn7Q\",\"openid\":\"owHN-uCohJurdL5SG91vnLU_7Bv8\",\"scope\":\"snsapi_userinfo\"}");

		@SuppressWarnings("unused")
		AccessToken accessToken = null;
		try {
			accessToken = CommonOauth.parseAccessToken(jsonSb.toString());
			// if (accessToken != null) {
			// System.out.println(" token : " + accessToken.getAccess_token());
			// System.out.println(" openid : " + accessToken.getOpenid());
			// }

			// accessToken =
			// CommonOauth.freshUserAccessToken(accessToken.getRefresh_token());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
