package cn.jesong.webcall.cuour.service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.core.client.CoreClient;
import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.logic.UserMgrException;
import cn.jesong.webcall.object.UserSession;

/**
 * 过滤分配客服
 * 
 * @author Administrator
 *
 */
@Service
public class FiltrationSaleUserService {

	private final static Log _logger = LogFactory.getLog(FiltrationSaleUserService.class);

	@Autowired
	private CacheFactory cacheFactory;

	/**
	 * 
	 * @param rule         名片分配规则配置
	 * @param saleUser     销售
	 * @param callbackTime 回电时间
	 * @param createTime   创建时间
	 * @return
	 */
	public boolean filtration(CardRule rule, SaleUser saleUser, Date callbackTime, Date createTime, Set<String> onlineIds) {

		//如果开启销售在线
		if (rule.getNeedOnLine() == 1) {
			// 检查当前在线客服集合中是否存在当前客服saleUser
			if (onlineIds.isEmpty())
				return false;

			if (!onlineIds.contains(saleUser.getUserId()))
				return false;
		}
		
		Date time = callbackTime;
		if(callbackTime == null) {
			time = createTime;
		}else {
			time = createTime.getTime() > callbackTime.getTime() ? createTime : callbackTime;
		}
		
		//如果开启排班
		if (rule.getNeedScheeduling() == 1) {
			
			// 检查是不是在排班
			//if (!this.cacheFactory.getScheduingCache().isInWorkTime(saleUser.getCompanyId(), saleUser.getUserId(),callbackTime == null ? callbackTime : callbackTime))
			if (!this.cacheFactory.getScheduingCache().isInWorkTime(saleUser.getCompanyId(), saleUser.getUserId(),time))
				return false;
		}

		// 分配权重大于0，并且是否达到最大分配量
		//if (saleUser.getAllocationWeight() < 1 || !saleUser.canAllocationCard(callbackTime, rule.getAllocationSize(),rule.getTimeInterval() * 60 * 1000, rule.getMaxAllocationSize()))
		if (saleUser.getAllocationWeight() < 1 || !saleUser.canAllocationCard(time, rule.getAllocationSize(),rule.getTimeInterval() * 60 * 1000, rule.getMaxAllocationSize()))
			return false;

		return true;
	}

	/**
	 * 获取当前在线销售集合
	 * 
	 * @param companyId
	 * @return
	 */
	public Set<String> getOnlieIds(int companyId, CardRule cardRule) {
		Set<String> onlineIds = new HashSet<String>();
		try {
			List<UserSession> sessions = CoreClient.getUserMgr(companyId).getCustomers(companyId);
			for (UserSession s : sessions) {
				// 在线分配模式 0 在线分配(只有在线的状态可以进行名片的分配) 1 在线分配(在线.忙碌.离开的状态可以进行名片的分配)
				if (cardRule.getIsOnlineAllocation() == 0) {
					if (s.getStatus() == UserSession.STATUS_ONLINE
							&& (s.getRunningStatus() == 1 || s.getRunningStatus() == 0)) {
						onlineIds.add(s.getUserId());
					}
				} else {
					if (s.getStatus() == UserSession.STATUS_ONLINE) {
						onlineIds.add(s.getUserId());
					}
				}
			}
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}
		return onlineIds;
	}

}
