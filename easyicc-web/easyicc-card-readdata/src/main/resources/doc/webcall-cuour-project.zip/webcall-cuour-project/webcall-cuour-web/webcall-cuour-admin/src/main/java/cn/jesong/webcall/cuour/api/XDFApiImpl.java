package cn.jesong.webcall.cuour.api;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSON;
import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.XdfBean;
import cn.jesong.webcall.cuour.entity.XdfRecourceBean;
import cn.jesong.webcall.cuour.secret.SecretFactory;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.DateUtil;
import cn.jesong.webcall.cuour.util.HttpClientUtil;

/**
 * 新东方接口
 * @author zhanglu
 *
 */
public class XDFApiImpl implements ThirdApiInterface {

	private final static Log logger = LogFactory.getLog(XDFApiImpl.class);

	/**
	 * ActionConfig 配置信息
	 * VisitorCardData 名片数据模型
	 * template tpl模板
	 */
	@Override
	public String httpPost(ActionConfig ac, String template) throws Exception{

		if (ac == null) {
			logger.info("----------------------------->推送失败，第三方接口配置信息为空!");
			return null;
		}
		String url = ac.getInterfaceUrl();
		String res = null;

		if (StringUtils.isEmpty(url)) {
			logger.info("----------------------------->推送失败，第三方接口配置信息URL为空!");
			return res;
		}
		SecretFactory instance = SecretFactory.getInstance(ac.getThirdPlatform());
		if (instance == null) {
			logger.info("----------------------------->未找到秘钥工厂类型！");
		}
		String token = instance.getGenerator().generatorKeyStr(ac);
		if (StringUtils.isEmpty(token)) {
			logger.info("----------------------------->推送失败，第三方接口token获取失败!");
			return res;
		}

		String charset = CardUtil.getValue(ac.getConfig(), "charset");
		if (charset == null) {
			charset = "UTF-8";
		}

		String appId = CardUtil.getValue(ac.getConfig(), "appId");
		String secret = CardUtil.getValue(ac.getConfig(), "secret");
		String method = CardUtil.getValue(ac.getConfig(), "method");
		String timestamp = DateUtil.getCurrentTime();
		
		StringBuffer str = new StringBuffer();
		str.append(secret);
		str.append("appId").append(appId);
		str.append("method").append(method);
		str.append("timestamp").append(timestamp);
		str.append(secret);
		//规则：转大写(MD5加密（秘钥+appId+appId对应的值+method+method对应的值+timestamp+timestamp对应的值+秘钥）) 例如： 
		String sign = DigestUtils.md5Hex(str.toString()).toUpperCase();

		XdfBean x = new XdfBean();
		x.setAppId(appId);
		x.setMethod(method);
		x.setSign(sign);
		x.setTimestamp(timestamp);
		
		XdfRecourceBean recourceBean = JSON.parseObject(template,XdfRecourceBean.class);
		List<XdfRecourceBean> list = new ArrayList<XdfRecourceBean>();
		list.add(recourceBean);
		x.setRecourceList(list);

		logger.info("----------------------------->XDF提交数据：" + JSON.toJSONString(x));
		res = HttpClientUtil.httpPost(url, JSON.toJSONString(x), charset);
		logger.info("----------------------------->XDF提交数据返回值：" + res);
		return res;
	}
}
