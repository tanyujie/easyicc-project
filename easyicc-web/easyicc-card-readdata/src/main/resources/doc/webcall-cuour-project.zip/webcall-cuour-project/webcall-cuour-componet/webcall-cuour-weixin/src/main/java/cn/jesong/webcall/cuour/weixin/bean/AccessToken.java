package cn.jesong.webcall.cuour.weixin.bean;
/**
 * 获取code 后，请求以下链接获取access_token： 
     https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=COD 
     E&grant_type=authorization_code 
 * 
 * {"access_token":"OezXcEiiBSKSxW0eoylIeLoUQfHLA2Hg6lev4w0RkjFPdrogUdi_VX4nCokSn5eE0I7xBrKVPhDdNu3yRAfFZwwiKgJOEYphgQPz4zsCLexyjwTahE2TMG0ezgbGjNPHJnibHntv8-kmFq4H0zY5MQ",
			"expires_in":7200,"refresh_token":"OezXcEiiBSKSxW0eoylIeLoUQfHLA2Hg6lev4w0RkjFPdrogUdi_VX4nCokSn5eEelyCyzIP31f0svIZkXqawoO6zQDvoah4UAeTeKj43lZ_HWRPhE6g7Tar_nC9LsMATeiHCRHvr005A-16YX9-zQ","openid":"owHN-uF5cCOao8O0sM-kSGyoLd44","scope":"snsapi_userinfo"}
 * @author Administrator
 *
 */
public class AccessToken {

	private String access_token;
	private String refresh_token;
	private long expires_in;
	private String scope;
	private String openid;

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String accessToken) {
		access_token = accessToken;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refreshToken) {
		refresh_token = refreshToken;
	}

	public long getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(long expiresIn) {
		expires_in = expiresIn;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

}
