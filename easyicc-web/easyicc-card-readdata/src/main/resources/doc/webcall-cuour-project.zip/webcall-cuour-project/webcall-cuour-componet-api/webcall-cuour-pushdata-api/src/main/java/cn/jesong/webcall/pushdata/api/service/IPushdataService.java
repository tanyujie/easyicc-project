package cn.jesong.webcall.pushdata.api.service;

import cn.jesong.webcall.cuour.cache.CacheDataLoader;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.event.SettingChangeEvent;
import cn.jesong.webcall.pushdata.api.domain.DistributionResult;

import java.util.List;

/**
 * 推送提供删除本地缓存接口
 */
public interface IPushdataService  extends CacheDataLoader {


    /**
     * 	删除本地缓存接口
     * @param companyId
     * @throws Exception
     */
    DistributionResult removeLocalCacheByCompanyId(Integer companyId);
    
    /**
     * 	清除本地缓存
     * @param companyId
     * @param userId
     */

    void clearCache(int companyId,String userId);

   


}
