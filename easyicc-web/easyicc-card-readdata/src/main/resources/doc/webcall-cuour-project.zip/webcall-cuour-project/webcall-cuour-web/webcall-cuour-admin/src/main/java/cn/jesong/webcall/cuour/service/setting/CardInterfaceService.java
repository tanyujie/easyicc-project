package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.jesong.webcall.cuour.entity.CardInterface;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class CardInterfaceService extends SettingService<Integer, CardInterface> {
	
	@Override
	protected Class<CardInterface> getEntityClass() {
		return CardInterface.class;
	}
	
	@Override
	protected String getTemplateQuerySQL() {
		return "from CardInterface where / companyId = {companyId} / and / isDelete = {isDelete} / order by id desc";
	}
	
	@Transactional
	public void saveCardInterface(CardInterface cif) {
		cif.setUrl("");
		int id = this.save(cif);
		String url = "http://api.easyliao.com/data/api/invoke?companyId="+
				cif.getCompanyId()+"&interfaceId="+id+"&token=" + cif.getToken()+"&cmd=insert";
		cif.setUrl(url);
		this.saveOrUpdate(cif);
	}
}
