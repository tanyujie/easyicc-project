package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.*;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.cache.entity.SchedulingTime;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocalCacheFactory implements CacheFactory{
	
	private final static Log _logger = LogFactory.getLog(LocalCacheFactory.class);
	
	private final static SimpleDateFormat formatter2 = new SimpleDateFormat("yyyyMMdd");
	
	private Map<Integer, String> loadFlags = new HashMap<Integer, String>();
	
	private final LockCache lockCache;
	
	private final CardRuleCache cardRuleCache;
	
	private final SubjectUserCache subjectUserCache;
	
	private final ScheduingCache scheduingCache;
	
	private final ActionConfigCache acCache;
	
	public LocalCacheFactory(){
		lockCache = new LocalLockCache(); 
		cardRuleCache = new LocalCardRuleCache();
		subjectUserCache = new LocalSubjectUserCache();
		scheduingCache = new LocalScheduingCache();
		acCache = new LocalActionConfigCache();
	}

	@Override
	public void checkInit(int companyId, CacheDataLoader loader, String time) {
		checkInit(companyId, loader, time,false);
	}
	@Override
	public void checkInit(int companyId, CacheDataLoader loader, String time,boolean isUserReset) {
		synchronized(this){
			//需要判断缓存数据是否为当天数据
			boolean reloadFlag = false;

			if(this.loadFlags.containsKey(companyId)){
				String cachetime = this.loadFlags.get(companyId);
				//缓存数据过期
				if(!time.equals(cachetime)||isUserReset){
					this.remove(companyId);
					reloadFlag = true;

				}
			}else{

				reloadFlag = true;
			}
			//需要重新加载数据
			if(reloadFlag){
				_logger.info("准备初始化["+companyId+"]缓存....");
				_logger.info("准备初始化["+companyId+"]缓存....");
				this.loadFlags.put(companyId, time);
				this.lockCache.init(companyId);
				long _t1 = System.currentTimeMillis();
				this.cardRuleCache.init(loader.getCardRule(companyId));
				long _t2 = System.currentTimeMillis();
				_logger.info("初始化["+companyId+"]CardRule:"+(_t2-_t1)+"ms");
				List<SaleUser> sales = loader.getSaleUser(companyId, time,isUserReset);
				long _t3 = System.currentTimeMillis();
				_logger.info("初始化["+companyId+"]getSaleUser:"+(_t3-_t2)+"ms");
				this.subjectUserCache.init(companyId, sales/*, loader.getAllocationedCards(companyId, time)*/);
				long _t4 = System.currentTimeMillis();
				_logger.info("初始化["+companyId+"]initSaleUserCache:"+(_t4-_t3)+"ms");
				List<SchedulingTime> schedulingTimes = loader.getSchedulingTimes(companyId, time);
				long _t5 = System.currentTimeMillis();
				_logger.info("初始化["+companyId+"]getSchedulingTimes:"+(_t5-_t4)+"ms");
				this.scheduingCache.init(companyId, schedulingTimes);
				long _t6 = System.currentTimeMillis();
				_logger.info("初始化["+companyId+"]initSchedulingTimesCache:"+(_t6-_t5)+"ms");
//				this.acCache.init(loader.getActionConfig(companyId));
				_logger.info("初始化["+companyId+"]缓存结束....");
				
				/*this.loadFlags.put(companyId, time);
				this.lockCache.init(companyId);
				this.cardRuleCache.init(loader.getCardRule(companyId));
				this.subjectUserCache.init(companyId, loader.getSaleUser(companyId, time,isUserReset), loader.getAllocationedCards(companyId, time));
				this.scheduingCache.init(companyId, loader.getSchedulingTimes(companyId, time));*/
//				this.acCache.init(loader.getActionConfig(companyId));
				_logger.info("初始化["+companyId+"]缓存结束....");
			}
			//重新装载完，将变量设置为false
//			reloadReset.setIsReset(false);
//			this.loadFlags.put(companyId, reloadReset);
		}
	}
	
	@Override
	public void remove(int companyId) {
		synchronized(this){
			_logger.info("准备移除["+companyId+"]缓存....");
			this.loadFlags.remove(companyId);
			this.lockCache.remove(companyId);
			this.cardRuleCache.remove(companyId);
			this.subjectUserCache.remove(companyId);
			this.scheduingCache.remove(companyId);
			_logger.info("移除["+companyId+"]缓存结束....");
		}
	}

	@Override
	public LockCache getLockCache() {
		return this.lockCache;
	}

	@Override
	public CardRuleCache getCardRuleCache() {
		return this.cardRuleCache;
	}

	@Override
	public SubjectUserCache getSubjectUserCache() {
		return this.subjectUserCache;
	}

	@Override
	public ScheduingCache getScheduingCache() {
		return this.scheduingCache;
	}

	@Override
	public ActionConfigCache getActionConfigCache() {
		return this.acCache;
	}

}
