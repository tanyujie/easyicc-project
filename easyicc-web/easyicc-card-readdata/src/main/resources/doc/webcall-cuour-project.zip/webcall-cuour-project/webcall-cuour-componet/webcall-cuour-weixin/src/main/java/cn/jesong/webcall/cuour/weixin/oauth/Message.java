/**
 * 微信公众平台开发模式(JAVA) SDK
 * (c) 2012-2014 ____′↘夏悸 <wmails@126.cn>, MIT Licensed
 * http://www.jeasyuicn.com/wechat
 */
package cn.jesong.webcall.cuour.weixin.oauth;


import cn.jesong.webcall.cuour.weixin.bean.Article;
import cn.jesong.webcall.cuour.weixin.bean.Articles;
import cn.jesong.webcall.cuour.weixin.bean.TemplateData;
import cn.jesong.webcall.cuour.weixin.util.HttpKit;

import com.alibaba.fastjson.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * 客服消息接口
 * 
 * @author L.cm
 * @date 2013-11-5 下午3:32:30
 * @description 
 *              当用户主动发消息给公众号的时候（包括发送信息、点击自定义菜单、订阅事件、扫描二维码事件、支付成功事件、用户维权），微信将会把消息数据推送给开发者
 *              ，开发者在一段时间内（目前修改为48小时）可以调用客服消息接口，通过POST一个JSON数据包来发送消息给普通用户，
 *              在48小时内不限制发送次数。此接口主要用于客服等有人工消息处理环节的功能，方便开发者为用户提供更加优质的服务。
 */
public class Message {

	private static final String MESSAGE_URL = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=";
	private static final String UPLOADNEWS_URL = "https://api.weixin.qq.com/cgi-bin/media/uploadnews?access_token=";
//	private static final String MASS_SENDALL_URL = "https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token=";
//	private static final String MASS_SEND_URL = "https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token=";
	private static final String MASS_DELETE_URL = "https://api.weixin.qq.com//cgi-bin/message/mass/delete?access_token=";
	private static final String TEMPLATE_SEND_URL = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=";

	private static final String MATERIAL_LIST_URL = "https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token=";

	/**
	 * 获取素材库 列表
	 * 
	 * @author zws
	 * @param accessToken
	 * @param message
	 * @return
	 * @throws Exception
	 */
	private String getMaterials(String accessToken, Map<String, Object> message) throws Exception {
		String result = HttpKit.post(MATERIAL_LIST_URL.concat(accessToken), JSONObject.toJSONString(message));
		return result;
	}

	/**
	 * 获取素材库 图片列表
	 * 
	 * @author zws
	 * @param accessToken
	 * @return
	 * @throws Exception
	 */
	public String getImageMaterial(String accessToken) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		json.put("type", "image");
		json.put("offset", 0);
		json.put("count", 100);
		String result = getMaterials(accessToken, json);
		return result;
	}

	/**
	 * 发送客服消息
	 * 
	 * @param accessToken
	 * @param message
	 * @return
	 * @throws Exception
	 */
	private String sendMsg(String accessToken, Map<String, Object> message) throws Exception {
		String result = HttpKit.post(MESSAGE_URL.concat(accessToken), JSONObject.toJSONString(message));
		return result;
	}

	/**
	 * 发送文本客服消息
	 * 
	 * @param openId
	 * @param text
	 * @throws Exception
	 */
	public String sendText(String accessToken, String openId, String text) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		Map<String, Object> textObj = new HashMap<String, Object>();
		textObj.put("content", text);
		json.put("touser", openId);
		json.put("msgtype", "text");
		json.put("text", textObj);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 发送图片消息
	 * 
	 * @param accessToken
	 * @param openId
	 * @param media_id
	 * @return
	 * @throws Exception
	 */
	public String SendImage(String accessToken, String openId, String media_id) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		Map<String, Object> textObj = new HashMap<String, Object>();
		textObj.put("media_id", media_id);
		json.put("touser", openId);
		json.put("msgtype", "image");
		json.put("image", textObj);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 发送语言回复
	 * 
	 * @param accessToken
	 * @param openId
	 * @param media_id
	 * @return
	 * @throws Exception
	 */
	public String SendVoice(String accessToken, String openId, String media_id) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		Map<String, Object> textObj = new HashMap<String, Object>();
		textObj.put("media_id", media_id);
		json.put("touser", openId);
		json.put("msgtype", "voice");
		json.put("voice", textObj);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 发送视频回复
	 * 
	 * @param accessToken
	 * @param openId
	 * @param media_id
	 * @param title
	 * @param description
	 * @return
	 * @throws Exception
	 */
	public String SendVideo(String accessToken, String openId, String media_id, String title, String description)
			throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		Map<String, Object> textObj = new HashMap<String, Object>();
		textObj.put("media_id", media_id);
		textObj.put("title", title);
		textObj.put("description", description);

		json.put("touser", openId);
		json.put("msgtype", "video");
		json.put("video", textObj);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 发送音乐回复
	 * 
	 * @param accessToken
	 * @param openId
	 * @param musicurl
	 * @param hqmusicurl
	 * @param thumb_media_id
	 * @param title
	 * @param description
	 * @return
	 * @throws Exception
	 */
	public String SendMusic(String accessToken, String openId, String musicurl, String hqmusicurl,
			String thumb_media_id, String title, String description) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		Map<String, Object> textObj = new HashMap<String, Object>();
		textObj.put("musicurl", musicurl);
		textObj.put("hqmusicurl", hqmusicurl);
		textObj.put("thumb_media_id", thumb_media_id);
		textObj.put("title", title);
		textObj.put("description", description);

		json.put("touser", openId);
		json.put("msgtype", "music");
		json.put("music", textObj);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 发送图文回复
	 * 
	 * @param accessToken
	 * @param openId
	 * @param articles
	 * @return
	 * @throws Exception
	 */
	public String SendNews(String accessToken, String openId, List<Articles> articles) throws Exception {
		Map<String, Object> json = new HashMap<String, Object>();
		json.put("touser", openId);
		json.put("msgtype", "news");
		json.put("voice", articles);
		String result = sendMsg(accessToken, json);
		return result;
	}

	/**
	 * 上传图文消息素材
	 * 
	 * @param accessToken
	 * @param articles
	 * @return
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws IOException
	 */
	public JSONObject uploadnews(String accessToken, List<Article> articles) throws IOException, ExecutionException,
			InterruptedException {
		Map<String, Object> json = new HashMap<String, Object>();
		json.put("articles", articles);
		String result = HttpKit.post(UPLOADNEWS_URL.concat(accessToken), JSONObject.toJSONString(json));
		if (StringUtils.isNotEmpty(result)) {
			return JSONObject.parseObject(result);
		}
		return null;
	}

	/**
	 * 删除群发
	 * 
	 * @param accessToken
	 * @param msgid
	 * @return
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws IOException
	 */
	public JSONObject massSend(String accessToken, String msgid) throws IOException, ExecutionException,
			InterruptedException {
		Map<String, Object> json = new HashMap<String, Object>();
		json.put("msgid", msgid);
		String result = HttpKit.post(MASS_DELETE_URL.concat(accessToken), JSONObject.toJSONString(json));
		if (StringUtils.isNotEmpty(result)) {
			return JSONObject.parseObject(result);
		}
		return null;
	}

	/**
	 * 发送模板消息
	 * 
	 * @param accessToken
	 * @param data
	 * @return
	 * @throws IOException
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	public JSONObject templateSend(String accessToken, TemplateData data) throws IOException, ExecutionException,
			InterruptedException {
		String result = HttpKit.post(TEMPLATE_SEND_URL.concat(accessToken), JSONObject.toJSONString(data));
		if (StringUtils.isNotEmpty(result)) {
			return JSONObject.parseObject(result);
		}
		return null;
	}
	
	/**
	 * 发送 模板 消息
	 * 
	 * @param openId
	 * @param templateId
	 * @param content
	 * @param url
	 * @return
	 */
	public boolean sendTemplate2(String openId, String content, String url, String accessToken, int type, String date) {
		boolean result = false;
		try {
			String templateId = "I0I4ulOhTTcrMrfGkbEn14HOU2Bqfzi_JPXpO46pyyg";
			int sizeLimit = 175;
			
			content = content.replaceFirst("(.*)【(.*)】(.*)", "$2");
			content = content.length() > sizeLimit ? content.substring(0, sizeLimit) + "..." : content;
			TemplateData data = new TemplateData(openId, templateId);
			
			data.getData().addItem("keyword1", content);
			data.getData().addItem("keyword2", "待办");
			data.getData().addItem("remark", "请尽快处理!");
			
			if (StringUtils.isNotEmpty(url)) {
				data.setUrl(url);
			}
		//    data.getData().addItem("remark", content);
			JSONObject obj = templateSend(accessToken, data);
			result = sendResultProcess(obj);
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	public boolean sendTemplate(String openId, String jobName, String requirement, String url, String accessToken) {
		boolean result = false;
		try {
			String templateId = "I0I4ulOhTTcrMrfGkbEn14HOU2Bqfzi_JPXpO46pyyg";
			int sizeLimit = 175;
			jobName = StringUtils.trim(jobName);
			jobName = jobName.length() > sizeLimit ? jobName.substring(0, sizeLimit) + "..." : jobName;
			
			requirement = StringUtils.trim(requirement);
			requirement = requirement.length() > 300 ? requirement.substring(0, 300) + "..." : requirement;
			TemplateData data = new TemplateData(openId, templateId);
			if (StringUtils.isNotEmpty(url)) {
				data.setUrl(url);
			}
			// data.getData().addItem("first", "事件预警通知");
			data.getData().addItem("keyword1", jobName);
			data.getData().addItem("keyword2", "在线网评协同管理平台");
			data.getData().addItem("keyword3", DateFormatUtils.format(new Date(), "yyyy-MM-dd HH:mm"));
			data.getData().addItem("keyword4", requirement);
		  //  data.getData().addItem("remark", "");
			JSONObject obj = templateSend(accessToken, data);
			result = sendResultProcess(obj);
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	public boolean sendNotice(String openId, String jobName, String requirement, String url, String accessToken) {
		boolean result = false;
		try {
			String templateId = "JJiSm3yaVnxCQapFn0DtmaZ-J7vhhLRAu381wVPn39Q";
			int sizeLimit = 175;
			jobName = StringUtils.trim(jobName);
			jobName = jobName.length() > sizeLimit ? jobName.substring(0, sizeLimit) + "..." : jobName;
			
			requirement = StringUtils.trim(requirement);
			requirement = requirement.length() > 300 ? requirement.substring(0, 300) + "..." : requirement;
			TemplateData data = new TemplateData(openId, templateId);
			if (StringUtils.isNotEmpty(url)) {
				data.setUrl(url);
			}
			// data.getData().addItem("first", "事件预警通知");
			data.getData().addItem("keyword1", jobName);
		//	data.getData().addItem("keyword2", "在线网评协同管理平台");
			data.getData().addItem("keyword2", DateFormatUtils.format(new Date(), "yyyy-MM-dd HH:mm"));
			data.getData().addItem("keyword3", requirement);
		  //  data.getData().addItem("remark", "");
			JSONObject obj = templateSend(accessToken, data);
			result = sendResultProcess(obj);
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	/**
	 * 通过 openId，发送绑定通知
	 * 
	 * @param openId
	 * @param content
	 * @return
	 */
	public boolean sendBindNotice(String token, String openId, String content) {
		boolean result = false;
		try {
			String templateId = "dfjvKWpT7LZFd1LAwLlY2-joks4bWB1r6WcrNslkQdE";
			JSONObject conentObj = JSONObject.parseObject(content);
			String first = conentObj.getString("first");
			String userName = conentObj.getString("userName");
			String userType = conentObj.getString("userType");
			
			TemplateData data = new TemplateData(openId, templateId);
			
			data.getData().addItem("first", first);
			data.getData().addItem("keyword1", userName);
			data.getData().addItem("keyword2", "用户类型：" + userType + ",绑定时间：" + DateFormatUtils.format(new Date(), "MM月dd日 HH:mm"));
			
			JSONObject obj = templateSend(token, data);
			result = sendResultProcess(obj);
		} catch (Exception e) {
			result = false;
		}
		return result;
	}
	
	/***
	 * 发送后 返回 acceesstoken 错误，则刷新 token
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	private static boolean sendResultProcess(JSONObject obj) throws Exception {
		boolean result = false;
		if (obj != null && obj.get("errmsg") != null && obj.get("errmsg").equals("ok")) {
			result = true;
		} else {
		//	int errcode = obj.getInteger("errcode");
			// access_token无效 ,重新 刷新token
		}
		return result;
	}
}
