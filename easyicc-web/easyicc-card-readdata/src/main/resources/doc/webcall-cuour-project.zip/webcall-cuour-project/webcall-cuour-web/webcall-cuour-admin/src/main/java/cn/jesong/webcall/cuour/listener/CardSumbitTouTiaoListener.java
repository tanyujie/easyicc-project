package cn.jesong.webcall.cuour.listener;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.service.OcpcService;
import cn.jesong.webcall.cuour.service.TouTiaoSubmitService;;

@Component
public class CardSumbitTouTiaoListener implements AllocationListener{
	
	private final static Log logger = LogFactory
			.getLog(CardSumbitTouTiaoListener.class);
	
	@Autowired
	private TouTiaoSubmitService touTiaoSubmitService;
	
	@Autowired
	private OcpcService ocpcService;
	
	@Autowired
	private CacheFactory cacheFactory;

	@Override
	public void before(Card card) {
		// TODO Auto-generated method stub
		try {
			CardRule cardRule = cacheFactory.getCardRuleCache().getCardRule(card.getCompanyId());
			if(cardRule.getNeedSumbitToutiao()==1){
				Map<String, String> match = ocpcService.match(card.getFirstUrl(), card.getChatUrl(), card.getReferUrl());
				touTiaoSubmitService.submit(card.getCreateTime(), match);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void after(Card card, boolean allocation) {
		// TODO Auto-generated method stub
		
	}

}
