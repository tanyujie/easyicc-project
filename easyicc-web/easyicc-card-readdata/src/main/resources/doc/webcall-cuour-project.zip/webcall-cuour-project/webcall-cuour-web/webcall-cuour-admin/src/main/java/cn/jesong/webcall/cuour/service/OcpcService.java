package cn.jesong.webcall.cuour.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;


@Service
public class OcpcService {
	
	private final static Log logger = LogFactory
			.getLog(OcpcService.class);
	
	public Map<String, String> match(String firstURL, String chatURL, String referURL) {
		Map<String, String> params = this.match(firstURL);
		if(params == null || params.isEmpty()){
			params = this.match(chatURL);
		}
		if(params == null || params.isEmpty()){
			params = this.match(referURL);
		}
		logger.info("获取的params的值为："+params);
		return params == null ? new HashMap<String, String>() : params;
	}
	
	public Map<String, String> match(String url){
		Map<String, String> info = null;
		Map<String, String> params = parseParams(url);
		//adid=__AID__&creativeid=__CID__&creativetype=__CTYPE__&clickid=__CLICKID__
		String adid = params.get("adid");
		String creativeid = params.get("creativeid");
		String creativetype = params.get("creativetype");
		String clickid = params.get("clickid");
		if(StringUtils.isNotBlank(adid) && StringUtils.isNotBlank(creativeid) && StringUtils.isNotBlank(creativetype) && StringUtils.isNotBlank(clickid)){
			info = new HashMap<String, String>();
			info.put("ocpc_platform", String.valueOf(this.getPlatform()));
			info.put("ocpc_toutiao_adid", adid);
			info.put("ocpc_toutiao_creativeid", creativeid);
			info.put("ocpc_toutiao_creativetype", creativetype);
			info.put("ocpc_toutiao_clickid", clickid);
			info.put("ocpc_toutiao_link", url);
		}
		return info;
	}

	
	private Map<String, String> parseParams(String uri){
		Map<String, String> params = new HashMap<String, String>();
		if(uri != null && uri.indexOf("?")>0){
			String query = uri.substring(uri.indexOf("?") + 1);
			String[] pairs = query.split("&");
			for(String pair : pairs){
				String[] kv = pair.split("=");
				if(kv.length > 1){
					params.put(kv[0], kv[1]);
				}
			}
		}
		return params;
	}
	
	public int getPlatform() {
		return 2;
	}
}
