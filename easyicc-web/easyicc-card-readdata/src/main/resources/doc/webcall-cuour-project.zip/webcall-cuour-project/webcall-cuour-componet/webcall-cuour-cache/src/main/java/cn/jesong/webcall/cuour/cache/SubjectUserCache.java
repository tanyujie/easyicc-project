package cn.jesong.webcall.cuour.cache;

import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;

import java.util.List;

public interface SubjectUserCache {
	
	public List<SaleUser> getAllSaleUsers(int companyId);

	public List<SaleUser> getUsersOfSubjectId(int companyId, int subjectID, int schoolId);

	public void allocationCard(SaleUser user, Card card);
	
	public void backCard(int companyId, int cardId, String userId);
	
	public void finished(int companyId, int cardId, String userId, boolean isSaleCard);
	
	public void userAllocationCard(int companyId, Card card, String userId);
	
	public void remove(int companyId);
	
	public void init(int companyId, List<SaleUser> users/*, List<Card> cards*/);

	public void expired(int companyId, int cardId, String userId);

	public SaleUser getUser(int companyId, String userId);
	
}
