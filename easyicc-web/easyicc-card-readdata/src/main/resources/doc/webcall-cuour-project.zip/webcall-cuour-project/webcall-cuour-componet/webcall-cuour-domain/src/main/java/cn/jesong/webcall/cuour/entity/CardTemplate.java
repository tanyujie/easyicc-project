package cn.jesong.webcall.cuour.entity;//package cn.jesong.webcall.cn.jesong.webcall.cuour.entity;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//
///**
// * 名片模板
// * @author hanjianxin
// *
// */
//@Entity
//@Table(name = "js_card_template")
//public class CardTemplate {
//	/**
//	 * id
//	 */
//	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_card_template_id_seq")
//	@SequenceGenerator(name = "js_card_template_id_seq", sequenceName = "js_card_template_id_seq", allocationSize = 1)
//	private int id;
//	
//	/**
//	 * 接口地址
//	 */
//	@Column(name = "url", nullable = false)
//	private String url;
//	
//	/**
//	 * 结构体
//	 */
//	@Column(name = "body", nullable = false)
//	private String body;
//	
//	/**
//	 * 结构体
//	 */
//	@Column(name = "param_type", nullable = false)
//	private String paramType;
//	
//	/**
//	 * 状态0：关闭,1：启用
//	 */
//	@Column(name = "status", nullable = false)
//	private int status;
//	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getUrl() {
//		return url;
//	}
//	public void setUrl(String url) {
//		this.url = url;
//	}
//	public String getBody() {
//		return body;
//	}
//	public void setBody(String body) {
//		this.body = body;
//	}
//	public String getParamType() {
//		return paramType;
//	}
//	public void setParamType(String paramType) {
//		this.paramType = paramType;
//	}
//	public int getStatus() {
//		return status;
//	}
//	public void setStatus(int status) {
//		this.status = status;
//	}
//}
