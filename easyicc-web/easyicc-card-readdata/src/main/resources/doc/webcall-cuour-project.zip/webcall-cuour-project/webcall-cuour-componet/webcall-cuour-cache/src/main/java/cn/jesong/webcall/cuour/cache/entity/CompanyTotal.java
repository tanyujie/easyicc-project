package cn.jesong.webcall.cuour.cache.entity;

import java.util.HashMap;
import java.util.Map;


public class CompanyTotal {

	private Map<Integer, Integer> allocations = new HashMap<Integer, Integer>();
	
	private Map<Integer, Integer> weights = new HashMap<Integer, Integer>();
	
	
	public synchronized void addWeight(int bussinessGroupId, int weight){
		if(this.weights.containsKey(bussinessGroupId)){
			this.weights.put(bussinessGroupId, this.weights.get(bussinessGroupId) + weight);
		}else{
			this.weights.put(bussinessGroupId, weight);
		}
	}
	
	public void addAllocation(int bussinessGroupId, int count){
		if(this.allocations.containsKey(bussinessGroupId)){
			this.allocations.put(bussinessGroupId, this.allocations.get(bussinessGroupId) + count);
		}else{
			this.allocations.put(bussinessGroupId, count);
		}
	}
	
	public int getTotalWeight(int bussinessGroupId){
		if(this.weights.containsKey(bussinessGroupId)){
			return this.weights.get(bussinessGroupId);
		}else{
			return 0;
		}
	}
	
	public int getAllocationTotal(int bussinessGroupId){
		if(this.allocations.containsKey(bussinessGroupId)){
			return this.allocations.get(bussinessGroupId);
		}else{
			return 0;
		}
	}
	
}
