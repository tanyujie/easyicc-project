package cn.jesong.webcall.cuour.service.setting;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Sales;
import cn.jesong.webcall.cuour.entity.Scheduling;
import cn.jesong.webcall.cuour.entity.SchedulingImportData;
import cn.jesong.webcall.cuour.entity.SchedulingUser;
import cn.jesong.webcall.cuour.entity.SchedulingWeek;
import cn.jesong.webcall.cuour.service.AllocationCardService;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SchedulingUserService extends SettingService<Integer, SchedulingUser>{
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private SchedulingService schedulingService;


    @Autowired
	private SaleService saleService;
	
	@Autowired
	private AllocationCardService allocationCardService;
	
	@Override
	protected Class<SchedulingUser> getEntityClass() {
		return SchedulingUser.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from SchedulingUser where schedulingType=1 / and companyId = {companyId} / / and schedulingTime like {schedulingTime}/ / and userId = {userId} /";
	}
	
	public List<Map<String, Object>> getPersonelSchedulings(int companyId, String userId, Date startTime){
		List<SaleUser> users = this.allocationCardService.getAllSaleUsers(companyId);
		List<SaleUser> list = new ArrayList<SaleUser>();
		for(SaleUser u : users){
			if(u.getUserId().equals(userId)){
				list.add(u);
				break;
			}
		}
		return this.getSchedulings(companyId, list, startTime);
	}
	
	public List<Map<String, Object>> getSchedulings(int companyId, Date startTime, Integer subjectId, Integer schoolId, Integer businessGroupId){
		List<SaleUser> users = this.allocationCardService.getAllSaleUsers(companyId);
		List<SaleUser> list = new ArrayList<SaleUser>();
		if(subjectId != null || schoolId != null || businessGroupId != null){
			for(SaleUser u : users){
				boolean flag = true;
				if(subjectId != null && u.getSubjectId().intValue() != subjectId.intValue()){
					flag = false;
				}
				if(flag && schoolId != null && u.getSchoolId().intValue() != schoolId.intValue()){
					flag = false;
				}
				if(flag && businessGroupId != null && u.getBusinessGroupId().intValue() != businessGroupId.intValue()){
					flag = false;
				}
				if(flag){
					list.add(u);
				}
			}
		}else{
			list = users;
		}
		return this.getSchedulings(companyId, list, startTime);
	}
	
	private List<Map<String, Object>> getSchedulings(int companyId, List<SaleUser> list, Date startTime){
		List<Map<String, Object>> infos = new ArrayList<Map<String, Object>>();
		if(!list.isEmpty()){
			Calendar end = Calendar.getInstance();
			end.setTime(startTime);
			end.add(Calendar.DAY_OF_MONTH, 7);
			String sql = "select a.id, a.scheduling_id, a.scheduling_time, a.user_id, b.name  "+
						 "from js_scheduling_user a "+
						 "inner join js_scheduling b on a.scheduling_id=b.id  "+
						 "where a.company_id = ? and a.scheduling_type = 1 and to_date(a.scheduling_time, 'yyyymmdd') between ? and ?";
			List<Map<String, Object>> schedulings = this.jdbcTemplate.queryForList(sql, companyId, startTime, end.getTime());
			Map<String, Map<String, Object>> index = new HashMap<String, Map<String, Object>>();
			for(Map<String, Object> scheduling : schedulings){
				index.put(scheduling.get("scheduling_time")+"-"+scheduling.get("user_id"), scheduling);
			}
			int start = Integer.parseInt(formatter.format(startTime));
			for(SaleUser u : list){
				Map<String, Object> info = new HashMap<String, Object>();
				info.put("userId", u.getUserId());
				info.put("realName", u.getRealName());
				info.put("schoolName", u.getSchoolName());
				info.put("subjectName", u.getSubjectName());
				info.put("businessGroupName", u.getBusinessGroupName());
				info.put("salesTypeName", u.getSalesTypeName());
				for(int i=0; i<7; i++){
					Calendar t = Calendar.getInstance();
					t.setTime(startTime);
					t.add(Calendar.DAY_OF_MONTH, i);
					Map<String, Object> scheduling = index.get((formatter.format(t.getTime()))+"-"+u.getUserId());
					if(scheduling != null){
						info.put("id"+i, scheduling.get("id"));
						info.put("schedulingName"+i, scheduling.get("name"));
					}else{
						info.put("id"+i, -1);
						info.put("schedulingName"+i, "休息");
					}
					info.put("schedulingTime"+i, start+i);
				}
				
				infos.add(info);
			}
		}
		return infos;
	}
	
	
	
	@Transactional
	public void importData(final SchedulingImportData data) throws Exception{
		List<Scheduling> schedulings = this.schedulingService.getList("from Scheduling where companyId = ?", new Object[]{data.getCompanyId()});
		Map<String, Integer> index = new HashMap<String, Integer>();
		for(Scheduling s : schedulings){
			index.put(s.getName().trim(), s.getId());
		}
		Set<String> set = new HashSet<String>();
		List<Sales> sales = this.saleService.getList("from Sales where companyId = ?", new Object[]{data.getCompanyId()});
		for(Sales s : sales){
			set.add(s.getUserId());
		}
		List<SchedulingUser> users = new ArrayList<SchedulingUser>();
		for(SchedulingWeek week : data.getSchedulings()){
			//需要判断班次是不是存在
			for(int i=0; i<week.getSchedulingNames().length; i++){
				if(week.getSchedulingNames()[i] != null && !week.getSchedulingNames()[i].equals("")){
					Integer schedulingId = index.get(week.getSchedulingNames()[i]);
					if(schedulingId == null){
						throw new Exception("未知的排班班次["+week.getSchedulingNames()[i]+"]");
					}else{
						SchedulingUser u = new SchedulingUser();
						u.setCompanyId(data.getCompanyId());
						u.setSchedulingId(schedulingId);
						u.setSchedulingTime(data.getDates()[i]);
						u.setSchedulingType(1);
						u.setUserId(week.getUserId());
						users.add(u);
					}
				}
				if(!set.contains(week.getUserId())){
					throw new Exception("未配置["+week.getUserId()+"]的销售信息");
				}
			}
		}
		if(users.isEmpty()){
			throw new Exception("导入数据不能为空");
		}
		//清除之前数据
		for(int i=0; i<data.getDates().length; i++){
			final String date = data.getDates()[i];
			this.getHibernateTemplate().execute((HibernateCallback<Object>) session -> {
                Query query = session.createQuery("delete from SchedulingUser where companyId = ? and schedulingTime = ? ");
                query.setParameter(0, data.getCompanyId());
                query.setParameter(1, date);
                return query.executeUpdate();
            });
		}
		this.batchSave(users);
		this.onSettingChanged(data.getCompanyId());
	}

}
