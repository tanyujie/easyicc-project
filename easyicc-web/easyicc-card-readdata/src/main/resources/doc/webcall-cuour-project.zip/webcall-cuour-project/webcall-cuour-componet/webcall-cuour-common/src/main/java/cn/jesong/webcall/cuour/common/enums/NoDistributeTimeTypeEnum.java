package cn.jesong.webcall.cuour.common.enums;

/**
 * 同手机号新建的名片 多长时间内不再分配的时间类型枚举
 * @author lcy
 *
 */
public enum NoDistributeTimeTypeEnum {
	 	HOUR(1, "小时"),
	    DAY(2, "天");
	
	 	private Integer type;
	    private String text;

	    NoDistributeTimeTypeEnum(Integer type, String text) {
	        this.type = type;
	        this.text = text;
	    }

		public Integer getType() {
			return type;
		}

		public void setType(Integer type) {
			this.type = type;
		}

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

	  
}
