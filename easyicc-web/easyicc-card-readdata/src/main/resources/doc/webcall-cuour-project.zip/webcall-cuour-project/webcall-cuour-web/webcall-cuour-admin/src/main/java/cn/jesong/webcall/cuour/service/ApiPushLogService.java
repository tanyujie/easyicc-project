package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.eutils.web.platform.db.SQLEso;
import cn.eutils.web.platform.db.SQLInfo;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.jesong.webcall.cuour.entity.ApiPushLog;
import cn.jesong.webcall.cuour.entity.Card;


@Service
public class ApiPushLogService {

	@Resource(name="jdbcTemplate")
	private JdbcTemplate template;
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public Page<ApiPushLog> pageApiPushVisitorInfo(PageConfig pageConfig, Map<String, Object> map) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.*, b.* from js_card_api_push_log a left join js_visitor_info b on a.card_id = b.id   ");
		hql.append("  where / a.company_id = {companyId}  / ")
		   .append("/ and b.create_time >= {startTime}  / ")
		   .append("/ and b.create_time <= {endTime}   /");
		Integer status = Integer.valueOf(map.get("status").toString());
		if(status > -1){
			hql.append("/ and a.status = {status}   /");
		}
		hql.append("/  and  b.mobile like  '%'||{phoneNumber}||'%'  / ");
		hql.append(" order by b.create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map);
		Page<ApiPushLog> page = this.template.query(sql.getSQL(), sql.getParams(), new PageResultSetExtractor<ApiPushLog>(pageConfig, new ApiPushLogRowMapper()));
		return page;
	}
	
	public List<ApiPushLog> downApiPushVisitorInfo(PageConfig pageConfig, Map<String, Object> map) throws Exception {
		StringBuilder hql = new StringBuilder();
		hql.append("select a.*, b.* from js_card_api_push_log a left join js_visitor_info b on a.card_id = b.id   ");
		hql.append("  where / a.company_id = {companyId}  / ")
		   .append("/ and b.create_time >= {startTime}  / ")
		   .append("/ and b.create_time <= {endTime}   /");
		Integer status = Integer.valueOf(map.get("status").toString());
		if(status > -1){
			hql.append("/ and a.status = {status}   /");
		}
		hql.append("/  and  b.mobile like  '%'||{phoneNumber}||'%'  / ");
		hql.append(" order by b.create_time desc");
		SQLEso sql = SQLInfo.parseSQLEso(hql.toString(), map);
		List<ApiPushLog> page = this.template.query(sql.getSQL(), sql.getParams(),  new ApiPushLogRowMapper());
		return page;
	}
	
	
	public Card getCard(int cardId){
		List<Card> list = this.template.query("select * from js_visitor_info where id = ?", new Object[]{cardId}, new CardRowMapper());
		if(list != null && !list.isEmpty()){
			return list.get(0);
		}else{
			return null;
		}
	}
	
  class  PageResultSetExtractor <T> implements ResultSetExtractor<Page<T>>{
		
		private PageConfig pageConfig;
		
		private RowMapper<T> rowMapper;
		
		public PageResultSetExtractor(PageConfig pageConfig, RowMapper<T> rowMapper){
			this.pageConfig = pageConfig;
			this.rowMapper = rowMapper;
		}

		@Override
		public Page<T> extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			int currentRow = 1;  
			Page<T> page = new Page<T>();
			List<T> rows = new ArrayList<T>();
			int startRow = (pageConfig.getPageNo() - 1) * pageConfig.getPageSize() + 1;
			while(rs.next()){
				if(currentRow < startRow + pageConfig.getPageSize() && currentRow >= startRow){
					rows.add(rowMapper.mapRow(rs, currentRow)); 
				}
				currentRow++;  
			}
            page.setRows(rows);
            page.setTotal(currentRow-1);
			return page;
		}
	}
  
  
  class ApiPushLogRowMapper implements RowMapper<ApiPushLog>{

		@Override
		public ApiPushLog mapRow(ResultSet rs, int rowNum) throws SQLException {
			ApiPushLog v = new ApiPushLog();
			v.setId(rs.getInt("id"));
			v.setVisitorStaticId(rs.getString("visitor_static_id"));
			v.setCompanyId(rs.getInt("company_id"));
			v.setName(rs.getString("name"));
			v.setTel(rs.getString("tel"));
			v.setEmail(rs.getString("email"));
			v.setNote(rs.getString("note"));
			v.setReseveKey(rs.getString("reseve_key"));
			v.setSex(rs.getString("sex"));
			v.setRepName(rs.getString("repname"));
			v.setMobile(rs.getString("mobile"));
			v.setQq(rs.getString("qq"));
			v.setMsn(rs.getString("msn"));
			v.setUrl(rs.getString("url"));
			v.setCompanyName(rs.getString("company_name"));
			v.setArea(rs.getString("area"));
			v.setUserId(rs.getString("user_id"));
			v.setCreateTime(rs.getTimestamp("create_time"));
			v.setExtColumn1(rs.getString("ext_column1"));
			v.setExtColumn2(rs.getString("ext_column2"));
			v.setExtColumn3(rs.getString("ext_column3"));
			v.setExtColumn4(rs.getString("ext_column4"));
			v.setExtColumn5(rs.getString("ext_column5"));
			v.setExtColumn6(rs.getString("ext_column6"));
			v.setExtColumn7(rs.getString("ext_column7"));
			v.setExtColumn8(rs.getString("ext_column8"));
			v.setExtColumn9(rs.getString("ext_column9"));
			v.setExtColumn10(rs.getString("ext_column10"));
			String responseStr = rs.getString("response_str");
			if(responseStr != null){
				responseStr = responseStr.replaceAll("<", "&lt;");
				responseStr = responseStr.replaceAll(">", "&gt;");
			}
			v.setResponseStr(responseStr);
			v.setFirstURL(rs.getString("first_url"));
			v.setPushCount(rs.getInt("PUSH_COUNT"));
			v.setFirsrErrorTime(rs.getTimestamp("FIRST_ERROR_TIME"));
			v.setLatErrorTime(rs.getTimestamp("LAST_ERROR_TIME"));
			v.setPushTime(rs.getTimestamp("PUSH_TIME"));
			v.setStatus(rs.getInt("status"));
			v.setCardId(rs.getInt("CARD_ID"));
			return v;
		}
		
	}
  
  
  final class CardRowMapper implements RowMapper<Card>{

		@Override
		public Card mapRow(ResultSet rs, int rowNum) throws SQLException {
			Card card = new Card();
			card.setId(rs.getInt("id"));
			card.setCompanyId(rs.getInt("company_id"));
			card.setName(rs.getString("name"));
			try {
				String subjectId = rs.getString("ext_column8");
				if(subjectId != null && NumberUtils.isNumber(subjectId)){
					card.setSubjectId(Integer.parseInt(subjectId));
				}
				String schoolId = rs.getString("ext_column9");
				if(schoolId != null && NumberUtils.isNumber(schoolId)){
					card.setSchooleId(Integer.parseInt(schoolId));
				}
				String callbackTime = rs.getString("ext_column10");
				if(callbackTime != null && !callbackTime.equals("")){
					card.setCallbackTime(formatter.parse(rs.getString("ext_column10")));
				}
			} catch (Exception e) {
				//_logger.error("名片错误的数据格式["+card.getId()+"]:"+e.getMessage(), e);
			}
			card.setAllocationTime(rs.getTimestamp("allocation_time"));
			card.setIsValid(rs.getInt("is_valid"));
			card.setIsBack(rs.getInt("is_back"));
			card.setAllocationStatus(rs.getInt("allocation_status"));
			card.setModifyIdentity(rs.getString("modify_identity"));
			card.setUserId(rs.getString("user_id"));
			if(card.getAllocationStatus() == Card.STATUS_FINISHED){
				card.setFinished(1);
			}
			card.setMobile(rs.getString("mobile"));
			Date createTime = rs.getTimestamp("create_time");
			card.setCreateTime(createTime == null ? new Date() :createTime);
			
			card.setCreateUserId(rs.getString("create_user_id"));
			
			card.setSaleId(rs.getString("ext_column6"));
			
			if(card.getCallbackTime() == null){
				card.setCallbackTime(card.getCreateTime());
			}
			
			return card;
		}
	}
}
