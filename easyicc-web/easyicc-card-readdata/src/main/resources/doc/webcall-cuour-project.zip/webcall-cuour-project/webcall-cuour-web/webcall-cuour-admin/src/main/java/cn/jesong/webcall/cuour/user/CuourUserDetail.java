package cn.jesong.webcall.cuour.user;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cn.eutils.web.platform.permission.user.IUserDetail;
import cn.jesong.webcall.resource.User;

public class CuourUserDetail implements IUserDetail{
	
	private User user;
	
	private boolean isAdmin;
	
	private Set<String> menuIds = new HashSet<String>();
	
	private Map<String, Set<String>> dataPermissions = new HashMap<String, Set<String>>();
	
	CuourUserDetail(User user, List<String> roles, List<String> menuIds, List<Map<String, String>> dataRoles){
		this.user = user;
		this.isAdmin = roles.contains("ADMIN_ROLE");
		this.menuIds.addAll(menuIds);
		
		for(Map<String, String> r : dataRoles){
			String key = r.get("menu_id")+"@"+r.get("data_id");
			Set<String> dataValues = this.dataPermissions.get(key);
			if(dataValues == null){
				dataValues = new HashSet<String>();
				this.dataPermissions.put(key, dataValues);
			}
			dataValues.add(r.get("data_value"));
		}
	}
	
	public Set<String> getDataPermission(String menuId, String dataId){
		String key = menuId+"@"+dataId;
		Set<String> dataValues = this.dataPermissions.get(key);
		if(dataValues != null){
			return dataValues;
		}else{
			return new HashSet<String>();
		}
	}
	
	public boolean hasDataPermission(String menuId, String dataId, String dataValue){
		return this.getDataPermission(menuId, dataId).contains(dataValue);
	}

	@Override
	public int getCompanyId() {
		return user.getCompanyId();
	}

	@Override
	public int getDepartmentId() {
		return user.getDepartmentId();
	}

	@Override
	public String getNickName() {
		return user.getNickName();
	}

	@Override
	public String getRealName() {
		return user.getRealName();
	}

	@Override
	public String getUserId() {
		return user.getUserId();
	}
	
	public boolean isAdmin(){
		return this.isAdmin;
	}
	
	public boolean hasMenu(String menuId){
		return this.isAdmin || this.menuIds.contains(menuId);
	}
	
	public boolean hasModule(String module){
		if(this.isAdmin){
			return true;
		}else{
			for(String key : this.menuIds){
				if(key.indexOf("cn.jesong.webcall.cuour."+module) == 0){
					return true;
				}
			}
			return false;
		}
	}

}
