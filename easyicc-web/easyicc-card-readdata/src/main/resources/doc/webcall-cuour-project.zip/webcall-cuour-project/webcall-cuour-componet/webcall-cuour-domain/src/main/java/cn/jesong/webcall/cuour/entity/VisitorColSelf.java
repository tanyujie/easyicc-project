package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@Table(name = "js_visitor_col_self")
public class VisitorColSelf implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_visitor_col_self_seq")
    @SequenceGenerator(name = "js_visitor_col_self_seq", sequenceName = "js_visitor_col_self_seq", allocationSize = 1)
    private Integer id;

   // private VisitorCol visitorCol;
    private int companyId;
    private String selfText = "";
    private int colType;
    private int hidden;
    private int sortIndex;
    private int editable = 1;
    private String referTable;
   // private Set<VisitorColSelfItem> items;
    private int required = 0;
    private String formatter;

    private String colName;
    public VisitorColSelf() {
    }

    public int getRequired() {
        return this.required;
    }

    public void setRequired(int required) {
        this.required = required;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

//    public VisitorCol getVisitorCol() {
//        return this.visitorCol;
//    }

//    public void setVisitorCol(VisitorCol visitorCol) {
//        this.visitorCol = visitorCol;
//    }

    public int getCompanyId() {
        return this.companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public String getSelfText() {
        return this.selfText;
    }

    public void setSelfText(String selfText) {
        this.selfText = selfText;
    }

    public int getColType() {
        return this.colType;
    }

    public void setColType(int colType) {
        this.colType = colType;
    }

    public int getHidden() {
        return this.hidden;
    }

    public void setHidden(int hidden) {
        this.hidden = hidden;
    }

    public int getSortIndex() {
        return this.sortIndex;
    }

    public void setSortIndex(int sortIndex) {
        this.sortIndex = sortIndex;
    }

//    public Set<VisitorColSelfItem> getItems() {
//        return this.items;
//    }
//
//    public void setItems(Set<VisitorColSelfItem> items) {
//        this.items = items;
//    }

    public int getEditable() {
        return this.editable;
    }

    public void setEditable(int editable) {
        this.editable = editable;
    }

    public String getReferTable() {
        return this.referTable;
    }

    public void setReferTable(String referTable) {
        this.referTable = referTable;
    }

    public String getFormatter() {
        return this.formatter;
    }

    public void setFormatter(String formatter) {
        this.formatter = formatter;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }
}
