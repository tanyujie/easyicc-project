package cn.jesong.webcall.cuour.service.setting;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Subject;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SubjectService extends SettingService<Integer, Subject>{
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Override
	protected Class<Subject> getEntityClass() {
		return Subject.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from Subject where / companyId = {companyId} / order by id desc";
	}

	public Boolean blinding(int companyId){
		String sql = "update JS_VISITOR_COL_SELF set col_type = ?, refer_table = ? where company_id = ? and col_name= ? ";
		int len = this.jdbcTemplate.update(sql, 4, "js_cuour_subject", companyId, "extColumn8");
		return len > 0 ?  true : false;
	}
}
