package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.SaleType;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SaleTypeService extends SettingService<Integer, SaleType>{
	
	@Override
	protected Class<SaleType> getEntityClass() {
		return SaleType.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from SaleType where / companyId = {companyId} / order by id desc";
	}

}