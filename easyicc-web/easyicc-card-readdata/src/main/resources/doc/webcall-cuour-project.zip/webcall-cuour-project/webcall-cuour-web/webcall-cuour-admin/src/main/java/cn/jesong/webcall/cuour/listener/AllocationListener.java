package cn.jesong.webcall.cuour.listener;

import cn.jesong.webcall.cuour.entity.Card;

/**
 * 名片分配监听
 * @author Administrator
 *
 */
public interface AllocationListener {

	/**
	 * 名片分配前的处理
	 * @param card
	 */
	public void before(Card card);
	
	/**
	 * 名片分配后的处理
	 * @param card
	 * @param allocation
	 */
	public void after(Card card, boolean allocation);
	
}
