package cn.jesong.webcall.cuour.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.orm.hibernate5.HibernateCallback;

import cn.eutils.web.platform.db.SQLEso;
import cn.eutils.web.platform.db.SQLInfo;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import org.springframework.transaction.annotation.Transactional;

public abstract class HibernateDAO<ID extends Serializable, E> extends HibernateDaoSupport{

	@Autowired
	private SessionFactory sessionFactory;
	
	@PostConstruct 
	public void init(){
		this.setSessionFactory(sessionFactory);
	}
	
	protected abstract Class<E> getEntityClass();
	
	protected abstract String getTemplateQuerySQL();
	
	/**
	 * 保存
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("unchecked")
    @Transactional
	public ID save(E obj){
		return (ID)this.getHibernateTemplate().save(obj);
	}
	
	/**
	 * 批量保存
	 * @param objs
	 */
    @Transactional
	public void batchSave(final Collection<?> objs){
		this.getHibernateTemplate().execute(session -> {
            int i=0;
            for(Object obj : objs){
                session.save(obj);
                if(++i % 20 == 0){
                    session.flush();
                }
            }
            session.flush();
            return null;
        });
	}
	
	/**
	 * 保存或更新
	 * @param obj
	 */
    @Transactional
	public void saveOrUpdate(E obj){
		this.getHibernateTemplate().saveOrUpdate(obj);
	}
	
	/**
	 * 删除
	 */
    @Transactional
	public void delete(E obj){
		this.getHibernateTemplate().delete(obj);
	}
	
	/**
	 * 删除
	 * @param clazz
	 * @param id
	 */
    @Transactional
	public void delete(ID id){
		E obj = this.get(id);
		if(obj != null){
			this.delete(obj);
		}
	}
	
	/**
	 * 查询
	 * @param clazz
	 * @param id
	 * @return
	 */
	public E get(ID id) {
		return this.getHibernateTemplate().get(this.getEntityClass(), id);
	}
	
	/**
	 * 执行更新SQL
	 * @param hql
	 * @param params
	 * @return
	 */
    @Transactional
	public Integer executeUpdate(final String hql, final Object ... params){
		return this.getHibernateTemplate().execute(session -> {
            Query query = session.createQuery(hql);
            if(params != null){
                for(int i=0; i<params.length; i++){
                    query.setParameter(i, params[i]);
                }
            }
            return query.executeUpdate();
        });
	}
	
	
	public Page<E> pageQueryByTemplate(PageConfig config, Object params){
		SQLEso eso = SQLInfo.parseSQLEso(this.getTemplateQuerySQL(), params);
		return this.pageQuery(eso.getSQL(), config.getPageNo(), config.getPageSize(), eso.getParams());
	}
	
	public List<E> getListByTemplate(Object params){
		SQLEso eso = SQLInfo.parseSQLEso(this.getTemplateQuerySQL(), params);
		return this.getList(eso.getSQL(), eso.getParams());
	}
	
	/**
	 * 分页查询
	 * @param hsql hibernateSQL
	 * @param pageNo 页数
	 * @param pageSize 每条数据量
	 * @param params 参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Page<E> pageQuery(final String hsql, final int pageNo, final int pageSize, final Object[] params){
		final Page<E> page = new Page<E>(pageNo, pageSize);
		String countQueryString = " select count (*) "
				+ removeSelect(removeOrders(hsql));
		List countlist = getHibernateTemplate().find(countQueryString, params);
		long total = ((Long) countlist.get(0)).longValue();
		page.setTotal(total);
		if(total == 0){
			page.setRows(new ArrayList<E>());
		}else{
			List<E> list = this.getHibernateTemplate().execute((HibernateCallback<List<E>>) session -> {
                Query query = session.createQuery(hsql);
                if (params != null) {
                    for (int i = 0; i < params.length; i++) {
                        query.setParameter(i, params[i]);
                    }
                }
                query.setFirstResult(page.getOffset());
                query.setMaxResults(page.getPageSize());
                return query.list();
            });
			page.setRows(list);
		}
		return page;
	}
	
	/**
	 * 查询
	 * @param hsql
	 * @param params
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<E> getList(String hsql, Object ... params){
		return (List<E>)this.getHibernateTemplate().find(hsql, params);
	}
	
	/**
	 * 删除hsqlfrom前的内容
	 * @param hql
	 * @return
	 */
	private static String removeSelect(String hql) {
		int beginPos = hql.toLowerCase().indexOf("from");		
		return hql.substring(beginPos);
	}
	
	/**
	 * 删除hsql排序内容
	 * @param hql
	 * @return
	 */
	private static String removeOrders(String hql) {		
		Pattern p = Pattern.compile("order\\s*by[\\w|\\W|\\s|\\S]*",
				Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(hql);
		StringBuffer sb = new StringBuffer();
		while (m.find()) {
			m.appendReplacement(sb, "");
		}
		m.appendTail(sb);
		return sb.toString();
	}
}
