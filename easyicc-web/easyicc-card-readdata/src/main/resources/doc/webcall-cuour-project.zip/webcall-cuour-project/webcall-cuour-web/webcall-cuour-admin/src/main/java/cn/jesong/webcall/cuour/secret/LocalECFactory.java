package cn.jesong.webcall.cuour.secret;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LocalECFactory extends SecretFactory {

	private final static Log _logger = LogFactory.getLog(LocalECFactory.class);

	private static CardAuxiliaryInterface auxiliary;

	public LocalECFactory() {
		auxiliary = new CardECImpl();
	}

	@Override
	public CardAuxiliaryInterface getGenerator() {
		return this.auxiliary;
	}

}
