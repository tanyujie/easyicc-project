package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.cache.CacheActionConfigLoader;
import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.entity.ActionConfig;
/**
 * 动作配置service
 * @author hanjianxin
 *
 */
@Service
public class ActionConfigService extends SettingService<Integer, ActionConfig> implements CacheActionConfigLoader  {
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CacheFactory cacheFactory;
	
	/**
	 * 获取动作配置
	 * @param companyId
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public ActionConfig getActionConfig(int companyId) throws Exception {
		String sql = " select * from js_card_action_config where company_id = ? ";
		ActionConfig ac = cacheFactory.getActionConfigCache().getActionConfig(companyId);
		if(ac == null) {
			List<ActionConfig> list = this.jdbcTemplate.query(sql, new Object[]{companyId}, new ActionConfigRowMapper());
			if(list != null&&list.size()>0) {
				ac = list.get(0);
				cacheFactory.getActionConfigCache().init(ac);
			}
			else
				cacheFactory.getActionConfigCache().initNullConfig(companyId);
		}
		
		return ac;
	}
	
	public Map<String, Object> loadCardFullData(int id) throws Exception {
		StringBuilder sql = new StringBuilder();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		sql.append(" select info.id, ");
//		sql.append(" JD.REAL_NAME CRATEREAL_NAME, ");
//		sql.append(" JD.REAL_NAME as realname, ");
		sql.append(" info.visitor_static_id as visitorStaticId, ");
		sql.append(" info.company_id as companyId, ");
		sql.append(" info.name, ");
		sql.append(" to_char(info.ALLOCATION_TIME, 'yyyy-mm-dd hh24:mi:ss') as allocationTime, ");
		sql.append(" info.email, ");
		sql.append(" info.note, ");
		sql.append(" info.sex, ");
		sql.append(" info.repName, ");
		sql.append(" info.qq, ");
		sql.append(" info.msn, ");
		sql.append(" info.url, ");
		sql.append(" info.company_name as companyName, ");
		sql.append(" info.area, ");
		sql.append(" info.user_id as userId, ");
		sql.append(" info.create_user_id as createUserId, ");
		sql.append(" info.ext_column1 as extColumn1, ");
		sql.append(" info.ext_column2 as extColumn2, ");
		sql.append(" info.ext_column3 as extColumn3, ");
		sql.append(" info.ext_column4 as extColumn4, ");
		sql.append(" info.ext_column5 as extColumn5, ");
		sql.append(" info.ext_column6 as extColumn6, ");
		sql.append(" info.ext_column7 as extColumn7, ");
		sql.append(" info.ext_column8 as extColumn8, ");
		sql.append(" info.ext_column9 as extColumn9, ");
		sql.append(" info.ext_column10 as extColumn10, ");
		sql.append(" info.search_engine as searchEngine, ");
		sql.append(" info.keyword, ");
		sql.append(" info.refer, ");
		sql.append(" info.chat_url as chatURL, ");
		sql.append(" info.search_host as searchHost, ");
		sql.append(" info.spread_flag as spreadFlag, ");
		sql.append(" info.first_url as firstURL, ");
		sql.append(" info.promotion_id as promotionId, ");
		sql.append(" info.type, ");
		sql.append(" info.crm_state as crmState, ");
		sql.append(" to_char(info.create_time, 'yyyy-mm-dd hh24:mi:ss') as createTime, ");
		sql.append(" to_char(info.edit_time, 'yyyy-mm-dd hh24:mi:ss') as editTime, ");
		sql.append(" info.mobile hideMobile, ");
		sql.append(" info.tel Tel, ");
		sql.append(" info.mobile mobile, ");
		sql.append(" info.CHAT_ID as chatId, ");
		sql.append(" info.COUNTRY as country, ");
		sql.append(" info.PROVINCE as province, ");
		sql.append(" info.CITY as city, ");
		sql.append(" site.NAME as siteName, ");
		sql.append(" info.DEVICE_TYPE as deviceType, ");
		sql.append(" info.SITE_ID as siteId ");
		sql.append(" from js_visitor_info info ");
//		sql.append(" LEFT JOIN js_user jd ON info.USER_ID = JD.USER_ID ");
//		sql.append(" left join ");
//		sql.append(" js_department jsdepartment ");
//		sql.append(" on jsdepartment.department_id=jd.department_id ");
	//	sql.append(" left join js_user createUser on info.CREATE_USER_ID = createUser.USER_ID ");
		sql.append(" left join JS_SITE site on info.SITE_ID = site.ID ");
		sql.append(" where info.id = ? ");

		list = this.jdbcTemplate.queryForList(sql.toString(), id);

		if (list != null && list.size() > 0) {
			
			return (Map<String, Object>)list.get(0);
//			int companyId = map.get("COMPANYID") == null ? 0 : Integer.parseInt(map.get("COMPANYID").toString());
//			String staticId = map.get("VISITORSTATICID") == null ? "" : map.get("VISITORSTATICID").toString();
//			String createTime = map.get("createTime") == null ? "" : map
//					.get("createTime").toString();
//			if(companyId > 0 && !"".equals(staticId)) {
//				String records = getChatRecordDetail(companyId, staticId, createTime, html);
//				map.put("RECORDS", records);
//			}
			
		}
		return null;
	}
	
	/**
	 * 添加动作配置
	 * @param ac
	 * @return
	 * @throws Exception
	 */
	public int insert(ActionConfig ac) throws Exception {
		int id = 0;
		if (ac != null) {
			String tpl = ac.getTpl() == null ? "" : ac.getTpl();
			String config = ac.getConfig() == null ? "" : ac.getConfig();
			String interfaceUrl = ac.getInterfaceUrl() == null ? "" : ac.getInterfaceUrl();
			String bodyType = ac.getBodyType() == null ? "" : ac.getBodyType();
			String isDataSign = ac.getIsDataSign() == null ? "" : ac.getIsDataSign();
			String signAlgorithm = ac.getSignAlgorithm() == null ? "" : ac.getSignAlgorithm();
			String signBody = ac.getSignBody() == null ? "" : ac.getSignBody();
			String thirdPlatform = ac.getThirdPlatform() == null ? "" : ac.getThirdPlatform();
			
			ac.setTpl(tpl);
			ac.setConfig(config);
			ac.setInterfaceUrl(interfaceUrl);
			ac.setBodyType(bodyType);
			ac.setIsDataSign(isDataSign);
			ac.setSignBody(signBody);
			ac.setSignAlgorithm(signAlgorithm);
			ac.setThirdPlatform(thirdPlatform);
			
			id = this.save(ac);
		}
		return id;
	}
	
	/**
	 * 修改动作配置
	 * @param ac
	 * @return
	 * @throws Exception
	 */
	public int update(ActionConfig ac) throws Exception {
		int id = 0;
		if (ac != null) {
			String hql = "update ActionConfig set status=?,companyId=?,companyName=?,cmd=?,tpl=?,paramType=?,interfaceUrl=?,bodyType=?,isDataSign=?,signAlgorithm=?,signBody=?,config=?,containType=?,containRule=?,thirdPlatform=? where id=?";
			id = this.executeUpdate(hql, ac.getStatus(),
					ac.getCompanyId(),ac.getCompanyName(),ac.getCmd(),ac.getTpl(),
					ac.getParamType(),ac.getInterfaceUrl(),ac.getBodyType(),ac.getIsDataSign(),
					ac.getSignAlgorithm(),ac.getSignBody(),ac.getConfig(),ac.getContainType(),ac.getContainRule(),ac.getThirdPlatform(), ac.getId());
			cacheFactory.getActionConfigCache().remove(ac.getCompanyId());
		}
		return id;
	}
	
	class ActionConfigRowMapper implements RowMapper<ActionConfig>{
		@Override
		public ActionConfig mapRow(ResultSet rs, int rowNum) throws SQLException {
			ActionConfig ac = new ActionConfig();
			ac.setId(rs.getInt("ID"));
			ac.setCompanyId(rs.getInt("COMPANY_ID"));
			ac.setCmd(rs.getString("CMD"));
			ac.setConfig(rs.getString("CONFIG"));
			ac.setTpl(rs.getString("TPL"));
			ac.setParamType(rs.getString("PARAM_TYPE"));
			ac.setStatus(rs.getInt("STATUS"));
			ac.setInterfaceUrl(rs.getString("INTERFACE_URL"));
			ac.setCompanyName(rs.getString("COMPANY_NAME"));
			
			ac.setBodyType(rs.getString("BODY_TYPE"));
			ac.setIsDataSign(rs.getString("IS_DATA_SIGN"));
			ac.setSignAlgorithm(rs.getString("SIGN_ALGORITHM"));
			ac.setSignBody(rs.getString("SIGN_BODY"));
			ac.setContainType(rs.getString("CONTAIN_TYPE"));
			ac.setContainRule(rs.getString("CONTAIN_RULE"));
			ac.setThirdPlatform(rs.getString("THIRD_PLATFORM"));
			return ac;
		}
	}

	@Override
	protected Class<ActionConfig> getEntityClass() {
		
		return ActionConfig.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from ActionConfig where / cmd = {cmd} / order by id desc";
	}

}
