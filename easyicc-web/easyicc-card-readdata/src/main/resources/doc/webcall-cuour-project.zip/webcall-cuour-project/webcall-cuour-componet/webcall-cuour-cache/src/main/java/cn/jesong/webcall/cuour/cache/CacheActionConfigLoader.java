package cn.jesong.webcall.cuour.cache;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public interface CacheActionConfigLoader {

	/**
	 * 数据发送动作配置
	 * @param companyId
	 * @return
	 */
	public ActionConfig getActionConfig(int companyId) throws Exception;
}
