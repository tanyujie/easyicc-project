package cn.jesong.webcall.cuour.service.setting;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.service.WeChatNotifyExtendService;
import cn.jesong.webcall.cuour.service.WeixinInfoService;
import cn.jesong.webcall.cuour.util.SendMessage;

/**
 * 名片扩展接口实现类-微信
 * 
 * @author hanjianxin
 * 
 */
@Service(value="weixinService")
public class WeChatNotifyExtendServiceImpl implements WeChatNotifyExtendService {

	private final static Log logger = LogFactory
			.getLog(WeChatNotifyExtendServiceImpl.class);

	@Autowired
	private WeixinInfoService wxService;

	/**
	 * 公共方法
	 */
	public void action(Card card) {
		try {
					// 发送微信
					

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(), e);
		}

	
	}
	
	public void sendNotifyMessage(String openId,String customerName,String mobile, String cuourName,
			String overdueTime, String url)
	{
		try {
			String message = SendMessage.sendMessage(
					openId, customerName,
					mobile, cuourName,
					overdueTime, url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(), e);
		}
	}
}
