package cn.jesong.webcall.cuour.api;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public interface ThirdApiInterface {
	
	public String httpPost(ActionConfig ac, String data) throws Exception;
	
}
