package cn.jesong.webcall.cuour.controller.setting;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.School;
import cn.jesong.webcall.cuour.service.setting.SchoolService;

@Controller
@RequestMapping("/setting/school")
public class SchoolController extends SimpleController<Integer, School>{
	
	@Autowired
	private SchoolService schoolService;

	@Override
	protected String getPrefix() {
		return "/setting/school";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, School> getHibernateService() {
		return schoolService;
	}

	@Override
	protected void beforeCreateOrUpdate(School entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
	}
	
	/*
	 * 
	 * 手动绑定校区
     */
	@RequestMapping(value="/blinding", method=RequestMethod.POST)
	public RespResult blinding(HttpServletResponse response) throws IOException{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId(); 
		try{
			schoolService.blinding(companyId);
			return RespResult.getSuccess();
		}catch(Exception e){
			return RespResult.getError(e);
		}
	}

}
