package cn.jesong.webcall.cuour.controller.setting;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;


import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.ApiPushLog;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.service.ApiPushLogService;
import cn.jesong.webcall.cuour.service.CardExtendService;
import cn.jesong.webcall.cuour.service.NotifyService;
import cn.jesong.webcall.cuour.util.ExportUtil;


@Controller
@RequestMapping("/setting/apiPushLog")
public class ApiPushLogController {
	
	private final static String PREFIX = "/setting/apiPushLog";
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	@Autowired
	private NotifyService notifyService;
	
	@Autowired
	private ApiPushLogService apiPushLogService;
	
	@Resource(name="sendDataService")
	private CardExtendService cardExtendService;
	
	@RequestMapping("/index")
	public String index(ModelMap model) throws Exception{
		
		
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		
		return PREFIX + "/index";
	}
	
	@RequestMapping("/query")
	@ResponseBody
	public Page<ApiPushLog> query(HttpServletRequest request) throws Exception{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId(); 
		String useId=OnLine.getCurrentUserDetails().getUserId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		params.put("useId", useId);
		String startTime = request.getParameter("startTime");
		if(startTime != null){
			params.put("startTime", formatter.parse(startTime));//+" 00:00:00"
		}
		String endTime = request.getParameter("endTime");
		if(endTime != null){
			params.put("endTime", formatter.parse(endTime));//+" 23:59:59"
		}
		String status = request.getParameter("status");
		if(status != null && status.trim().length() > 0){
			params.put("status", status);
		}
		String phoneNumber = request.getParameter("phoneNumber");
		if(phoneNumber != null && phoneNumber.trim().length() > 0){
			params.put("phoneNumber", phoneNumber);
		}
		this.notifyService.clearNotifyTime(companyId, OnLine.getCurrentUserDetails().getUserId());
		Page<ApiPushLog> page = this.apiPushLogService.pageApiPushVisitorInfo(PageConfig.createPageConfig(request), params);

		return page;
	}
	
	/*
	 * 调用同步的几口进行同步
	 * 
	*/
	
	@RequestMapping("/actionInvoke")
	@ResponseBody
	public void actionInvoke(HttpServletRequest request) throws Exception{
		String cardId=request.getParameter("cardId");
		Card card=this.apiPushLogService.getCard(Integer.valueOf(cardId));
		ActionConfig ac = cardExtendService.getActionConfig(card.getCompanyId());
		if(ac!=null || ac.getStatus() == 1){
			this.cardExtendService.action(ac,card);
		}
	}
	
	
	// 名片推送日记的导出
	@RequestMapping(value = "download")
	public void downloadCrm( HttpSession session,HttpServletRequest request, HttpServletResponse response) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<Map> listMap=new ArrayList<Map>();
		List<String> keys = new ArrayList<String>();
		List<String> heads = new ArrayList<String>();
		List<String> keysFirst = new ArrayList<String>();
		List<String> headsFirst = new ArrayList<String>();
		keys.add("name");
		heads.add("姓名");
		keys.add("mobile");
		heads.add("手机号");
		keys.add("tel");
		heads.add("电话");
		keys.add("createTime");
		heads.add("创建时间");
		keys.add("status");
		heads.add("推送状态");
		keys.add("pushTime");
		heads.add("推送时间");
		keys.add("firsrErrorTime");
		heads.add("第一次推送失败时间");
		keys.add("latErrorTime");
		heads.add("最后一次推送失败时间");
		keys.add("pushCount");
		heads.add("推送次数");
		keys.add("responseStr");
		heads.add("推送结果");
		int companyId = OnLine.getCurrentUserDetails().getCompanyId(); 
		String useId=OnLine.getCurrentUserDetails().getUserId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		params.put("useId", useId);
		String startTime = request.getParameter("startTime");
		if(startTime != null && !startTime.equals("")){
			params.put("startTime", formatter.parse(startTime));//+" 00:00:00"
		}
		String endTime = request.getParameter("endTime");
		if(endTime != null && !endTime.equals("")){
			params.put("endTime", formatter.parse(endTime));//+" 23:59:59"
		}
		String status = request.getParameter("status");
		if(status != null && status.trim().length() > 0){
			params.put("status", status);
		}
		String phoneNumber = request.getParameter("phoneNumber");
		if(phoneNumber != null && phoneNumber.trim().length() > 0){
			params.put("phoneNumber", phoneNumber);
		}
		this.notifyService.clearNotifyTime(companyId, OnLine.getCurrentUserDetails().getUserId());
		List<ApiPushLog> apiPushLog = this.apiPushLogService.downApiPushVisitorInfo(PageConfig.createPageConfig(request), params);
		//List<ApiPushLog> apiPushLog=page.getRows();
		if(apiPushLog.size()>=1){
			for(ApiPushLog log : apiPushLog){
				Map<String, Object> mapApi = new HashMap<String, Object>();
				mapApi.put("name", log.getName());
				mapApi.put("mobile", log.getMobile());
				mapApi.put("tel", log.getTel());
				mapApi.put("createTime",log.getCreateTime()==null?log.getCreateTime():sdf.format(log.getCreateTime()));
				mapApi.put("status", log.getStatus()==0?"失败":"成功");
				mapApi.put("pushTime", log.getPushTime()==null?log.getPushTime():sdf.format(log.getPushTime()));
				mapApi.put("firsrErrorTime", log.getFirsrErrorTime()==null?log.getFirsrErrorTime():sdf.format(log.getFirsrErrorTime()));
				mapApi.put("latErrorTime", log.getLatErrorTime()==null?log.getLatErrorTime():sdf.format(log.getLatErrorTime()));
				mapApi.put("pushCount", log.getPushCount());
				mapApi.put("responseStr", log.getResponseStr());
				listMap.add(mapApi);
			}
		}
		keysFirst.addAll(keys);
		headsFirst.addAll(heads);
		response.setContentType("application/download");
		response.setHeader("Content-Disposition", "attachment;filename="
				+ URLEncoder.encode("名片推送日记导出", "utf-8") + ".xls");
		String title = "名片推送日记";
		ExportUtil.export(listMap, title,
				keysFirst.toArray(new String[keys.size()]),
				headsFirst.toArray(new String[heads.size()]),
				response.getOutputStream());
	}
}
