package cn.jesong.webcall.cuour.entity;

import java.io.Serializable;
import java.util.Date;

public class Card implements Serializable {
    private static final long serialVersionUID = 1L;
	/**
	 * 默认， 等待分配
	 */
	public final static int STATUS_DEFAULT = 0;
	
	/**
	 * 系统分配
	 */
	public final static int STATUS_SYSTEM_ALLOCATIONED = 1;
	
	/**
	 * 等待人工分配
	 */
	public final static int STATUS_WAIT_USE_ALLOCATION = 2;
	
	/**
	 * 人工分配
	 */
	public final static int STATUS_USE_ALLOCATIONED = 3;
	
	/**
	 * 高意向名片分配
	 */
	public final static int STATUS_SALE_ALLOCATIONED = 6;
	
	/**
	 * 已处理
	 */
	public final static int STATUS_FINISHED = 4;
	
	/**
	 * 重复线索
	 */
	public final static int STATUS_REPEAT = 5;
	
	private int id;
	
	private String name;
	
	private int companyId;
	
	private String mobile;
	
	private Date createTime;
	
	private String createUserId;
	
	/**
	 * 项目ID
	 */
	private int subjectId;
	
	/**
	 * 校区ID
	 */
	private int schooleId;
	
	/**
	 * 回电时间
	 */
	private Date callbackTime;
	
	/**
	 * 是否有效
	 */
	private int isValid;
	
	/**
	 * 是否退回
	 */
	private int isBack;
	
	/**
	 * 分配状态
	 */
	private int allocationStatus;
	
	/**
	 * 修改标识
	 */
	private String modifyIdentity;
	
	/**
	 * 是否处理
	 */
	private int finished = 0;
	
	/**
	 * 分处销售ID
	 */
	private String userId;
	
	/**
	 * 分配时间
	 */
	private Date allocationTime;


	/**
	 * 销售ID
	 */
	private String saleId;
	
	private String tel;
	
	private String repName;

	private String qq;
	
	private String msn;
	
	private String chatUrl;

	private String firstUrl;
	
	private String referUrl;
    /**
     * 新增字段，这个字段来判断是否分配，mq after方法里会用到
     */
    private boolean allocation;

	public String getChatUrl() {
		return chatUrl;
	}

	public void setChatUrl(String chatUrl) {
		this.chatUrl = chatUrl;
	}

	public String getFirstUrl() {
		return firstUrl;
	}

	public void setFirstUrl(String firstUrl) {
		this.firstUrl = firstUrl;
	}

	public String getReferUrl() {
		return referUrl;
	}

	public void setReferUrl(String referUrl) {
		this.referUrl = referUrl;
	}

	public Date getAllocationTime() {
		return allocationTime;
	}

	public void setAllocationTime(Date allocationTime) {
		this.allocationTime = allocationTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getFinished() {
		return finished;
	}

	public void setFinished(int finished) {
		this.finished = finished;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public int getSchooleId() {
		return schooleId;
	}

	public void setSchooleId(int schooleId) {
		this.schooleId = schooleId;
	}

	public Date getCallbackTime() {
		return callbackTime;
	}

	public void setCallbackTime(Date callbackTime) {
		this.callbackTime = callbackTime;
	}

	public int getIsValid() {
		return isValid;
	}

	public void setIsValid(int isValid) {
		this.isValid = isValid;
	}

	public int getIsBack() {
		return isBack;
	}

	public void setIsBack(int isBack) {
		this.isBack = isBack;
	}

	public int getAllocationStatus() {
		return allocationStatus;
	}

	public void setAllocationStatus(int allocationStatus) {
		this.allocationStatus = allocationStatus;
	}

	public String getModifyIdentity() {
		return modifyIdentity;
	}

	public void setModifyIdentity(String modifyIdentity) {
		this.modifyIdentity = modifyIdentity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Date getCreateTime() {
		return this.createTime == null ? new Date() : this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getSaleId() {
		return saleId;
	}

	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	
	public boolean isSaleCard(){
		return this.saleId != null && this.saleId.equals(this.userId);
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getRepName() {
		return repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	
	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getMsn() {
		return msn;
	}

	public void setMsn(String msn) {
		this.msn = msn;
	}

    public boolean isAllocation() {
        return allocation;
    }

    public void setAllocation(boolean allocation) {
        this.allocation = allocation;
    }
}
