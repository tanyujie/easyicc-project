package cn.jesong.webcall.cuour.api.pattern;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public abstract class ApiPatternFactory {
	
	private static IApiPattern fa = new IndexOfPattern();
	
	public static IApiPattern getInstance(ActionConfig config){
		if(ContainEnum.INDEXOF.toString().toLowerCase().equals(config.getContainType())){
			return fa;
		}
		return null;
	}
	
}
