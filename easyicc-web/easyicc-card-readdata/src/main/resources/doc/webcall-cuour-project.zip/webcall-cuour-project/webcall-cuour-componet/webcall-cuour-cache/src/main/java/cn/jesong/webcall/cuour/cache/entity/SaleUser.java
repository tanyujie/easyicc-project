package cn.jesong.webcall.cuour.cache.entity;

import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.Sales;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaleUser extends Sales{
	
	private final static Log _logger = LogFactory.getLog(SaleUser.class);
	
	private String realName;

	private String schoolName;
	
	private String subjectName;
	
	private String businessGroupName;
	
	private String salesTypeName;
	
	private List<Card> cards = new ArrayList<Card>();
	
	private boolean weixinPushStatus = false;
	private String weiXinOpenId = null;

	/**
	 * 有效量
	 */
	private int validCount;
	
	/**
	 * 退回量
	 */
	private int backCount;
	
	/**
	 * 已分配量
	 */
	private int allocationCount;
	
	/**
	 * 当天已分配量
	 */
	private int actualAllocationCount;
	
	/**
	 * 当天有效量
	 */
	private int actualValidCount;
	
	/**
	 * 已处理量
	 */
	private int finishedCount;
	
	/**
	 * 超期未处理量
	 */
	private int expiredCount;
	
	/**
	 * 分配权重
	 */
	private int allocationWeight;
	
	/**
	 * 退回率
	 */
	private double backRatio;
	
	/**
	 * 合理比率
	 */
	private double fairRatio;
	
	/**
	 * 实际比率
	 */
	private double actualRatio;
	
	/**
	 * 最大分配量
	 */
	private int maxCardSize;
	
	/**
	 * 高意向名片分配量
	 */
	private int saleAllocationCount;
	
	/**
	 * 高意向名片处理量
	 */
	private int saleFinishedCount;
	
	
	
	
	public int getSaleAllocationCount() {
		return saleAllocationCount;
	}


	public void setSaleAllocationCount(int saleAllocationCount) {
		this.saleAllocationCount = saleAllocationCount;
	}


	public int getSaleFinishedCount() {
		return saleFinishedCount;
	}


	public void setSaleFinishedCount(int saleFinishedCount) {
		this.saleFinishedCount = saleFinishedCount;
	}


	public int getActualValidCount() {
		return actualValidCount;
	}


	public void setActualValidCount(int actualValidCount) {
		this.actualValidCount = actualValidCount;
	}


	public int getActualAllocationCount() {
		return actualAllocationCount;
	}


	public void setActualAllocationCount(int actualAllocationCount) {
		this.actualAllocationCount = actualAllocationCount;
	}


	public int getMaxCardSize() {
		return maxCardSize;
	}


	public void setMaxCardSize(int maxCardSize) {
		this.maxCardSize = maxCardSize;
	}


	public double getBackRatio(){
		return this.backRatio;
	}
	
	
	public double getFairRatio() {
		return fairRatio;
	}

	public void setFairRatio(double fairRatio) {
		this.fairRatio = fairRatio;
	}

	public double getActualRatio() {
		return actualRatio;
	}

	public void setActualRatio(double actualRatio) {
		this.actualRatio = actualRatio;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public int getAllocationWeight() {
		return allocationWeight;
	}

	public void setAllocationWeight(int allocationWeight) {
		this.allocationWeight = allocationWeight;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getBusinessGroupName() {
		return businessGroupName;
	}

	public void setBusinessGroupName(String businessGroupName) {
		this.businessGroupName = businessGroupName;
	}

	public String getSalesTypeName() {
		return salesTypeName;
	}

	public void setSalesTypeName(String salesTypeName) {
		this.salesTypeName = salesTypeName;
	}

	public List<Card> getCards() {
		return cards;
	}
	
	public boolean canAllocationCard(Date callbackTime, int size, int timeInterval, int maxAllocationSize){
		synchronized(this){
			boolean flag = true;
			boolean maxFlag = false;
			//是否达到当天最大分配量(全局或个人)
			if(maxAllocationSize <= this.allocationCount || maxAllocationSize <= this.actualAllocationCount || this.maxCardSize <= this.actualValidCount){
				_logger.warn(String.format("[%s]达到最大分配量, maxAllocationSize[%s], allocationCount[%s], actualAllocationCount[%s], maxCardSize[%s], actualValidCount[%s]", 
						this.getUserId(), maxAllocationSize, this.allocationCount, this.actualAllocationCount, this.maxCardSize, this.actualValidCount));
				maxFlag = true;
			}
			int count = 0;
			for(int i=this.cards.size()-1; i>=0 && !maxFlag; i--){
				Card card = this.cards.get(i);
				//需要未处理
				if(card.getFinished() == 0 && (card.getCallbackTime() == null || callbackTime == null || Math.abs(card.getCallbackTime().getTime() - callbackTime.getTime()) <= timeInterval)){
					count++;
				}
				
				if(count >= size){
					_logger.warn(String.format("[%s]未处理量达到[%s]>=[%s]", this.getUserId(), count, size));
					flag = false;
					break;
				}
			}
			return flag && !maxFlag;
		}
	}
	
	public void allocationCard(Card card){
		synchronized(this){
			if(!card.isSaleCard()){
				this.cards.add(card);
				this.validCount++;
				this.allocationCount++;
				this.actualAllocationCount++;
				this.actualValidCount++;
				this.backRatio = (new BigDecimal(this.backCount*100)).divide(new BigDecimal(this.allocationCount), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}else{
				this.saleAllocationCount++;
			}
		}
	}
	
	public void setBackRatio(double backRatio) {
		this.backRatio = backRatio;
	}

	public int getValidCount() {
		return validCount;
	}

	public int getBackCount() {
		return backCount;
	}
	
	
	public void back(int cardId){
		synchronized(this){
			Card c = null;
			for(Card card : cards){
				if(card.getId() == cardId){
					c = card;
					break;
				}
			}
			this.backCount++;
			this.validCount--;
			if(this.validCount < 0){
				this.validCount = 0;
			}
			this.actualValidCount--;
			if(this.actualValidCount < 0){
				this.actualValidCount = 0;
			}
			if(c != null){
				this.cards.remove(c);
			}
			if(this.allocationCount>0){
				this.backRatio = (new BigDecimal(this.backCount*100)).divide(new BigDecimal(this.allocationCount), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}
		}
	}
	
	public void finished(int cardId, boolean isSaleCard){
		synchronized(this){
			if(isSaleCard){
				this.saleFinishedCount++;
			}else{
				Card c = null;
				for(Card card : cards){
					if(card.getId() == cardId){
						c = card;
						break;
					}
				}
				if(c != null){
					this.cards.remove(c);
				}
				this.finishedCount++;
			}
		}
	}
	
	public int getAllocationCount() {
		return allocationCount;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public void setValidCount(int validCount) {
		if(validCount > 0){
			this.validCount = validCount;
		}else{
			this.validCount = 0;
		}
	}

	public void setBackCount(int backCount) {
		this.backCount = backCount;
		if(this.allocationCount>0){
			this.backRatio = (new BigDecimal(this.backCount*100)).divide(new BigDecimal(this.allocationCount), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
		}
	}

	public void setAllocationCount(int allocationCount) {
		this.allocationCount = allocationCount;
	}
	
	/*public void initAddCard(Card card){
		this.allocationCard(card);
		//this.cards.add(card);
	}*/


	public int getFinishedCount() {
		return finishedCount;
	}


	public void setFinishedCount(int finishedCount) {
		this.finishedCount = finishedCount;
	}


	public int getExpiredCount() {
		return expiredCount;
	}


	public void setExpiredCount(int expiredCount) {
		this.expiredCount = expiredCount;
	}


	public boolean isOpenWeixinPush() {
		return weixinPushStatus;
	}


	public void setWeixinPushStatus(boolean weixinPushStatus) {
		this.weixinPushStatus = weixinPushStatus;
	}


	public String getUserWeiXinOpenId() {
		return weiXinOpenId;
	}

	public void setUserWeiXinOpenId(String weiXinOpenId) {
		this.weiXinOpenId = weiXinOpenId;
	}
	
}
