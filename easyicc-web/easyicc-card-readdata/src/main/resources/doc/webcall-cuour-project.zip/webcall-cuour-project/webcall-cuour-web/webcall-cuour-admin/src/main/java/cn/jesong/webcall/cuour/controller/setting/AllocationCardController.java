package cn.jesong.webcall.cuour.controller.setting;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.entity.CuourCard;
import cn.jesong.webcall.cuour.redis.ServiceFactory;
import cn.jesong.webcall.cuour.service.AllocationCardService;
import cn.jesong.webcall.cuour.service.CardConfigService;
import cn.jesong.webcall.cuour.service.CardLogService;
import cn.jesong.webcall.cuour.service.NotifyService;
import cn.jesong.webcall.cuour.service.setting.BackTypeService;
import cn.jesong.webcall.cuour.service.setting.CardRuleService;
import cn.jesong.webcall.cuour.service.setting.SchoolService;
import cn.jesong.webcall.cuour.service.setting.SubjectService;
import cn.jesong.webcall.cuour.user.CuourUserDetail;
import cn.jesong.webcall.logic.UserMgrException;

@Controller
@RequestMapping("/setting/allocation")
public class AllocationCardController {
    private final static Log _logger = LogFactory.getLog(AllocationCardController.class);
	private final static String PREFIX = "/setting/allocation";
	private final static String REDIS_OPEN_QUERY_ALLSALES_KEY = "allocationCard:openQueryAllSales:company:";
	private final static String OPEN_QUERY_ALL_SALES = "1";
	
	private final static String CLOSE_QUERY_ALL_SALES = "2";
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	@Autowired
	private CardConfigService cardConfigService;
	
	@Autowired
	private AllocationCardService allocationCardService;
	
	@Autowired
	private SubjectService subjectService;
	
	@Autowired
	private SchoolService schoolService;
	
	@Autowired
	private NotifyService notifyService;
	
	@Autowired
	private BackTypeService backTypeService;
	
	@Autowired
	private CardLogService cardLogService;
	
	@Autowired
	private CardRuleService ruleService;
	
	@RequestMapping("/index")
	public String index(ModelMap model) throws Exception{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		model.put("cols", cardConfigService.getShowVisitorCols(companyId));
		model.put("subjects", subjectService.getListByTemplate(params));
		model.put("schools", this.schoolService.getListByTemplate(params));
		model.put("backTypes", this.backTypeService.getListByTemplate(params));
		
		CardRule rule = this.ruleService.get(companyId);
		if(rule == null){
			rule = new CardRule();
		}
		model.put("defaultSubjectId", rule.getDefaultSubjectId());
		model.put("defaultSchoolId", rule.getDefaultSchoolId());
		// 测试数据发送
		try {
		//	Card card = new Card();
		//	card.setCompanyId(1);
		//	card.setId(1989212);
		//	String userId = OnLine.getCurrentUserDetails().getUserId();
		//	weixinService.action(card)
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return PREFIX + "/index";
	}
	
	@RequestMapping("/query")
	@ResponseBody
	public Page<CuourCard> query(@RequestParam("status") int status, HttpServletRequest request) throws Exception{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId(); 
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		String startTime = request.getParameter("startTime");
		if(startTime != null){
			params.put("startTime", formatter.parse(startTime));//+" 00:00:00"
		}
		String endTime = request.getParameter("endTime");
		if(endTime != null){
			params.put("endTime", formatter.parse(endTime));//+" 23:59:59"
		}
		params.put("extColumn8", request.getParameter("subjectId"));
		params.put("extColumn9", request.getParameter("schoolId"));
		
		String backUserId = request.getParameter("backUserId");
		if(backUserId != null && !backUserId.equals("")){
			params.put("backUserId", "%"+backUserId+"%");
		}
		/*String isBack = request.getParameter("isBack");
		if(isBack != null && !isBack.equals("")){
			params.put("isBack", Integer.parseInt(isBack));
		}
		String isExpired = request.getParameter("isExpired");
		if(isExpired != null && !isExpired.equals("")){
			params.put("isExpired", Integer.parseInt(isExpired));
		}*/
		String backType = request.getParameter("backType");
		if(backType != null && !backType.equals("")){
			params.put("backType", Integer.parseInt(backType));
		}
		this.notifyService.clearNotifyTime(companyId, OnLine.getCurrentUserDetails().getUserId());
		Page<CuourCard> page = this.cardConfigService.pageVisitorCard(PageConfig.createPageConfig(request), params, status);
		//遍历循环如果该名片没有subjectId和 schoolId的话将默认的赋值过去(后来改用从页面将默认值传过去)
		/*List<CuourCard> list=page.getRows();
		CardRule rule = this.ruleService.get(companyId);
		if(rule == null){
			rule = new CardRule();
		}
		for(CuourCard card : list){
			String subjectId=card.getExtColumn8();//subjectId
			String schollId=card.getExtColumn9();//schoolId
			if(subjectId==null && (rule.getDefaultSubjectId())!=0) {
				card.setExtColumn8(String.valueOf(rule.getDefaultSubjectId()));
			}
			if(schollId==null && (rule.getDefaultSchoolId())!= 0) {
				card.setExtColumn9(String.valueOf(rule.getDefaultSchoolId()));
			}
		}*/
		//CardRule rule = this.cardRuleService.get(companyId);
		//long now = new Date().getTime();
		//if(rule != null && rule.getMobileHideTime() > 0){
			CuourUserDetail ud = (CuourUserDetail)OnLine.getCurrentUserDetails();
			if(ud.hasDataPermission("3d5c4d88-032f-409f-bf74-1b2f429d1216", "hideTelephone", "1")){
				for(CuourCard card : page.getRows()){
					//if(card.getCreateTime() == null || now - card.getCreateTime().getTime() < rule.getMobileHideTime() * 60 * 1000){
						String noteString=card.getNote();
						String mobileString=card.getMobile();
						String telString=card.getTel();
						String qqString=card.getQq();
						String msnString=card.getMsn();
						card.setMobile(hidePhoneRule(mobileString));
						card.setQq(hidePhoneRule(qqString));
						card.setTel(hidePhoneRule(telString));
						card.setNote(hideMSNRule(noteString));
						card.setMsn(hideMSNRule(msnString));
						/*if(mobile != null && !mobile.equals("")){
							if(mobile.length() == 11){
								mobile = mobile.substring(0, 3) + "****" + mobile.substring(7, mobile.length());
							}else if(mobile.length() > 4){
								mobile = mobile.substring(0, mobile.length() - 4) + "****";
							}else{
								mobile = "****";
							}
							card.setMobile(mobile);
						}*/
					//}
				}
			}
		//}
		return page;
	}

    @RequestMapping("/saleUsers")
    @ResponseBody
    public List<Map<String, Object>> getCanAllocationSaleUser(@RequestParam("subjectId") int subjectId,
                                                              @RequestParam("schoolId") int schoolId,@RequestParam("realName") String realName,HttpServletRequest request) throws UserMgrException, Exception{
        Long _beginTime = System.currentTimeMillis();
        Integer companyId = OnLine.getCurrentUserDetails().getCompanyId();
//		List<SaleUser> users = this.allocationCardService.getCanAllocationSaleUser(companyId, subjectId, schoolId);

        List<SaleUser> users = Lists.newArrayList();
//		Map<String, String> status = this.allocationCardService.getStatus(companyId);
        Map<String, String> status = Maps.newHashMap();
        this.allocationCardService.getCanAllocationSaleUserAndStatus(companyId, subjectId, schoolId,users,status);


        Long _endTime2 = System.currentTimeMillis();
        _logger.info(String.format("通过公司ID[%s]获取所有的用户对应的状态map耗时[%s]毫秒", companyId,(_endTime2-_beginTime)));

        List<Map<String, Object>> list = Lists.newArrayList();
        //这个key是放到redis里面，客户是否开启了查询全部销售的开关
        String isOpenStr = ServiceFactory.getMessageCache().getRedisService()
                .get(REDIS_OPEN_QUERY_ALLSALES_KEY + companyId + ":userId"
                        + OnLine.getCurrentUserDetails().getUserId());
        boolean isOpen = false;
        if(StringUtils.isNotBlank(isOpenStr)){
            if(isOpenStr.equals(OPEN_QUERY_ALL_SALES)){
                isOpen = true;
            }
        }
        //如果传过来的查询不为空，但是去除空格后为空，则直接返回一个空字符串
        if(StringUtils.isNotBlank(realName)){
            realName = realName.replaceAll("\\s*", "");
            if(StringUtils.isBlank(realName)){
                return list;
            }

        }
        for(SaleUser user : users){
            Map<String, Object> info = Maps.newHashMap();
            info.put("schoolName", user.getSchoolName());
            info.put("subjectName", user.getSubjectName());
            info.put("businessGroupName", user.getBusinessGroupName());
            //如果查询销售关键字不为空，则需要对比销售名字 和 销售ID，如果两个都不匹配，则不组装
            if(StringUtils.isNotBlank(realName)){
                if(!user.getRealName().contains(realName) && !user.getUserId().contains(realName)){
                    continue;
                }
            }
            info.put("userId", user.getUserId());
            info.put("realName", user.getRealName());
            info.put("allocationCount", user.getAllocationCount());
            info.put("validCount", user.getValidCount());
            info.put("backCount", user.getBackCount());
            info.put("backRatio", user.getBackRatio());
            info.put("actualRatio", user.getActualRatio());
            info.put("fairRatio", user.getFairRatio());
            info.put("finishedCount", user.getFinishedCount());
            info.put("expiredCount", user.getExpiredCount());
            info.put("allocationWeight", user.getAllocationWeight());
            info.put("maxCardSize", user.getMaxCardSize());
            info.put("actualAllocationCount", user.getActualAllocationCount());
            info.put("actualValidCount", user.getActualValidCount());
            String st = status.get(user.getUserId());
            String saleStatus = st == null ? "offline" : st;
            //如果销售的状态为下线，并且查询全部开关为 false，则不组装下线的销售列表
            if(saleStatus.equals("offline")){
                if(!isOpen){
                    continue;
                }
            }
            info.put("status", st == null ? "offline" : st);
            info.put("saleAllocationCount", user.getSaleAllocationCount());
            info.put("saleFinishedCount", user.getSaleFinishedCount());
            list.add(info);
        }

        Long _endTime3 = System.currentTimeMillis();
        _logger.info(String.format("最终筛选出销售集合耗时[%s]毫秒", companyId,(_endTime3-_endTime2)));
//		以下是测试数据，测试通过后需要将以下代码删掉
//		for(int i=0;i<5;i++){
//			Map<String, Object> info = new HashMap<String, Object>();
//			String userRealName = "realName"+i;
//			String userId = i+"";
//			if(StringUtils.isNotBlank(realName)){
//				realName = realName.replaceAll("\\s*", "");
//				if(StringUtils.isBlank(realName)){
//					continue;
//				}
//				if(!userRealName.contains(realName) && !userId.contains(realName)){
//					continue;
//				}
//			}
//			info.put("schoolName", "schoolName"+i);
//			info.put("subjectName", "subjectName"+i);
//			info.put("businessGroupName", "businessGroupName"+i);
//			info.put("userId", i);
//			info.put("realName", "realName"+i);
//			info.put("allocationCount", 10);
//			info.put("validCount", 10);
//			info.put("backCount", 0);
//			info.put("backRatio", 0.55);
//			info.put("actualRatio", 0.33);
//			info.put("fairRatio", 0.22);
//			info.put("finishedCount", 5);
//			info.put("expiredCount", 4);
//			info.put("allocationWeight", 0.11);
//			info.put("maxCardSize", 50);
//			info.put("actualAllocationCount", 20);
//			info.put("actualValidCount", 30);
//			if(i==0){
//				info.put("status",  "offline");
//			}else if(i==1){
//				info.put("status",  "online");
//			}else if(i==2){
//				info.put("status",  "leave");
//			}else if(i==3){
//				info.put("status",  "buzy");
//			}else if(i==4){
//				info.put("status",  "offline");
//			}
//			
//			info.put("saleAllocationCount", 20);
//			info.put("saleFinishedCount", 10);
//			
//			if(info.get("status").equals("offline")){
//				if(!isOpen){
//					continue;
//				}
//				
//			}
//			
//			list.add(info);
//		}

        return list;
    }

	/**
	 * 通过此方法，可以将【是否查询全部销售开关】的状态放到redis里面
	 * @param isOpen
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/openQueryAllSales", method = RequestMethod.POST)
	@ResponseBody
	public void openQueryAllSales(@RequestParam("isOpen") boolean isOpen, HttpServletResponse response)
			throws IOException {

		try {
			if (isOpen) {
				//打开是1
				ServiceFactory.getMessageCache().getRedisService()
						.set(REDIS_OPEN_QUERY_ALLSALES_KEY + OnLine.getCurrentUserDetails().getCompanyId() + ":userId"
								+ OnLine.getCurrentUserDetails().getUserId(), OPEN_QUERY_ALL_SALES);
				RespResult.getSuccess().writeToResponse(response);
			} else {
				//关闭是2
				ServiceFactory.getMessageCache().getRedisService()
						.set(REDIS_OPEN_QUERY_ALLSALES_KEY + OnLine.getCurrentUserDetails().getCompanyId() + ":userId"
								+ OnLine.getCurrentUserDetails().getUserId(), CLOSE_QUERY_ALL_SALES);
				RespResult.getSuccess().writeToResponse(response);
			} 
		} catch (Exception e) {
			RespResult.getError("操作失败").writeToResponse(response);
		}
	}
	
	
	@RequestMapping(value="/allocation", method=RequestMethod.GET)
	public String allocation(@RequestParam("subjectId") int subjectId, 
			@RequestParam("cardId") int cardId, @RequestParam("schoolId") int schoolId,HttpServletRequest request){
		String queryAllSalesKey = REDIS_OPEN_QUERY_ALLSALES_KEY + OnLine.getCurrentUserDetails().getCompanyId() + ":userId"
				+ OnLine.getCurrentUserDetails().getUserId();
		String openValue = ServiceFactory.getMessageCache().getRedisService().get(queryAllSalesKey);
		if(null==openValue || "".equals(openValue)){
			request.getSession().setAttribute("isOpen", false);
		}else{
			if(openValue.equals("1")){
				//打开分配页面展示所有客服
				request.getSession().setAttribute("isOpen", true);
			}else{
				request.getSession().setAttribute("isOpen", false);
			}
		}
				
		
		return PREFIX + "/allocation";
	}
	
	@RequestMapping(value="/allocation", method=RequestMethod.POST)
	public void allocation(@RequestParam("allocationCardId") int cardId, 
			@RequestParam("allocationUserId") String userId, HttpServletResponse response) throws IOException{
		if(!userId.equals("")){
			this.allocationCardService.userAllocationCard(OnLine.getCurrentUserDetails().getCompanyId(), cardId, userId, OnLine.getCurrentUserDetails().getUserId());
			RespResult.getSuccess().writeToResponse(response);
		}else{
			RespResult.getError("请选择一个要分配的咨询师！").writeToResponse(response);
		}
		
	}
	
	@RequestMapping("/allocation/oneKey")
	public void allocation(@RequestParam("cardId") int cardId, HttpServletResponse response) throws IOException{
		boolean flag = this.allocationCardService.allocation(cardId);
		if(flag){
			RespResult.getSuccess().writeToResponse(response);
		}else{
			RespResult.getError("一键分配失败, 未找到合适的分配客服").writeToResponse(response);
		}
	}
	
	@RequestMapping("/notValidate")
	public void notValidate(@RequestParam("cardId") int cardId, HttpServletResponse response) throws IOException{
		this.allocationCardService.setNotValidate(OnLine.getCurrentUserDetails().getCompanyId(), cardId);
		RespResult.getSuccess().writeToResponse(response);
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String edit(@RequestParam("cardId") int cardId, ModelMap model){
		model.put("entity", this.allocationCardService.getCard(cardId));
		return PREFIX + "/edit";
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public void edit(@RequestParam("id") int id, @RequestParam("modifyIdentity") String modifyIdentity, 
			@RequestParam("subjectId") int subjectId, @RequestParam("schooleId") int schooleId, HttpServletResponse response) throws IOException{
		boolean flag = this.allocationCardService.updateCard(id, modifyIdentity, subjectId, schooleId);
		if(flag){
			RespResult.getSuccess().writeToResponse(response);
		}else{
			RespResult.getError("该名片已被修改或者不存在， 请刷新后重试").writeToResponse(response);
		}
		
	}
	
	@RequestMapping("/log/index")
	public String logIndex(ModelMap model) {
		return PREFIX + "/log";
	}
	
	@RequestMapping("/log/query")
	@ResponseBody
	public Page<Map<String, Object>> logQuery(HttpServletRequest request) throws ParseException{
		Map<String, Object> params = new HashMap<String, Object>();
		String startTime = request.getParameter("startTime");
		if(startTime != null){
			params.put("startTime", formatter.parse(startTime));//+" 00:00:00"
		}
		String endTime = request.getParameter("endTime");
		if(endTime != null){
			params.put("endTime", formatter.parse(endTime));//+" 23:59:59"
		}
		String allocationType = request.getParameter("allocationType");
		if(allocationType != null && !allocationType.equals("")){
			params.put("allocationType", Integer.parseInt(allocationType));
		}
		String userId = request.getParameter("userId");
		if(userId != null && !userId.equals("")){
			params.put("userId", userId);
		}
		String mobile = request.getParameter("mobile");
		if(mobile != null && !mobile.equals("")){
			params.put("mobile", "%"+mobile+"%");
		}
		return this.cardLogService.pageQuery2(OnLine.getCurrentUserDetails().getCompanyId(), PageConfig.createPageConfig(request), params);
	}
	
	/*
	 * 
	 * 手动按钮清除名片分配的缓存
     */
	@RequestMapping(value="/clearCache", method=RequestMethod.POST)
	public void clearCache(HttpServletResponse response) throws IOException{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		String userId = OnLine.getCurrentUserDetails().getUserId();
		//System.out.println("测试");
		this.allocationCardService.clearCache(companyId,userId);
		
		//TODO : 清除轮循缓存
		this.allocationCardService.clearAlternateCache(companyId,userId);
	}
	
	public static String hidePhoneRule(String str){
		if(str != null && ! str.equals("")){
			return str.replaceAll("([0-9]{3}-?)[0-9]{4}([0-9]{3,6})","$1****$2");
		}else {
			return "";
		}
		
	}
	//微信号隐藏和备注的隐藏
	public static String hideMSNRule(String fullString){
		String returnString ="";
		StringBuilder sb = new StringBuilder();
		String reg = "([\\S]{3})(.*)([\\S]{2})";
		Pattern r = Pattern.compile(reg);
		if(fullString != null && fullString != ""){
			fullString = fullString.replace("，", ",");
			String [] atring =fullString.split(",");
			for(int i=0;i<atring.length;i++){
				Matcher m = r.matcher(atring[i]);
				String hideString = "";
				if(m.find()){
					for (int y = 0; y <m.group(2).length(); y++) {
						hideString=hideString+"*";
		            }
					returnString += m.group(1)+hideString+m.group(3);
		        }else{
		        	returnString = fullString;
		        }
				if(i<atring.length-1){
					returnString +=",";
				}
			}
		}
		return returnString;

	}
	public static void main(String[] args){
		String realName = "11"
				+ " 1";
		realName = realName.replaceAll("\\s*", "");
		System.out.println("realName==="+realName);
	}
}
