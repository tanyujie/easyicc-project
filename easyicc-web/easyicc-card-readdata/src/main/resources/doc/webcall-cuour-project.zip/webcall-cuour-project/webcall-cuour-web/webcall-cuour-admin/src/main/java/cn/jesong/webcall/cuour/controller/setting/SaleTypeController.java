package cn.jesong.webcall.cuour.controller.setting;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.SaleType;
import cn.jesong.webcall.cuour.service.setting.SaleTypeService;


@Controller
@RequestMapping("/setting/saleType")
public class SaleTypeController extends SimpleController<Integer, SaleType>{
	
	@Autowired
	private SaleTypeService saleTypeService;

	@Override
	protected String getPrefix() {
		return "/setting/saleType";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, SaleType> getHibernateService() {
		return saleTypeService;
	}

	@Override
	protected void beforeCreateOrUpdate(SaleType entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
	}
	
	

}

