package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.BackType;

@Service
public class BackTypeService extends HibernateDAO<Integer, BackType>{
	
	@Override
	protected Class<BackType> getEntityClass() {
		return BackType.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from BackType where / companyId = {companyId} / order by id desc";
	}

}
