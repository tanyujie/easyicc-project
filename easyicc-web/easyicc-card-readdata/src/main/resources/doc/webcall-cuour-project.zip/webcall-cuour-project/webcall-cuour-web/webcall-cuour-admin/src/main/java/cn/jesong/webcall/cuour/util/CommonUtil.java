package cn.jesong.webcall.cuour.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 公共常用工具
 * @author zhanglu
 *
 */
public class CommonUtil {

	private final static Log _logger = LogFactory.getLog(CardUtil.class);

	/**
	 * 获取工号
	 * name value规则  名称[工号]
	 * @param name
	 * @return
	 */
	public static String getEmployeeNumber(String name) {
		if (StringUtils.isEmpty(name))
			return null;

		String number = "";
		Pattern pattern = Pattern.compile("(?<=\\[).*?(?=\\])");
		Matcher m = pattern.matcher(name);
		
		while (m.find()) {
			number = m.group(0);
			System.out.println(m.group(0));
		}
		
		return number;
	}
}
