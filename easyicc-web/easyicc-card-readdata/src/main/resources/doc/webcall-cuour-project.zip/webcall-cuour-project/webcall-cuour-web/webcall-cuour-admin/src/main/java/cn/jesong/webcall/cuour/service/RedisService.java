package cn.jesong.webcall.cuour.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.jesong.webcall.cuour.redis.IRedisService;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

public class RedisService implements IRedisService{

	private final static Log _logger = LogFactory.getLog(RedisService.class);

	private ShardedJedisPool pool;

	public RedisService(ShardedJedisPool pool) {
		this.pool = pool;
	}

	/**
	 * 判断缓存中是否有对应的value
	 *
	 * @param key
	 * @return
	 */
	public boolean exists(final String key) {
		ShardedJedis shardedJedis = pool.getResource();
		boolean info = false;
		try {
			info = shardedJedis.exists(key);
		} finally {
			pool.returnResource(shardedJedis);
		}
		return info;
	}

	public void set(String key, String value, Integer time) {
		ShardedJedis shardedJedis = pool.getResource();
		try {
			shardedJedis.set(key, value);
			// 过期时间,默认1小时
			if (time == null || time == 0)
				time = 1 * 60 * 60;
			shardedJedis.expire(key, time);
		} finally {
			pool.returnResource(shardedJedis);
		}
	}

	public String get(String key) {
		ShardedJedis shardedJedis = pool.getResource();
		String value = "";
		try {
			value = shardedJedis.get(key);
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
		} finally {
			pool.returnResource(shardedJedis);
		}
		return value;
	}

	public void remove(String key) {
		ShardedJedis shardedJedis = pool.getResource();
		try {
			shardedJedis.del(key);
		} finally {
			pool.returnResource(shardedJedis);
		}
	}

	public void set(String key, String value) {
		set(key, value, null);
	}

}
