package cn.jesong.webcall.cuour.service;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.CardApiPushLog;
import cn.jesong.webcall.cuour.entity.VisitorCardData;
import cn.jesong.webcall.cuour.log.dao.CardLogDao;

@Service
public class CardPushLogService{
	
	private final static Log _logger = LogFactory.getLog(CardPushLogService.class);

	@Autowired
	private CardLogDao dao;
	
	public void saveLog(ActionConfig config, VisitorCardData cardData, String result, boolean matching) {
		CardApiPushLog cardApiPushLog = dao.getLog(cardData.getId());
		Date d = new Date();
		if(cardApiPushLog == null){
			CardApiPushLog log = new CardApiPushLog();
			log.setCardId(cardData.getId());
			log.setVisitorStaticId(cardData.getVisitorStaticId());
			log.setCompanyId(config.getCompanyId());
			log.setPushTime(d);
			if(cardData.getChatId() != null){
				log.setChatId(Integer.valueOf(cardData.getChatId()));
			}
			log.setPushCount(1);
			log.setResponseStr(result);
			if(!matching){
				log.setFirstErrorTime(d);
				log.setLastErrorTime(d);
				log.setStatus(0);
			}else{
				log.setStatus(1);
			}
			dao.saveLog(log);
			_logger.info("-------------------------------->CardPushLogService  新增分配日志结果，成功");
			return;
		}
		int pushCount = cardApiPushLog.getPushCount();
		pushCount++;
		cardApiPushLog.setPushCount(pushCount);
		cardApiPushLog.setResponseStr(result);
		cardApiPushLog.setVisitorStaticId(cardData.getVisitorStaticId());
		cardApiPushLog.setCompanyId(config.getCompanyId());
		if(cardData.getChatId() != null){
			cardApiPushLog.setChatId(Integer.valueOf(cardData.getChatId()));
		}
		cardApiPushLog.setPushTime(d);
		if(!matching){
			cardApiPushLog.setLastErrorTime(d);
			cardApiPushLog.setStatus(0);
		}else{
			cardApiPushLog.setStatus(1);
		}
		dao.saveOrUpdateLog(cardApiPushLog);
		_logger.info("-------------------------------->CardPushLogService  更新分配日志结果，成功");
	}

}
