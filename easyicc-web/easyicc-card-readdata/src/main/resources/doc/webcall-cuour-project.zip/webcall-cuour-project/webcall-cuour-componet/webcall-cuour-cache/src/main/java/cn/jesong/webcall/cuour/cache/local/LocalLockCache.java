package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.LockCache;
import cn.jesong.webcall.cuour.cache.entity.Lock;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 本地锁缓存
 * @author xieyulin
 *
 */
public class LocalLockCache implements LockCache{
	
	private ConcurrentHashMap<Integer, Lock> locks = new ConcurrentHashMap<Integer, Lock>();

	@Override
	public Lock getLock(int companyId) {
		return locks.get(companyId);
	}

	@Override
	public void init(int companyId) {
		Lock lock = new Lock(companyId);
		locks.putIfAbsent(companyId, lock);
	}

	@Override
	public void remove(int companyId) {
		this.locks.remove(companyId);
	}

}
