package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.ActionConfigCache;
import cn.jesong.webcall.cuour.entity.ActionConfig;

import java.util.HashMap;
import java.util.Map;

public class LocalActionConfigCache implements ActionConfigCache {
	
	private Map<Integer, ActionConfig> cache = new HashMap<Integer, ActionConfig>();

	@Override
	public ActionConfig getActionConfig(int companyId) {
		return cache.get(companyId);
	}

	@Override
	public void remove(int companyId) {
		cache.remove(companyId);
	}

	@Override
	public void init(ActionConfig ac) {
		cache.put(ac.getCompanyId(), ac);
	}
	@Override
	public void initNullConfig(int companyId) {
		cache.put(companyId, null);
	}
}
