package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 项目
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_cuour_subject")
public class Subject implements CompanySetting{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_cuour_subject_id_seq")
	@SequenceGenerator(name = "js_cuour_subject_id_seq", sequenceName = "js_cuour_subject_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 项目名称
	 */
	@Column(name = "name", nullable = false)
	private String name;
	
	/**
	 * 说明
	 */
	@Column(name = "desp", nullable = true)
	private String desp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesp() {
		return desp;
	}

	public void setDesp(String desp) {
		this.desp = desp;
	}
	
	
	
}
