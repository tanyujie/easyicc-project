package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.WeixinInfo;

/**
 * 微信service
 * @author hanjianxin
 *
 */
@Service
public class WeixinInfoService extends SettingService<Integer, WeixinInfo> {
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * 查询数据
	 * @param companyId
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List<WeixinInfo> getWeixinInfo(String userId) throws Exception {
		String sql = " select ID id,USER_ID userId,OPEN_ID openid,NICK_NAME nickName,USER_NAME userName,STATUS status,SEND_OPPORTUNITY sendOpportunity,COMPANY_ID companyId,COMPANY_NAME companyName from js_card_weixin_info where USER_ID = ? and OPEN_ID IS NOT NULL ";
		List<WeixinInfo> list = this.jdbcTemplate.query(sql, new Object[]{userId}, new WeixinInfoRowMapper());
		
		return list;
	}
	
	public WeixinInfo getWeixinInfoByOpenId(String openid) throws Exception {
		String sql = " select ID id,USER_ID userId,OPEN_ID openid,NICK_NAME nickName,USER_NAME userName,STATUS status,SEND_OPPORTUNITY sendOpportunity,COMPANY_ID companyId,COMPANY_NAME companyName from js_card_weixin_info where OPEN_ID = ? ";
		List<WeixinInfo> list = this.jdbcTemplate.query(sql, new Object[]{openid}, new WeixinInfoRowMapper());
		if(list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return new WeixinInfo();
		}
	}
	
	/**
	 * 添加动作配置
	 * @param ac
	 * @return
	 * @throws Exception
	 */
	public int updateUserId(String userId, String openid) throws Exception {
		int count = 0;
		if (userId != null && !"".equals(userId)) {
			String sql = "UPDATE js_card_weixin_info SET USER_ID=? WHERE OPEN_ID=?";
			count = this.jdbcTemplate.update(sql, WeixinInfo.class, userId, openid);
		}
		return count;
	}
	
	/**
	 * 添加微信信息
	 * @param ac
	 * @return
	 * @throws Exception
	 */
	public int insert(WeixinInfo weixin) throws Exception {
		int id = 0;
		if (weixin != null) {
			id = this.save(weixin);
		}
		return id;
	}
	
	class WeixinInfoRowMapper implements RowMapper<WeixinInfo>{
		@Override
		public WeixinInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			WeixinInfo wx = new WeixinInfo();
			wx.setId(rs.getInt("id"));
			wx.setNickName(rs.getString("nickName"));
			wx.setOpenid(rs.getString("openid"));
			wx.setUserId(rs.getString("userId"));
			wx.setUserName(rs.getString("userName"));
			wx.setStatus(rs.getInt("status"));
			wx.setSendOpportunity(rs.getString("sendOpportunity"));
			wx.setCompanyId(rs.getInt("companyId"));
			wx.setCompanyName(rs.getString("companyName"));
			
			return wx;
		}
	}

	@Override
	protected Class<WeixinInfo> getEntityClass() {
		return WeixinInfo.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from WeixinInfo order by id desc";
	}
	
}
