package cn.jesong.webcall.cuour.util;

import net.sf.json.JSONObject;
import cn.jesong.webcall.cuour.entity.CardItem;

public class JSONTool {
	
	private boolean isTab = true;

	public String stringToJSON(String strJson) {
		// 计数tab的个数
		int tabNum = 0;
		StringBuffer jsonFormat = new StringBuffer();
		int length = strJson.length();

		for (int i = 0; i < length; i++) {
			char c = strJson.charAt(i);
			if (c == '{') {
				tabNum++;
				jsonFormat.append(c + "\n");
				jsonFormat.append(getSpaceOrTab(tabNum));
			} else if (c == '}') {
				tabNum--;
				jsonFormat.append("\n");
				jsonFormat.append(getSpaceOrTab(tabNum));
				jsonFormat.append(c);
			} else if (c == ',') {
				jsonFormat.append(c + "\n");
				jsonFormat.append(getSpaceOrTab(tabNum));
			} else {
				jsonFormat.append(c);
			}
		}
		return jsonFormat.toString();
	}

	// 是空格还是tab
	public String getSpaceOrTab(int tabNum) {
		StringBuffer sbTab = new StringBuffer();
		for (int i = 0; i < tabNum; i++) {
			if (isTab) {
				sbTab.append('\t');
			} else {
				sbTab.append("    ");
			}
		}
		return sbTab.toString();
	}

	/**
	 * 封装名片接口信息
	 * @param ci
	 * @return
	 * @throws Exception
	 */
	public static JSONObject getCardInterface(CardItem ci) throws Exception {
		JSONObject object = new JSONObject();
		
		if(ci != null) {
			object.put("extColumn8", ci.getExtColumn8());
			object.put("extColumn9", ci.getExtColumn9());
			object.put("extColumn10", ci.getExtColumn10());
			object.put("tel", ci.getTel());

			if (ci.getName() != null && !"".equals(ci.getName())) {
				object.put("name", ci.getName());
			}
			if (ci.getSex() != null && !"".equals(ci.getSex())) {
				object.put("sex", ci.getSex());
			}
			if (ci.getEmail() != null && !"".equals(ci.getEmail())) {
				object.put("email", ci.getEmail());
			}
			if (ci.getMobile() != null && !"".equals(ci.getMobile())) {
				object.put("mobile", ci.getMobile());
			}
			if (ci.getCompanyName() != null
					&& !"".equals(ci.getCompanyName())) {
				object.put("companyName", ci.getCompanyName());
			}
			if (ci.getArea() != null && !"".equals(ci.getArea())) {
				object.put("area", ci.getArea());
			}
			if (ci.getQq() != null && !"".equals(ci.getQq())) {
				object.put("qq", ci.getQq());
			}
			if (ci.getNote() != null && !"".equals(ci.getNote())) {
				object.put("note", ci.getNote());
			}

			if (ci.getExtColumn1() != null
					&& !"".equals(ci.getExtColumn1())) {
				object.put("extColumn1", ci.getExtColumn1());
			}
			if (ci.getExtColumn2() != null
					&& !"".equals(ci.getExtColumn2())) {
				object.put("extColumn2", ci.getExtColumn2());
			}
			if (ci.getExtColumn3() != null
					&& !"".equals(ci.getExtColumn3())) {
				object.put("extColumn3", ci.getExtColumn3());
			}
			if (ci.getExtColumn4() != null
					&& !"".equals(ci.getExtColumn4())) {
				object.put("extColumn4", ci.getExtColumn4());
			}
			if (ci.getExtColumn5() != null
					&& !"".equals(ci.getExtColumn5())) {
				object.put("extColumn5", ci.getExtColumn5());
			}
			if (ci.getExtColumn6() != null
					&& !"".equals(ci.getExtColumn6())) {
				object.put("extColumn6", ci.getExtColumn6());
			}
			if (ci.getExtColumn7() != null
					&& !"".equals(ci.getExtColumn7())) {
				object.put("extColumn7", ci.getExtColumn7());
			}
		}
		
		return object;
	}
	
	/**
	 * 封装名片接口信息--预览
	 * @param ci
	 * @return
	 * @throws Exception
	 */
	public static JSONObject getCardInterfaceForPreview(CardItem item) throws Exception {
		JSONObject object = new JSONObject();
		object.put(item.getExtColumn8(), "");
		object.put(item.getExtColumn9(), "");
		object.put(item.getExtColumn10(), "");
		object.put(item.getTel(), "");

		if (item.getName() != null && !"".equals(item.getName())) {
			object.put(item.getName(), "");
		}
		if (item.getSex() != null && !"".equals(item.getSex())) {
			object.put(item.getSex(), "");
		}
		if (item.getEmail() != null && !"".equals(item.getEmail())) {
			object.put(item.getEmail(), "");
		}
		if (item.getMobile() != null && !"".equals(item.getMobile())) {
			object.put(item.getMobile(), "");
		}
		if (item.getCompanyName() != null
				&& !"".equals(item.getCompanyName())) {
			object.put(item.getCompanyName(), "");
		}
		if (item.getArea() != null && !"".equals(item.getArea())) {
			object.put(item.getArea(), "");
		}
		if (item.getQq() != null && !"".equals(item.getQq())) {
			object.put(item.getQq(), "");
		}
		if (item.getNote() != null && !"".equals(item.getNote())) {
			object.put(item.getNote(), "");
		}

		if (item.getExtColumn1() != null
				&& !"".equals(item.getExtColumn1())) {
			object.put(item.getExtColumn1(), "");
		}
		if (item.getExtColumn2() != null
				&& !"".equals(item.getExtColumn2())) {
			object.put(item.getExtColumn2(), "");
		}
		if (item.getExtColumn3() != null
				&& !"".equals(item.getExtColumn3())) {
			object.put(item.getExtColumn3(), "");
		}
		if (item.getExtColumn4() != null
				&& !"".equals(item.getExtColumn4())) {
			object.put(item.getExtColumn4(), "");
		}
		if (item.getExtColumn5() != null
				&& !"".equals(item.getExtColumn5())) {
			object.put(item.getExtColumn5(), "");
		}
		if (item.getExtColumn6() != null
				&& !"".equals(item.getExtColumn6())) {
			object.put(item.getExtColumn6(), "");
		}
		if (item.getExtColumn7() != null
				&& !"".equals(item.getExtColumn7())) {
			object.put(item.getExtColumn7(), "");
		}
		
		return object;
	}
}
