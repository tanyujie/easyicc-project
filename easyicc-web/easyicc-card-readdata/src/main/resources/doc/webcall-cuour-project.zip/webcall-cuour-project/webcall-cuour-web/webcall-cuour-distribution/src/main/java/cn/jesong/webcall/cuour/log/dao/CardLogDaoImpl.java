package cn.jesong.webcall.cuour.log.dao;

import org.springframework.stereotype.Repository;

import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.CardApiPushLog;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class CardLogDaoImpl extends HibernateDAO<Integer, CardApiPushLog> implements CardLogDao{

	@Override
	public CardApiPushLog getLog(Integer id) {
		return super.get(id);
	}

	@Transactional
	@Override
	public void saveLog(CardApiPushLog log) {
		super.save(log);
	}

	@Override
    @Transactional
	public void saveOrUpdateLog(CardApiPushLog cardApiPushLog) {
		super.saveOrUpdate(cardApiPushLog);
	}

	@Override
	protected Class<CardApiPushLog> getEntityClass() {
		return CardApiPushLog.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return null;
	}

}
