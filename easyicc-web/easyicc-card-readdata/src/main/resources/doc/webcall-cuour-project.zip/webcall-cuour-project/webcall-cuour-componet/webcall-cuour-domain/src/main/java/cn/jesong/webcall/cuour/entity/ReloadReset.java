package cn.jesong.webcall.cuour.entity;

public class ReloadReset{
	
	private Boolean isReset;
	
	public Boolean getIsReset() {
		return isReset;
	}

	public void setIsReset(Boolean isReset) {
		this.isReset = isReset;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	private String time;
}