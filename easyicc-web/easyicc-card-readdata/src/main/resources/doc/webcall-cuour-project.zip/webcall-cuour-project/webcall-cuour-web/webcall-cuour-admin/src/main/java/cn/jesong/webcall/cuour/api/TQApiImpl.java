package cn.jesong.webcall.cuour.api;

import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.secret.SecretFactory;
import cn.jesong.webcall.cuour.service.CardPushLogService;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.HttpClientUtil;

/**
 * TQ接口
 * @author zhanglu
 *
 */
public class TQApiImpl implements ThirdApiInterface {

	private final static Log logger = LogFactory.getLog(TQApiImpl.class);

	@Autowired
	private CardPushLogService service;

	/**
	 * ActionConfig 配置信息
	 * VisitorCardData 名片数据模型
	 * template tpl模板
	 */
	@Override
	public String httpPost(ActionConfig ac, String template) throws Exception{

		logger.info("----------------------------->配置信息:" + JSON.toJSONString(ac) + "," + template);

		if (ac == null) {
			logger.info("----------------------------->推送失败，第三方接口配置信息为空!");
			return null;
		}

		if (StringUtils.isNotEmpty(template)) {

			JSONObject jsonTemplate = JSON.parseObject(template);
			Iterator<String> its = jsonTemplate.keySet().iterator();

			String str = "";
			while (its.hasNext()) {

				String key = its.next();
				Object value = jsonTemplate.get(key);
				
				if (StringUtils.isEmpty(value + ""))
					continue;
				
				if (String.valueOf(value).indexOf("$") != -1)
					continue;

				str += key + "=" + value + "&";
			}

			if (str.length() > 0) {
				template = str.substring(0, str.length() - 1);
			}
		}

		String url = ac.getInterfaceUrl();
		String res = null;

		if (StringUtils.isEmpty(url)) {
			logger.info("----------------------------->推送失败，第三方接口配置信息URL为空!");
			return res;
		}

		SecretFactory instance = SecretFactory.getInstance(ac.getThirdPlatform());
		if (instance == null) {
			logger.info("----------------------------->未找到秘钥工厂类型！");
		}
		String token = instance.getGenerator().generatorKeyStr(ac);
		if (StringUtils.isEmpty(token)) {
			logger.info("----------------------------->推送失败，第三方接口token获取失败!");
			return res;
		}

		String charset = CardUtil.getValue(ac.getConfig(), "charset");
		if (charset == null) {
			charset = "UTF-8";
		}

		String adminUin = CardUtil.getValue(ac.getConfig(), "adminUin");
		String uin = CardUtil.getValue(ac.getConfig(), "uin");
		//{"errorCode":0,"message":"请求成功"}
		url = url + "?access_token=" + token + "&admin_uin=" + adminUin;

		logger.info("----------------------------->提交数据：" + template + "," + url);
		res = HttpClientUtil.httpPost(url, template, charset, "application/x-www-form-urlencoded;charset=utf-8");
		return res;
	}
}
