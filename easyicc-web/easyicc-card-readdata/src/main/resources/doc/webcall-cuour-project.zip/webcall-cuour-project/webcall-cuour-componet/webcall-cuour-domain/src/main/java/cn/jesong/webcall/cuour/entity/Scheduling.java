package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 排班班次
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_scheduling")
public class Scheduling implements CompanySetting{
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_scheduling_id_seq")
	@SequenceGenerator(name = "js_scheduling_id_seq", sequenceName = "js_scheduling_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 业务组名称
	 */
	@Column(name = "name", nullable = false)
	private String name;
	
	/**
	 * 说明
	 */
	@Column(name = "desp", nullable = true)
	private String desp;
	
	/**
	 * 开始时间
	 */
	@Column(name = "start_time", nullable = false)
	private String startTime;
	
	/**
	 * 结束时间
	 */
	@Column(name = "end_time", nullable = false)
	private String endTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesp() {
		return desp;
	}

	public void setDesp(String desp) {
		this.desp = desp;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
