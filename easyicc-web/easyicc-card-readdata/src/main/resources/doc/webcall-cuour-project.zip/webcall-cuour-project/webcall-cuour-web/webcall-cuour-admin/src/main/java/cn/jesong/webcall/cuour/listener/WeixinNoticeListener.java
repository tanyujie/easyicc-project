package cn.jesong.webcall.cuour.listener;

import java.util.Properties;

import javax.annotation.Resource;

import net.kinfe.util.properties.ConfigLoader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.jesong.webcall.core.client.CoreClient;
import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.service.WeChatNotifyExtendService;
import cn.jesong.webcall.cuour.service.setting.WeChatNotifyExtendServiceImpl;
import cn.jesong.webcall.resource.CompanyGlobalConf;
import cn.jesong.webcall.resource.User;

@Component
public class WeixinNoticeListener implements AllocationListener {

	private final static Log logger = LogFactory
			.getLog(WeChatNotifyExtendServiceImpl.class);
	
	@Resource(name="weixinService")
	private WeChatNotifyExtendService weixinService;
	
	@Autowired
	private CacheFactory cacheFactory;
	
	@Override
	public void before(Card card) {
		
		try {
			CompanyGlobalConf config = CoreClient.getUserMgr(card.getCompanyId()).getCompanyGlobalConfig(card.getCompanyId());
			
//			User u = CoreClient.getUserMgr(card.getCompanyId()).getUser("admin");
//			u.setExtendConfigProperty("openWeChatNotify", "false");
//			u.setExtendConfigProperty("notifyOpenId",openId);
//			u.setExtendConfigProperty("notifyUserNickName",nickName);
//			CoreClient.getUserMgr(card.getCompanyId()).updateCustomer(u);
			
			
//			config.getProps2().setProperty("openWeChatNotify", "false");
//			config.getProps2().setProperty("notifyOpenId",openId);
//			config.getProps2().setProperty("notifyUserNickName",nickName);
//			CoreClient.getUserMgr(card.getCompanyId()).updateCompanyGlobalConfig(config);
			
			String notifyStatus = config.getProps2().getProperty("notifyIsOpen", "false");
			CardRule cardRule = cacheFactory.getCardRuleCache().getCardRule(card.getCompanyId());
			
			
//			logger.error("company wechat config status=" + notifyStatus + ",notifyOpenId=" + config.getProps2().getProperty("notifyOpenId"));
			logger.info("iswechatpush  before1="+cardRule.getIsWechatOpen());
			//if("true".equals(notifyStatus) && cardRule.getIsWechatOpen()==0)
			if(cardRule.getIsWechatOpen()==0)//不需要全局的微信的判断了
			{
				String notifyOpenId = config.getProps2().getProperty("notifyOpenId");
				logger.info("iswechatpush  before2="+cardRule.getIsWechatOpen());
				if(notifyOpenId!=null&&!"".equals(notifyOpenId))
				{
					String customerName = card.getName() == null ? "" : card.getName();
					String mobile = card.getMobile() == null ? "" : card.getMobile();
					String tel = card.getTel() == null ? "" : card.getTel();
					String cuourName = card.getRepName() == null ? "" : card.getRepName();
					String qq=card.getQq() == null ? "" : card.getQq();
					String msn=card.getMsn() == null ? "" : card.getMsn() ;
					// 过期时间--名片分配目前没有这个字段，所以暂时未空
					String overdueTime = "";
		
					// 跳转的url
					/*String url = "http://test.jswebcall.com/cuour/cardDocking/card";
					url += "?companyId=" + card.getCompanyId()
							+ "&cardId=" + card.getId();*/
					Properties prop = ConfigLoader.getInstance().load();
					String serverType = prop.getProperty("server.script.domain.type", "");
					String CropId = "wxf5f153db1f8a580e";
					String redirect_uri = "http://api.easyliao.com/"+serverType+ "/cn/jesong/webcall/cuour/cardDocking/cardAuth";
					redirect_uri += "?companyId=" + card.getCompanyId()
							+ "&cardId=" + card.getId();
					redirect_uri = java.net.URLEncoder.encode(redirect_uri, "utf-8");
					String url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="
							+ CropId
							+ "&redirect_uri="
							+ redirect_uri
							+ "&response_type=code&scope=snsapi_userinfo&state=yuqing#wechat_redirect";
					
					
					logger.info("cardUrl="+url);
					
					weixinService.sendNotifyMessage(notifyOpenId, customerName, mobile +" ; QQ: "+ qq + " ; 微信: "+ msn, cuourName, overdueTime, url);
				}
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(), e);
		}
		
	}

	@Override
	public void after(Card card, boolean allocation) {
		if(allocation) {
			///this.weixinService.action(card);
			
			if (card != null) {
				String userId = card.getUserId();
				
				
//				logger.info("wx notify to user:" + userId);
				CardRule cardRule = cacheFactory.getCardRuleCache().getCardRule(card.getCompanyId());
				logger.info("iswechatpush after1="+cardRule.getIsWechatOpen());
				if (userId != null && !"".equals(userId)) {
					
					SaleUser saleUser = cacheFactory.getSubjectUserCache().getUser(card.getCompanyId(), userId);
					
//					logger.info("wx notify to user:" + ((saleUser==null)?false:saleUser.isOpenWeixinPush()));
					
					if(saleUser==null||!saleUser.isOpenWeixinPush() || cardRule.getIsWechatOpen()==1)
						
						return;
					
//					logger.info("wx notify to user: status=" + saleUser.isOpenWeixinPush() + ",openId=" + saleUser.getUserWeiXinOpenId() );
					logger.info("iswechatpush after2="+cardRule.getIsWechatOpen());
					try
					{
						// 发送微信模板消息
						String customerName = card.getName() == null ? "" : card.getName();
						String mobile = card.getMobile() == null ? "" : card.getMobile();
						String tel = card.getTel() == null ? "" : card.getTel();
						String cuourName = card.getRepName() == null ? "" : card.getRepName();
						String qq=card.getQq() == null ? "" : card.getQq();
						String msn=card.getMsn() == null ? "" : card.getMsn() ;
						// 过期时间--名片分配目前没有这个字段，所以暂时未空
						String overdueTime = "";
						Properties prop = ConfigLoader.getInstance().load();
						String serverType = prop.getProperty("server.script.domain.type", "");
						// 跳转的url
						/*String url = "http://test.jswebcall.com/cuour/cardDocking/card";
						url += "?companyId=" + card.getCompanyId()
								+ "&cardId=" + card.getId();*/
						
						//后期统一升级再改用调用微信的接口，进行认证跳转跳转
						String corpid="wxf5f153db1f8a580e";
						String backurl = "http://api.easyliao.com/"+serverType+ "/cn/jesong/webcall/cuour/cardDocking/cardAuth";
						backurl += "?companyId=" + card.getCompanyId()
								+ "&cardId=" + card.getId();
						backurl = java.net.URLEncoder.encode(backurl, "utf-8");
						String url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="
								+ corpid
								+ "&redirect_uri="
								+ backurl
								+ "&response_type=code&scope=snsapi_userinfo&state=yuqing#wechat_redirect";
						
						logger.info("iswechatpush after="+cardRule.getIsWechatOpen());
						weixinService.sendNotifyMessage(saleUser.getUserWeiXinOpenId(),customerName,
										mobile + ", " + tel +" ; QQ: "+qq+ " ; 微信: "+ msn, cuourName,
										overdueTime, url); 
							

					} catch (Exception e) {
						// TODO Auto-generated catch block
						logger.error(e.getMessage(), e);
					}
					
				}
			}
			
		}
	}

}
