package cn.jesong.webcall.cuour.util;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;

import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;

public class HttpClientUtil {

	private final static Log _logger = LogFactory.getLog(HttpClientUtil.class);

	public static String httpPost(String apiInvokeUrl, String data, String charset) throws Exception {

		if (charset == null || charset.trim().length() == 0) {
			charset = "UTF-8";
		}

		URL url = new URL(apiInvokeUrl);
		// 2019-03-05注释掉以下代码，因为会丢失端口
		// URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(),
		// url.getQuery(), null);

		// 2019-03-05 换成新方法创建URI，支持端口
		URI uri = new URI(url.getProtocol(), null, url.getHost(), url.getPort(), url.getPath(), url.getQuery(), null);
		_logger.info("HttpClientUtil推送第三方:stateTime:" + DateUtil.getCurrentTime() + ",url:" + apiInvokeUrl);
		HttpClient client;

		if ("https".equals(url.getProtocol())) {
			client = new SslClient();

		} else {
			client = new DefaultHttpClient();

		}
		// System.out.println(uri);

		HttpPost post = new HttpPost(uri);
		post.addHeader("Content-Type", "application/json");
		StringEntity s = new StringEntity(data, charset);
		s.setContentEncoding("UTF-8");
		s.setContentType("text/json;charset=UTF-8");
		post.setEntity(s);
		
		client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,3000);//连接时间
		client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,10000);//数据传输时间
		
		HttpResponse rsp = client.execute(post);
		
		if (rsp.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
			HttpEntity entity = rsp.getEntity();
			String res = EntityUtils.toString(entity);

			_logger.info("HttpClientUtil结束向第三方推送crm信息----------》uri：" + uri + ",endTime:" + DateUtil.getCurrentTime());
			_logger.info("HttpClientUtil结束向第三方推送crm信息----------》res：" + res);
			return res;
		} else {
			_logger.info("---------------------》HttpClientUtil向第三方推送crm信息推送未成功！endTime:" + DateUtil.getCurrentTime());
			_logger.info("---------------------》HttpClientUtil返回code码：" + rsp.getStatusLine().getStatusCode());
		}

		return null;
	}

	/**
	 * 发送请求
	 * 
	 * @param url
	 * @param s
	 * @param accessToken
	 * @param contentType
	 * @return
	 * @throws IOException
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	public static String httpPost(String url, String s, String accessToken, String contentType) throws Exception {
		AsyncHttpClient http = new AsyncHttpClient();
		AsyncHttpClient.BoundRequestBuilder builder = http.preparePost(url);

		if (StringUtils.isNotEmpty(accessToken))
			builder.addHeader("Authorization", accessToken);

		builder.setBodyEncoding("UTF-8");

		if (StringUtils.isNotEmpty(s))
			builder.setBody(s);

		if (StringUtils.isNotEmpty(contentType))
			builder.setHeader("Content-Type", contentType);

		Future<Response> f;
		String body = "";
		f = builder.execute();
		body = f.get().getResponseBody("UTF-8");
		http.close();
		return body;
	}
}
