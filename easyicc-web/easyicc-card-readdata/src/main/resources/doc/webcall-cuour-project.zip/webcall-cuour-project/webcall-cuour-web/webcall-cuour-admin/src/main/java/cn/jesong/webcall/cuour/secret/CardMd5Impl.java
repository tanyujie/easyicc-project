package cn.jesong.webcall.cuour.secret;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.DateUtil;
import cn.jesong.webcall.cuour.util.KeyUtil;

public class CardMd5Impl implements CardAuxiliaryInterface {

	private final static Log _logger = LogFactory.getLog(CardMd5Impl.class);

	@Override
	public String generatorKeyStr(ActionConfig config) throws Exception {
		String keyStr = null;
		if (config != null && config.getConfig() != null && config.getConfig().trim().length() > 0) {

			String configStr = config.getConfig();
			/*Properties prop = new Properties();
			InputStream stringStream = StringToInputStream.getStringStream(configStr);
			prop.load(stringStream);*/
			String oid = CardUtil.getValue(configStr, "oid");
			String otherStr = CardUtil.getValue(configStr, "otherStr");
			if (StringUtils.isEmpty(oid) || StringUtils.isEmpty(otherStr)) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "]未配置ActionConfig信息:oid、otherStr！");
				return null;
			} else {
				oid = oid + otherStr + DateUtil.getCurDate();//prop.getProperty("oid");
			}
			/*String key = oid + "_crm_zdytable_257790_20396_"
					+ DateUtil.getCurDate();*/
			/*if (oid == null) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "]未配置ActionConfig信息！");
				return null;
			}*/
			//String key = oid + DateUtil.getCurDate();

			keyStr = KeyUtil.encryption(oid);

		}
		return keyStr;
	}

}
