package cn.jesong.webcall.cuour.service;

import java.net.URLEncoder;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.util.HttpTouTiaoUtil;
import cn.jesong.webcall.resource.ChatRecord;

@Service
public class TouTiaoSubmitService /*implements TrackSubmitService*/{

	private final static Log _logger = LogFactory.getLog(TouTiaoSubmitService.class);
	
	/**
	 * https://ad.toutiao.com/track/activate/?link=__LINK__&source=__SOURCE__&conv_time=__CONVTIME__&event_type=__EVENT_TYPE__
	 * event_type 表单提交：3  在线咨询： 4    有效咨询：5   有效获客：19
	 */
	public final static String URL = "https://ad.toutiao.com/track/activate/?";
	
	private ExecutorService executorService =  new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors() + 1, 40, 120, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(2000), new ThreadPoolExecutor.AbortPolicy());



	public void submit(Date endTime, Map<String, String> otherInfos) {
		String link = otherInfos.get("ocpc_toutiao_link");
		_logger.info("sumbit的link值为："+link);
		if(StringUtils.isNotBlank(link)){
			try{
				executorService.execute(new TouTiaoTask(link, 5, endTime.getTime()/1000));
			}catch(Exception e){
				_logger.error(e.getMessage(), e);
			}
		}
	}
	
	class TouTiaoTask implements Runnable{
		
		private String link;
		private int eventType;
		private long convTime;
		
		TouTiaoTask(String link, int eventType, long convTime){
			this.link = link;
			this.eventType = eventType;
			this.convTime = convTime;
		}
		
		@Override
		public void run() {
			try {
				String url = URL + "link="+URLEncoder.encode(this.link, "utf-8") +
						"&conv_time="+this.convTime+"&event_type="+this.eventType;
				_logger.info("sumbit的url值为："+url);
			//	HttpRequestUtil.get(url, null);
				HttpTouTiaoUtil.get(url);
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
			}
		}
	}
}
