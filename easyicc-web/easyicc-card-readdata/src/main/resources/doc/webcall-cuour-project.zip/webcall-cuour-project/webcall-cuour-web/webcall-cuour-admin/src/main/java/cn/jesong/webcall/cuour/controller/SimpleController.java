package cn.jesong.webcall.cuour.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.eutils.web.platform.ui.Page;
import cn.eutils.web.platform.ui.PageConfig;
import cn.eutils.web.platform.ui.RespResult;
import cn.jesong.webcall.cuour.dao.HibernateDAO;

@Controller
public abstract class SimpleController<ID extends java.io.Serializable, T> {

	protected abstract String getPrefix();
	
	protected abstract Object getQueryParams(HttpServletRequest request);
	
	protected abstract HibernateDAO<ID, T> getHibernateService();
	
	protected String getCreatePage(){
		return "form";
	}
	
	protected String getEditPage(){
		return "form";
	}
	
	protected void indexInit(ModelMap model){
	}
	
	protected void createPageInit(HttpServletRequest request, ModelMap model){
	}
	
	protected void updatePageInit(T entity, HttpServletRequest request, ModelMap model){
	}
	
	protected void beforeCreateOrUpdate(T entity){
	}
	
	@RequestMapping("/index")
	public String index(ModelMap model){
		this.indexInit(model);
		return this.getPrefix() + "/index";
	}
	
	@RequestMapping("/query/page")
	@ResponseBody
	public Page<T> pageQuery(HttpServletRequest request){
		Object params = this.getQueryParams(request);
		if(params == null){
			params = new HashMap<String, Object>();
		}
		return this.getHibernateService().pageQueryByTemplate(PageConfig.createPageConfig(request), params);
	}
	
	@RequestMapping("/query/list")
	@ResponseBody
	public List<T> listQuery(HttpServletRequest request){
		Object params = this.getQueryParams(request);
		if(params == null){
			params = new HashMap<String, Object>();
		}
		return this.getHibernateService().getListByTemplate(params);
	}
	
	/**
	 * 创建页面
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public String create(HttpServletRequest request, ModelMap model){
		this.createPageInit(request, model);
		return this.getPrefix() + "/" + getCreatePage();
	}
	
	/**
	 * 创建
	 * @param entity
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public void create(T entity, HttpServletRequest request, HttpServletResponse response) throws IOException{
		try{
			this.beforeCreateOrUpdate(entity);
			this.getHibernateService().saveOrUpdate(entity);
			RespResult.getSuccess().writeToResponse(response);
		}catch(Exception e){
			RespResult.getError(e).writeToResponse(response);
		}
	}
	
	/**
	 * 更新页面
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String update(@RequestParam("id") ID id, HttpServletRequest request, ModelMap model){
		T entity = this.getHibernateService().get(id);
		model.put("entity", entity);
		this.updatePageInit(entity, request, model);
		return this.getPrefix() + "/" + this.getEditPage();
	}
	
	
	/**
	 * 更新
	 * @param entity
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void update(T entity, HttpServletResponse response) throws IOException{
		try{
			this.beforeCreateOrUpdate(entity);
			this.getHibernateService().saveOrUpdate(entity);
			RespResult.getSuccess().writeToResponse(response);
		}catch(Exception e){
			RespResult.getError(e).writeToResponse(response);
		}
	}
	
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	@RequestMapping("/delete")
	@ResponseBody
	public RespResult delete(@RequestParam("id") ID id){
		try{
			this.getHibernateService().delete(id);
			return RespResult.getSuccess();
		}catch(Exception e){
			return RespResult.getError(e);
		}
	}
	
	
	
	
}
