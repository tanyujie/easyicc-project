package cn.jesong.webcall.cuour.entity;

import org.json.simple.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TestData {
	
	private String crmzdy_88232948;
	private String crm_holder;
	private String crmzdy_80974415;
	private String crm_name;
	private String crmzdy_80974418;
	private String crmzdy_88070094;
	
	private String crmzdy_88232342;
	
	private String crmzdy_88232295;
	
	private String crmzdy_80979018;
	
	private String crmzdy_81253707;
	
	private String crmzdy_88167326;
	
	private String crmzdy_80974439;
	
	private String crmzdy_80979020;
	
	private String crmzdy_88232284;
	
	private String crmzdy_88232306;
	private String crmzdy_88232317;
	
	private Map<String, Object> map;
	
	public TestData(){
		map = new HashMap<String, Object>();
	}
	
	public String replaceTemplateAllValues(String template,String bodyType)
	{
		
		template = replaceTemplateValue(template,"visitorStaticId",bodyType,getCrmzdy_88232948());
		template = replaceTemplateValue(template,"userRealName",bodyType,getCrm_holder());
		template = replaceTemplateValue(template,"mobile",bodyType,getCrmzdy_80974415());
		template = replaceTemplateValue(template,"name",bodyType,getCrm_name());
		template = replaceTemplateValue(template,"qq",bodyType,getCrmzdy_80974418());
		template = replaceTemplateValue(template,"weixin",bodyType,getCrmzdy_88070094());
		template = replaceTemplateValue(template,"createTime",bodyType,getCrmzdy_88232342());
		template = replaceTemplateValue(template,"allocationTime",bodyType,getCrmzdy_88232295());
		template = replaceTemplateValue(template, "crmState",bodyType,getCrmzdy_80979018());
		template = replaceTemplateValue(template, "subjectName",bodyType, getCrmzdy_81253707());
		template = replaceTemplateValue(template, "schoolName",bodyType, getCrmzdy_88167326());
		template = replaceTemplateValue(template, "extColumn10",bodyType, getCrmzdy_80974439());
		template = replaceTemplateValue(template, "note",bodyType, getCrmzdy_80979020());
		template = replaceTemplateValue(template, "createUserId",bodyType, getCrmzdy_88232284());
		template = replaceTemplateValue(template, "extColumn1",bodyType, getCrmzdy_88232306());
		template = replaceTemplateValue(template, "currentChatDetail",bodyType, getCrmzdy_88232317());
		return template;
	}
	public String replaceTemplateValue(String template,String attr,String bodyType,String value)
	{
		System.out.println(template.replace("$"+attr, value==null?"":JSONObject.escape(value)));
		return template.replace("$"+attr, value==null?"":JSONObject.escape(value));
	}
	
	public TestData(Map<String, Object> map){
		setCrmzdy_88232948(map.get("crmzdy_88232948").toString());
		setCrm_holder(map.get("crm_holder").toString());
		setCrmzdy_80974415(map.get("crmzdy_80974415").toString());
		setCrm_name(map.get("crm_name").toString());
		setCrmzdy_80974418(map.get("crmzdy_80974418").toString());
		setCrmzdy_88070094(map.get("crmzdy_88070094").toString());
		setCrmzdy_88232342(map.get("crmzdy_88232342").toString());
		setCrmzdy_88232295(map.get("crmzdy_88232295").toString());
		setCrmzdy_80979018(map.get("crmzdy_80979018").toString());
		setCrmzdy_81253707(map.get("crmzdy_81253707").toString());
		setCrmzdy_88167326(map.get("crmzdy_88167326").toString());
		setCrmzdy_80974439(map.get("crmzdy_80974439").toString());
		setCrmzdy_80979020(map.get("crmzdy_80979020").toString());
		setCrmzdy_88232284(map.get("crmzdy_88232284").toString());
		setCrmzdy_88232306(map.get("crmzdy_88232306").toString());
		setCrmzdy_88232317(map.get("crmzdy_88232317").toString());
		
	}
	
	public String getCrmzdy_88232948() {
		return crmzdy_88232948;
	}
	public void setCrmzdy_88232948(String crmzdy_88232948) {
		this.crmzdy_88232948 = crmzdy_88232948;
	}
	public String getCrm_holder() {
		return crm_holder;
	}
	public void setCrm_holder(String crm_holder) {
		this.crm_holder = crm_holder;
	}
	public String getCrmzdy_80974415() {
		return crmzdy_80974415;
	}
	public void setCrmzdy_80974415(String crmzdy_80974415) {
		this.crmzdy_80974415 = crmzdy_80974415;
	}
	public String getCrm_name() {
		return crm_name;
	}
	public void setCrm_name(String crm_name) {
		this.crm_name = crm_name;
	}
	public String getCrmzdy_80974418() {
		return crmzdy_80974418;
	}
	public void setCrmzdy_80974418(String crmzdy_80974418) {
		this.crmzdy_80974418 = crmzdy_80974418;
	}
	public String getCrmzdy_88070094() {
		return crmzdy_88070094;
	}
	public void setCrmzdy_88070094(String crmzdy_88070094) {
		this.crmzdy_88070094 = crmzdy_88070094;
	}
	public String getCrmzdy_88232342() {
		return crmzdy_88232342;
	}
	public void setCrmzdy_88232342(String crmzdy_88232342) {
		this.crmzdy_88232342 = crmzdy_88232342;
	}
	public String getCrmzdy_88232295() {
		return crmzdy_88232295;
	}
	public void setCrmzdy_88232295(String crmzdy_88232295) {
		this.crmzdy_88232295 = crmzdy_88232295;
	}
	public String getCrmzdy_80979018() {
		return crmzdy_80979018;
	}
	public void setCrmzdy_80979018(String crmzdy_80979018) {
		this.crmzdy_80979018 = crmzdy_80979018;
	}
	public String getCrmzdy_81253707() {
		return crmzdy_81253707;
	}
	public void setCrmzdy_81253707(String crmzdy_81253707) {
		this.crmzdy_81253707 = crmzdy_81253707;
	}
	public String getCrmzdy_88167326() {
		return crmzdy_88167326;
	}
	public void setCrmzdy_88167326(String crmzdy_88167326) {
		this.crmzdy_88167326 = crmzdy_88167326;
	}
	public String getCrmzdy_80974439() {
		return crmzdy_80974439;
	}
	public void setCrmzdy_80974439(String crmzdy_80974439) {
		this.crmzdy_80974439 = crmzdy_80974439;
	}
	public String getCrmzdy_80979020() {
		return crmzdy_80979020;
	}
	public void setCrmzdy_80979020(String crmzdy_80979020) {
		this.crmzdy_80979020 = crmzdy_80979020;
	}
	public String getCrmzdy_88232284() {
		return crmzdy_88232284;
	}
	public void setCrmzdy_88232284(String crmzdy_88232284) {
		this.crmzdy_88232284 = crmzdy_88232284;
	}
	public String getCrmzdy_88232306() {
		return crmzdy_88232306;
	}
	public void setCrmzdy_88232306(String crmzdy_88232306) {
		this.crmzdy_88232306 = crmzdy_88232306;
	}
	public String getCrmzdy_88232317() {
		return crmzdy_88232317;
	}
	public void setCrmzdy_88232317(String crmzdy_88232317) {
		this.crmzdy_88232317 = crmzdy_88232317;
	}
	
	
	
	
}
