package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.BusinessGroup;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class BusinessGroupService extends SettingService<Integer, BusinessGroup>{
	
	@Override
	protected Class<BusinessGroup> getEntityClass() {
		return BusinessGroup.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from BusinessGroup where / companyId = {companyId} / order by id desc";
	}

}
