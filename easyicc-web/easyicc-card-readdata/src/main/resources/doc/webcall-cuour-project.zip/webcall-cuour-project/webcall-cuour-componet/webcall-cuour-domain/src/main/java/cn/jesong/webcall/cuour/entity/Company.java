package cn.jesong.webcall.cuour.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 公司
 * @author hanjianxin
 *
 */
@Entity
@Table(name = "js_company")
public class Company {
	
	/**
	 * 公司id
	 */
	@Id
	@Column(name = "company_id", nullable = true)
	private int companyId;
	
	/**
	 * 公司名称
	 */
	@Column(name = "company_name", nullable = true)
	private String companyName; 
	
	/**
	 * 站点
	 */
	@Column(name = "web_site", nullable = true)
	private String webSite;
	
	/**
	 * 城市
	 */
	@Column(name = "city", nullable = true)
	private String city;
	
	/**
	 * 国家
	 */
	@Column(name = "country", nullable = true)
	private String country;
	
	/**
	 * 街道
	 */
	@Column(name = "street", nullable = true)
	private String street;
	
	/**
	 * 邮政编码
	 */
	@Column(name = "zip_code", nullable = true)
	private String zipCode;
	
	/**
	 * 省份
	 */
	@Column(name = "province", nullable = true)
	private String province; // PROVINCE
	
	/**
	 * 电话号码
	 */
	@Column(name = "phone_number", nullable = true)
	private String phoneNumber; //PHONE_NUMBER
	
	/**
	 * 传真
	 */
	@Column(name = "fax", nullable = true)
	private String fax; // FAX
	
	/**
	 * 供应商
	 */
	@Column(name = "supplier", nullable = true)
	private String supplier; // SUPPLIER
	
	/**
	 * 领域
	 */
	@Column(name = "domain", nullable = true)
	private String domain; // DOMAIN
	
	/**
	 * 代理
	 */
	@Column(name = "agent", nullable = true)
	private String agent; // AGENT
	
	/**
	 * 行业
	 */
	@Column(name = "industry", nullable = true)
	private String industry; // INDUSTRY

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getWebSite() {
		return webSite;
	}

	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}
}
