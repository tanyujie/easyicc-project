package cn.jesong.webcall.cuour.secret;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.HttpClientUtil;

/**
 * 获取ec token实现
 * @author zhanglu
 *
 */
public class CardECImpl implements CardAuxiliaryInterface {

	private final static Log _logger = LogFactory.getLog(CardECImpl.class);

	@Override
	public String generatorKeyStr(ActionConfig config) throws Exception{
		String keyStr = null;
		if (config != null && config.getConfig() != null && config.getConfig().trim().length() > 0) {

			String configStr = config.getConfig();

			// 企业id corpId = "10097014";
			// Appid appId = "459758381591166976";
			// App密钥 appSecret = "e9ynm6N1ZSBGnhVafTB";
			String corpId = CardUtil.getValue(configStr, "corpId");
			String appId = CardUtil.getValue(configStr, "appId");
			String appSecret = CardUtil.getValue(configStr, "appSecret");
			String getTokenUrl = CardUtil.getValue(configStr, "getTokenUrl");

			if (StringUtils.isEmpty(corpId) || StringUtils.isEmpty(appId) || StringUtils.isEmpty(appSecret)) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "]未配置ActionConfig信息!");
				return null;
			}

			JSONObject s = new JSONObject();
			s.put("appId", appId);
			s.put("appSecret", appSecret);

			String info = HttpClientUtil.httpPost(getTokenUrl, JSON.toJSONString(s), "UTF-8");
			if (StringUtils.isEmpty(info)) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "请求密钥失败!");
				return null;
			}

			JSONObject ec = JSON.parseObject(info);
			if (ec.containsKey("errCode") && ec.getInteger("errCode") == 200) {
				keyStr = ec.getJSONObject("data").getString("accessToken");
			}

			_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "请求密钥结果："+info);
		}
		return keyStr;
	}

}
