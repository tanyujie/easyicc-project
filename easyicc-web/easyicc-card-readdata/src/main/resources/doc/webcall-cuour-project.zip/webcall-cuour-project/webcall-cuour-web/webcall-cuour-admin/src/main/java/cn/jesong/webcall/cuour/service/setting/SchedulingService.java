package cn.jesong.webcall.cuour.service.setting;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Scheduling;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SchedulingService extends SettingService<Integer, Scheduling>{
	
	@Override
	protected Class<Scheduling> getEntityClass() {
		return Scheduling.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from Scheduling where / companyId = {companyId} / order by id desc";
	}

}