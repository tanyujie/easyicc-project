package cn.jesong.webcall.cuour.common;

/**
 * 公司工具类
 * @author hanjianxin
 *
 */
public class CompanyUtil {
	
	private static String SAIYOU_URL = "http://cn828.800app.com/uploadfile/staticresource/257790/269129/sy_AddLeads.aspx";
	private static int SAIYOU_ID = 1;

	/**
	 * 根据公司id获取接口的url
	 * @param companyId
	 * @return
	 */
	public static String getInterfaceUrlByCompanyId(int companyId) {
		String url = "";
		if(companyId == SAIYOU_ID) {
			url = SAIYOU_URL; 
		}
		
		return url;
	}
	
}
