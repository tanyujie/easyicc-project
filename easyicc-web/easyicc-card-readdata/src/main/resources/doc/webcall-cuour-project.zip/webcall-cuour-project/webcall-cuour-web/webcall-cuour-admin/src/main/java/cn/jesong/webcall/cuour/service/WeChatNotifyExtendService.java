package cn.jesong.webcall.cuour.service;

import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Card;

/**
 *
 */
@Service
public interface WeChatNotifyExtendService {
	
	public void action(Card card);
	public void sendNotifyMessage(String openId, String customerName, String mobile, String cuourName,
                                  String overdueTime, String url);
}
