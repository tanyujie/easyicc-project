package cn.jesong.webcall.cuour.entity;

import java.util.Set;

public class VisitorColSelfSon extends VisitorColSelf{
    private Set<VisitorColSelfItem> items;
    private VisitorCol visitorCol;
	public Set<VisitorColSelfItem> getItems() {
		return items;
	}
	public void setItems(Set<VisitorColSelfItem> items) {
		this.items = items;
	}
	public VisitorCol getVisitorCol() {
		return visitorCol;
	}
	public void setVisitorCol(VisitorCol visitorCol) {
		this.visitorCol = visitorCol;
	}
    
    

}
