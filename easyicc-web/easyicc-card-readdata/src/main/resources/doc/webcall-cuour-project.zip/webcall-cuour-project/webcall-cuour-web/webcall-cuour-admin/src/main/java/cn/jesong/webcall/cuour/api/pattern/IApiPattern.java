package cn.jesong.webcall.cuour.api.pattern;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public interface IApiPattern {
	
	public boolean isMatching(ActionConfig config, String result);
	
}
