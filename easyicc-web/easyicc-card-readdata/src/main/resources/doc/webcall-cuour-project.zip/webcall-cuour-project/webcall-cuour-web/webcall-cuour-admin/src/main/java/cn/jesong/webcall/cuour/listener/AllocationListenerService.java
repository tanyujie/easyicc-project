package cn.jesong.webcall.cuour.listener;


import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Card;


@Service
public class AllocationListenerService implements ApplicationContextAware{

	private ApplicationContext context;
	
	private ExecutorService executor = Executors.newFixedThreadPool(10);

	@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		this.context = context;
	}
	
	public void before(final Card card){
		executor.execute(new Runnable(){
			@Override
			public void run() {
				Map<String, AllocationListener> beans = context.getBeansOfType(AllocationListener.class);
				for(AllocationListener listener : beans.values()){
					listener.before(card);
				}
			}
			
		});
		
	}
	
	public void after(final Card card, final boolean allocation){
		executor.execute(new Runnable(){
			@Override
			public void run() {
				Map<String, AllocationListener> beans = context.getBeansOfType(AllocationListener.class);
				for(AllocationListener listener : beans.values()){
					listener.after(card, allocation);
				}
			}
		});
	}
}
