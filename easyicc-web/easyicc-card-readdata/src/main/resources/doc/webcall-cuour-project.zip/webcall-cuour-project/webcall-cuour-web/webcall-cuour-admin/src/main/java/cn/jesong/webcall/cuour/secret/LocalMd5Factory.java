package cn.jesong.webcall.cuour.secret;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LocalMd5Factory extends SecretFactory {
	
	private final static Log _logger = LogFactory.getLog(LocalMd5Factory.class);
	
	private static CardAuxiliaryInterface auxiliary;
	
	
	public LocalMd5Factory(){
		auxiliary = new CardMd5Impl();
	}
	
	@Override
	public CardAuxiliaryInterface getGenerator() {
		return this.auxiliary;
	}

}
