package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 校区
 * @author xieyulin
 *
 */
@Entity
@Table(name = "js_cuour_back_type")
public class BackType implements CompanySetting{

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_cuour_back_type_id_seq")
	@SequenceGenerator(name = "js_cuour_back_type_id_seq", sequenceName = "js_cuour_back_type_id_seq", allocationSize = 1)
	private Integer id;
	
	/**
	 * 所属公司ID
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 校区名称
	 */
	@Column(name = "name", nullable = false)
	private String name;
	
	/**
	 * 说明
	 */
	@Column(name = "desp", nullable = true)
	private String desp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesp() {
		return desp;
	}

	public void setDesp(String desp) {
		this.desp = desp;
	}
	
	
	
	
}
