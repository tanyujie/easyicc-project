package cn.jesong.webcall.cuour.api;

import cn.jesong.webcall.cuour.entity.ActionConfig;

public abstract class ThirdApiFactory {

	private static ThirdApiInterface saiYouImpl = new SaiYouApiImpl();

	private static ThirdApiInterface ecImpl = new ECApiImpl();

	private static ThirdApiInterface tqImpl = new TQApiImpl();

	private static ThirdApiInterface defaultImpl = new DefaultApiImpl();
	
	private static ThirdApiInterface xdfImpl = new XDFApiImpl();

	public static ThirdApiInterface getInstance(ActionConfig config) {

		if (config == null)
			return defaultImpl;

		String platform = config.getThirdPlatform();

		if ("tq".equals(platform))
			return tqImpl;

		if ("saiyoucrm".equals(platform))
			return saiYouImpl;

		if ("ec".equals(platform))
			return ecImpl;
		
		if ("xdf".equals(platform))
			return xdfImpl;

		return defaultImpl;
	}

}
