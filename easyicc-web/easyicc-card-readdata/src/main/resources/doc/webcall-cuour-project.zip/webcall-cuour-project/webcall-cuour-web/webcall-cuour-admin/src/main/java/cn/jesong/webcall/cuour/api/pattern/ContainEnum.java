package cn.jesong.webcall.cuour.api.pattern;

public enum ContainEnum {
	INDEXOF,REGULAR
}
