package cn.jesong.webcall.cuour.service.setting;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//import org.json.JSONException;
//import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.core.client.CoreClient;
import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.VisitorCardData;
import cn.jesong.webcall.cuour.service.ActionConfigService;
import cn.jesong.webcall.cuour.service.CardExtendService;
import cn.jesong.webcall.cuour.service.ChatRecordService;
import cn.jesong.webcall.cuour.service.ThirdApiInvokeService;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.CommonUtil;
import cn.jesong.webcall.resource.ChatRecordDetail;

/**
 * 名片扩展接口实现类
 * 
 * @author hanjianxin
 * 
 */
@Service(value = "sendDataService")
public class CardExtendServiceImpl implements CardExtendService {

	private final static Log logger = LogFactory.getLog(CardExtendServiceImpl.class);

	@Autowired
	private CacheFactory cacheFactory;

	@Autowired
	private ActionConfigService acService;

	@Autowired
	private ThirdApiInvokeService thirdApiInvokeService;

	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	private ChatRecordService chatRecordService;

	public ActionConfig getActionConfig(int companyId) throws Exception {
		return acService.getActionConfig(companyId);
	}

	/**
	 * 公共方法（分配工号）
	 */
	public void action(ActionConfig ac, Card card) {
		try {
			// 配置
			// String config = ac.getConfig();
			// json字典
			String template = ac.getTpl();
			// 获取名片信息
			// JSONObject jsonConfig = new JSONObject(config);

			Map map = acService.loadCardFullData(card.getId());

			if (map == null)
				return;

			VisitorCardData vcard = new VisitorCardData(map);
			// ac.getBodyType();
			// logger.info("push-api-config-Template="+template);
			template = vcard.replaceTemplateAllValues(template, ac.getBodyType());
			logger.info("######分配工号：template替换：" + template + ",card：" + JSON.toJSONString(card) + ",VisitorCardData："
					+ JSON.toJSONString(vcard) + "map：" + map.toString());

			if (card.getUserId() != null && !"".equals(card.getUserId())) {
				SaleUser u = cacheFactory.getSubjectUserCache().getUser(card.getCompanyId(), card.getUserId());
				logger.info("######分配工号：SaleUser：" + u);
				if (u != null) {
					// map.put("userRealName", u.getRealName());
					// map.put("areaName", u.getSchoolName());
					// map.put("subjectName", u.getSubjectName());

					template = vcard.replaceTemplateValue(template, "userRealName", ac.getBodyType(), u.getRealName());

					// 取工号
					String code = CommonUtil.getEmployeeNumber(u.getRealName());
					if (StringUtils.isEmpty(code))
						code = CardUtil.getValue(ac.getConfig(), "userCode");

					logger.info("-----取工号--------------u.getRealName:" + u.getRealName() + ",code" + code);
					template = vcard.replaceTemplateValue(template, "userCode", ac.getBodyType(), code);
					template = vcard.replaceTemplateValue(template, "schoolName", ac.getBodyType(), u.getSchoolName());
					template = vcard.replaceTemplateValue(template, "subjectName", ac.getBodyType(),
							u.getSubjectName());
					
				}
				
				SaleUser createUser = cacheFactory.getSubjectUserCache().getUser(card.getCompanyId(),
						card.getCreateUserId());
				if (createUser != null) {
					template = vcard.replaceTemplateValue(template, "createUserRealName", ac.getBodyType(),
							createUser.getRealName());
				}
			} 
			/*else {
				String code = CardUtil.getValue(ac.getConfig(), "userCode");
				logger.info("-----取工号--------------code:" + code);
				if (StringUtils.isNotEmpty(code))
					template = vcard.replaceTemplateValue(template, "userCode", ac.getBodyType(), code);
			}*/

			List<ChatRecordDetail> recordDetail = null;

			if (vcard.getChatId() != null && !"".equals(vcard.getChatId())) {
				try {
					recordDetail = CoreClient.getChatMgr(card.getCompanyId()).getCurrentChatRecord(card.getCompanyId(),
							Integer.parseInt(vcard.getChatId()));

					if (recordDetail == null || recordDetail.size() == 0) {
						recordDetail = chatRecordService.getChatRecordDetail(card.getCompanyId(),
								Integer.parseInt(vcard.getChatId()), card.getCreateTime());
					}

				} catch (Exception e) {

					logger.error(e.getMessage(), e);
				}
			} else {
				recordDetail = chatRecordService.getChatRecordDetail(card.getCompanyId(), vcard.getVisitorStaticId(),
						format.format(card.getCreateTime()));
			}

			if (recordDetail != null) {
				StringBuffer detail = new StringBuffer();
				// 起路教育对话记录（缩短访客名称、截取1000字节内容）
				StringBuffer detailEC = new StringBuffer();
				JSONArray jsonStr = new JSONArray();
				for (int i = 0; i < recordDetail.size(); i++) {
					JSONObject json = new JSONObject();
					ChatRecordDetail d = recordDetail.get(i);

					json.put("chat_id", d.getChatId());
					json.put("create_time", format.format(d.getCreateTime()));
					json.put("from_id", d.getFromId());
					json.put("message", d.getMessage());
					json.put("recorder_id", d.getRecorderId());
					json.put("type", d.getType());
					jsonStr.add(json);

					detail.append(d.getFromId());
					detail.append(" ");
					detail.append(format.format(d.getCreateTime()));
					detail.append("\r\n");
					detail.append(d.getMessage());
					detail.append("\r\n");
					detail.append("\r\n");

					// "senderType":1,//1 是访客，0是客服
					String fromId = d.getFromId();
					if (d.getSenderType() == 1 && fromId != null && !"".equals(fromId) && fromId.length() > 5)
						fromId = fromId.substring(fromId.length() - 5, fromId.length());
					detailEC.append(fromId);
					detailEC.append(" ");
					detailEC.append(format.format(d.getCreateTime()));
					detailEC.append(" ");
					detailEC.append(d.getMessage());
					detailEC.append(" ");
				}
				// logger.info("------currentChatJsonDetail:" + JSON.toJSONString(jsonStr));
				// logger.info("------currentChatDetail:" + detail.toString());
				String detailECStr = detailEC.toString();
				detailECStr = idgui(detailECStr, 1000);
				logger.info("------名片分配对话记录信息 template:" + template + "," + detailECStr);

				template = vcard.replaceTemplateValue(template, "chatDetailEC", ac.getBodyType(), detailECStr);
				template = vcard.replaceTemplateJSonValue(template, "currentChatJsonDetail",
						JSON.toJSONString(jsonStr));
				template = vcard.replaceTemplateValue(template, "currentChatDetail", ac.getBodyType(),
						detail.toString());

			} else {
				template = vcard.replaceTemplateJSonValue(template, "currentChatJsonDetail", "");
				template = vcard.replaceTemplateValue(template, "currentChatDetail", ac.getBodyType(), "");
				template = vcard.replaceTemplateValue(template, "chatDetailEC", ac.getBodyType(), "");
			}

			// JSONObject jsonData = jsonConfig.getJSONObject("data");
			// Iterator<Map.Entry<String, Object>> it = map.entrySet()
			// .iterator();
			// while (it.hasNext()) {
			// Map.Entry<String, Object> entry = it.next();
			// String key = entry.getKey();
			// Object value = entry.getValue();
			//
			// if (jsonData.has(key) == true) {
			// String t = jsonData.getString(key) == null ? ""
			// : jsonData.getString(key);
			// if (value != null) {
			// tpl = tpl.replace(t, value.toString());
			// } else {
			// tpl = tpl.replace(t, "");
			// }
			//
			// }
			//
			// }
			// logger.info("push-api-config="+config);
			// logger.info("push-api-data="+(new JSONObject(map)));

			String apiRsp = thirdApiInvokeService.invoke(ac, vcard, template);

			logger.info("push-data{mobile=" + vcard.getMobile() + ",weixin=" + vcard.getWeixin() + "},dataBody="
					+ template + "\r\nresp=" + apiRsp);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

	}

	/**
	 * 截取汉字
	 * 
	 * @param s
	 * @param num
	 * @return
	 */
	public static String idgui(String s, int num) {
		int changdu = s.getBytes().length;
		if (changdu > num) {
			s = s.substring(0, s.length() - 1);
			s = idgui(s, num);
		}
		return s;
	}

}
