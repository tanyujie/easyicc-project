package cn.jesong.webcall.cuour.cache;

public interface CacheFactory {
	
	public void checkInit(int companyId, CacheDataLoader loader, String time);
	
	public void remove(int companyId);
	
	public LockCache getLockCache();
	
	public CardRuleCache getCardRuleCache();

	public SubjectUserCache getSubjectUserCache();
	
	public ScheduingCache getScheduingCache();
	
	public ActionConfigCache getActionConfigCache();
	
	void checkInit(int companyId, CacheDataLoader loader, String time,
                   boolean isUserReset);
	
}
