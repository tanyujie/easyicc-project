package cn.jesong.webcall.cuour.api;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.util.HttpClientUtil;

public class DefaultApiImpl implements ThirdApiInterface{
	
	private static ThirdApiInterface a= new DefaultApiImpl();

	@Override
	public String httpPost(ActionConfig ac, String data) throws Exception{
		String url = ac.getInterfaceUrl();
		
		if (url != null && !"".equals(url)) {
			String res  = HttpClientUtil.httpPost(url, data, null);

			return res;
		}
		
		return null;
	}
	
	public static void main(String[] args) {
		String url = "http://123.56.181.149/easyliao_ak_it.php";
		String data = "{\"mobile\":\"18211112222\",\"username\":\"it-wangwei19\"}";
		
		if (url != null && !"".equals(url)) {
			String res = "";
			try {
				res = HttpClientUtil.httpPost(url, data, null);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println(res);
		}
		
	}

}
