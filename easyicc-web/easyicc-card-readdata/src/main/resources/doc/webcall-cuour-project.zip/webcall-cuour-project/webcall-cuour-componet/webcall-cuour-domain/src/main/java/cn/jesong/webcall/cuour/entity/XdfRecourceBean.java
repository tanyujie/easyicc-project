package cn.jesong.webcall.cuour.entity;

/**
 * 新东方推送数据
 * @author zl
 *
 */
public class XdfRecourceBean {
	
	//nschoolId	是	string	学校(有且仅能传报名系统学校ID)
	private String nschoolId;
	//studentName	是	string	学生姓名
	private String studentName;
	//mobilePhone	是	String	手机号
	private String mobilePhone;
	//sex	否	String	性别(男M，女F)严格大小写
	private String sex;
	//grade	否	String	年级
	private String grade;
	//course	否	String	课程
	private String course;
	//age	否	String	年龄
	private String age;
	//schoolAreaCode	否	String	校区编码(报名系统校区编码)
	private String schoolAreaCode;
	//channelSource	否	String	渠道来源
	private String channelSource;
	//activityName	是	String	收集项名称(市场活动)
	private String activityName;
	//inputEmail	是	String	线索所属人(XDF邮箱)
	private String inputEmail;
	//deptName	是	String	分配部门(有且仅有：国外/国内/北美/英联邦)
	private String deptName;
	//createEmail	是	String	创建人邮箱(XDF邮箱)
	private String createEmail;
	//otherRemark	否	String	其它（组件）
	private String otherRemark;
	
	public String getNschoolId() {
		return nschoolId;
	}
	public void setNschoolId(String nschoolId) {
		this.nschoolId = nschoolId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getSchoolAreaCode() {
		return schoolAreaCode;
	}
	public void setSchoolAreaCode(String schoolAreaCode) {
		this.schoolAreaCode = schoolAreaCode;
	}
	public String getChannelSource() {
		return channelSource;
	}
	public void setChannelSource(String channelSource) {
		this.channelSource = channelSource;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getInputEmail() {
		return inputEmail;
	}
	public void setInputEmail(String inputEmail) {
		this.inputEmail = inputEmail;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getCreateEmail() {
		return createEmail;
	}
	public void setCreateEmail(String createEmail) {
		this.createEmail = createEmail;
	}
	public String getOtherRemark() {
		return otherRemark;
	}
	public void setOtherRemark(String otherRemark) {
		this.otherRemark = otherRemark;
	}
	
	
	
	
}
