/**
 * 微信公众平台开发模式(JAVA) SDK
 * (c) 2012-2013 ____′↘夏悸 <wmails@126.cn>, MIT Licensed
 * http://www.jeasyuicn.com/wechat
 */
package cn.jesong.webcall.cuour.weixin.util;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;

/**
 * https 请求 微信为https的请求
 *
 * @author L.cm
 * @date 2013-10-9 下午2:40:19
 */ 
public class HttpKit {
	private static final String DEFAULT_CHARSET = "UTF-8";
    /**
     * @return 返回类型:
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @description 功能描述: get 请求
     */
    public static String get(String url, Map<String, String> params, Map<String, String> headers) throws IOException, ExecutionException, InterruptedException {
        AsyncHttpClient http = new AsyncHttpClient();
        AsyncHttpClient.BoundRequestBuilder builder = http.prepareGet(url);
        builder.setBodyEncoding(DEFAULT_CHARSET);
        if (params != null && !params.isEmpty()) {
            Set<String> keys = params.keySet();
            for (String key : keys) {
                builder.addQueryParameter(key, params.get(key));
            }
        }

        if (headers != null && !headers.isEmpty()) {
            Set<String> keys = headers.keySet();
            for (String key : keys) {
                builder.addHeader(key, params.get(key));
            }
        }
        Future<Response> f = builder.execute();
        String body = f.get().getResponseBody(DEFAULT_CHARSET);
        http.close();
        return body;
    }

    /**
     * @return 返回类型:
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @description 功能描述: get 请求
     */
    public static String get(String url) throws KeyManagementException, NoSuchAlgorithmException, NoSuchProviderException, UnsupportedEncodingException, IOException, ExecutionException, InterruptedException {
        return get(url, null);
    }

    /**
     * @return 返回类型:
     * @throws IOException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws UnsupportedEncodingException
     * @description 功能描述: get 请求
     */
    public static String get(String url, Map<String, String> params) throws KeyManagementException, NoSuchAlgorithmException, NoSuchProviderException, UnsupportedEncodingException, IOException, ExecutionException, InterruptedException {
        return get(url, params, null);
    }

    /**
     * @return 返回类型:
     * @throws IOException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @description 功能描述: POST 请求
     */
    public static String post(String url, Map<String, String> params) throws IOException, ExecutionException, InterruptedException {
        AsyncHttpClient http = new AsyncHttpClient();
        AsyncHttpClient.BoundRequestBuilder builder = http.preparePost(url);
        builder.setBodyEncoding(DEFAULT_CHARSET);
        if (params != null && !params.isEmpty()) {
            Set<String> keys = params.keySet();
            for (String key : keys) {
                builder.addParameter(key, params.get(key));
            }
        }
        Future<Response> f = builder.execute();
        String body = f.get().getResponseBody(DEFAULT_CHARSET);
        http.close();
        return body;
    }

    public static BufferedInputStream downloadImg(String url) throws ExecutionException, InterruptedException, IOException {
    	BufferedInputStream bis = null; 
    	AsyncHttpClient http = new AsyncHttpClient();
    	AsyncHttpClient.BoundRequestBuilder builder = http.prepareGet(url);
    	builder.setBodyEncoding(DEFAULT_CHARSET);
    	Future<Response> f = builder.execute();
    	if (f.get().getContentType().equalsIgnoreCase("text/plain")) {
    	} else {
    		bis = new BufferedInputStream(f.get().getResponseBodyAsStream());
    	}
    	http.close();
    	return bis;
    }

    public static String post(String url, String s) throws IOException, ExecutionException, InterruptedException {
        AsyncHttpClient http = new AsyncHttpClient();
        AsyncHttpClient.BoundRequestBuilder builder = http.preparePost(url);
        builder.setBodyEncoding(DEFAULT_CHARSET);
        builder.setBody(s);
        Future<Response> f = builder.execute();
        String body = f.get().getResponseBody(DEFAULT_CHARSET);
        http.close();
        return body;
    }
    
    public  static void main(String[] args) throws Exception{
//    	String accessToken = "ulhEL9F2CciJezmGj47C-d3hAJZwXiAANctVIwSHwBRK7Z1enIRWeZKZekk8jS5abIkCo2YmMSDlqUFKOKvSaw";
//		String openId = "oeZTVt6XlCphRnCI-DlpdTyk27p4";
//		UserInfo u = WeChat.user.getUserInfo(accessToken, openId);
		
//    	String url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
//    	String ss = "<xml><sign><![CDATA[FC8204F30EE7286B56F72206447F58BF]]></sign><body><![CDATA[购买]]></body><mch_id><![CDATA[1229736502]]></mch_id><total_fee>1</total_fee><spbill_create_ip><![CDATA[172.30.81.114]]></spbill_create_ip><notify_url><![CDATA[http://baokan.peopleyuqing.com.cn]]></notify_url><appid><![CDATA[wx38f78e271995c3ba]]></appid><openid><![CDATA[owHN-uKFqFpsxT7f8ohTNoCNGx6Y]]></openid><out_trade_no><![CDATA[a4]]></out_trade_no><nonce_str><![CDATA[e7efb83b26644ee9b1d44aa2099dc72f]]></nonce_str><trade_type><![CDATA[JSAPI]]></trade_type></xml>";
//		String u = HttpKit.post(url, ss);
//		System.out.println(u);
    	String str = "223.202.116.5, 123.151.139.156";
    	
    	
    	System.out.println( str.substring(0,str.indexOf(",")).trim() );
		
//		System.out.println(JSON.toJSONString(u));
		//System.out.println(WeChat.message.sendText(accessToken , openId , "测试"));
    	//Map<String, Object> mgs = WeChat.uploadMedia(accessToken, "image", new File("C:\\Users\\郭华\\Pictures\\13.jpg"));
    	//System.out.println(JSON.toJSONString(mgs));
    }
}