package cn.jesong.webcall.cuour.entity;

import cn.jesong.webcall.resource.VisitorInfo;

import java.util.Date;

public class ApiPushLog extends VisitorInfo{
	
	private static final long serialVersionUID = 1L;
    
    public Integer getPushCount() {
		return pushCount;
	}

	public void setPushCount(Integer pushCount) {
		this.pushCount = pushCount;
	}

	public String getResponseStr() {
		return responseStr;
	}

	public void setResponseStr(String responseStr) {
		this.responseStr = responseStr;
	}

	public Date getFirsrErrorTime() {
		return firsrErrorTime;
	}

	public void setFirsrErrorTime(Date firsrErrorTime) {
		this.firsrErrorTime = firsrErrorTime;
	}

	public Date getPushTime() {
		return pushTime;
	}

	public void setPushTime(Date pushTime) {
		this.pushTime = pushTime;
	}

	public Date getLatErrorTime() {
		return latErrorTime;
	}

	public void setLatErrorTime(Date latErrorTime) {
		this.latErrorTime = latErrorTime;
	}

    public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

    private Integer pushCount ;
    
    private String responseStr ;
    
	private Date firsrErrorTime ;
    
    private Date pushTime ;
    
    private Date latErrorTime ;
    
    private Integer status ;
    
    public Integer getCardId() {
		return cardId;
	}

	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}

	private Integer cardId ;
}
