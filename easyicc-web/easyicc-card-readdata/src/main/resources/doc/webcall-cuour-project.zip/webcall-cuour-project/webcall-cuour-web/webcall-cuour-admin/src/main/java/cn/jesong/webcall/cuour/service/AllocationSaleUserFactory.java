package cn.jesong.webcall.cuour.service;

import cn.jesong.webcall.cuour.entity.CardRule;

public abstract class AllocationSaleUserFactory {

	private static AllocationSaleUserInterface weight = new WeightAllocationImpl();
	private static AllocationSaleUserInterface cycle = new AlternateAllocationImpl();

	/**
	 * 算法
	 * @param rule 名片分配规则信息
	 * @return
	 */
	public static AllocationSaleUserInterface getInstance(CardRule rule) {

		if (rule == null)
			return weight;

		//算法类型
		int algorithm = rule.getAlgorithm();

		//权重
		if (algorithm == 0)
			return weight;

		//轮循
		if (algorithm == 1)
			return cycle;

		return weight;
	}

}
