package cn.jesong.webcall.cuour.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import cn.jesong.webcall.cuour.cache.entity.RedisSaleUser;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.redis.ServiceFactory;

/**
 * 轮循分配（标记分配）
 * 
 * @author Administrator
 *
 */
@Service
public class AlternateAllocationImpl implements AllocationSaleUserInterface {

	private final static Log _logger = LogFactory.getLog(AlternateAllocationImpl.class);

	// redisKeyPrefix
	private String RKP = "JESONG:CUOUR:SYSTEM:";

	/**
	 * 循环分配算法
	 * 
	 * @param card
	 * @param allocationUsers 最新可分配客服组list
	 * @return
	 */
	@Override
	public SaleUser allocationSaleUser(Card card, List<SaleUser> allocationUsers) {

		if (allocationUsers == null)
			return null;

		if (allocationUsers.size() < 1)
			return null;
		// RKP = ConfKit.get("RKP");

		// 上次轮循分配客服组状态缓存
		String redisKey = RKP + "_" + card.getCompanyId() + "_" + card.getSubjectId() + "_" + card.getSchooleId()
				+ "_allot";
		String lastTimeUserList = ServiceFactory.getMessageCache().getRedisService().get(redisKey);
		List<RedisSaleUser> redisList = JSON.parseArray(lastTimeUserList, RedisSaleUser.class);

		// 最新客服组转换为增加标记状态客服组
		List<RedisSaleUser> saleUserList = transitionSaleUsers(allocationUsers);

		// 最新客服组按userId排序
		Collections.sort(saleUserList);

		return getSaleUser(redisKey, redisList, saleUserList);
	}

	/**
	 * 将最新客服组转换为增加标记状态客服组
	 * 
	 * @param allocationUsers
	 * @return
	 */
	private List<RedisSaleUser> transitionSaleUsers(List<SaleUser> allocationUsers) {
		List<RedisSaleUser> userList = new ArrayList<RedisSaleUser>();
		for (SaleUser s : allocationUsers) {
			RedisSaleUser r = new RedisSaleUser();
			r = toRedisSaleUser(s);
			userList.add(r);
		}
		return userList;
	}

	/**
	 * 获取分配销售客服
	 *
	 * @param redisKey           缓存key:公司id_校区id_项目id
	 * @param cache              上次轮循后客服组缓存
	 * @param allocationUsers    最新客服组信息
	 * @param allocationUsersMap 最新客服组信息Map,判断工号是否存在
	 * @return
	 */
	public SaleUser getSaleUser(String redisKey, List<RedisSaleUser> redisList, List<RedisSaleUser> saleUserList) {

		RedisSaleUser allocationSaleUser = new RedisSaleUser();
		
		if(saleUserList == null || saleUserList.size() < 1)
			return null;
		
		//上次分配客服组缓存不存在时，取最新客服组第一位客服，并将最新客服组重组排序存入缓存
		if(redisList == null || redisList.size() < 1) {
			allocationSaleUser = newRedis(redisKey, saleUserList);
			sortRedisSaleUsers(redisKey, saleUserList, allocationSaleUser);
			return allocationSaleUser;
		}
		
		Set<String> saleUserSet = new HashSet<String>();
		for (RedisSaleUser s : saleUserList) {
			saleUserSet.add(s.getUserId());
		}

		//轮循缓存客服组，从第一位开始匹配最新客服组，存在匹配成功，则将此客服做为分配客服
		int count = 0;
		boolean seekOut = false;
		for (RedisSaleUser r : redisList) {
			if (!saleUserSet.contains(r.getUserId())) {
				count++;
				continue;
			}

			if (seekOut)
				break;

			for (RedisSaleUser s : saleUserList) {
				if (r.getUserId().equals(s.getUserId())) {
					allocationSaleUser = s;
					seekOut = true;
					break;
				}
			}
		}

		//轮循缓存客服组，从第一位开始匹配最新客服组，匹配都不成功时，取最新客服组第一位客服，并将最新客服组重组排序存入缓存
		if (count == redisList.size())
			allocationSaleUser = newRedis(redisKey, saleUserList);

		//最新客服组重组排序存入缓存
		sortRedisSaleUsers(redisKey, saleUserList, allocationSaleUser);

		return allocationSaleUser;
	}

	/**
	 * 当前redisKey对应缓存为空时，建立新缓存，并返回当前客服组中第一个客服
	 * 
	 * @param redisKey
	 * @param allocationUsers
	 * @param redisService
	 * @return
	 */
	public RedisSaleUser newRedis(String redisKey, List<RedisSaleUser> saleUserList) {

		// 最新轮循分配客服组状态
		List<RedisSaleUser> newestCashe = new ArrayList<RedisSaleUser>();

		// 上次轮循缓存为空时，获取当前最新可分配客服组list中第一位客服返回
		RedisSaleUser saleUser = saleUserList.get(0);

		_logger.info("公司" + saleUser.getCompanyId() + "轮循分配算法：redisKey：" + redisKey + "缓存为空,建立新缓存，并返回当前客服组中第一个客服:"
				+ JSON.toJSON(saleUser));

		int count = 0;

		// 记录当次分配情况，对已分配客服做标记，并存入redis
		for (RedisSaleUser s : saleUserList) {
			if (count == 0) {
				s.setSign(1);
				s.setAllocated(true);
			} else {
				s.setSign(0);
				s.setAllocated(false);
			}
			count++;
			newestCashe.add(s);
		}

		ServiceFactory.getMessageCache().getRedisService().set(redisKey, JSON.toJSONString(newestCashe));

		return saleUser;
	}

	/**
	 * 将客服组重组排序，并写入缓存
	 * 
	 * @param saleUsers          最新客服组
	 * @param allocationSaleUser 分配客服
	 * @return
	 */
	private void sortRedisSaleUsers(String redisKey, List<RedisSaleUser> saleUserList,
			RedisSaleUser allocationSaleUser) {
		// （集合上部分）上次最终分配客服的下一位客服及列表至末尾的客服
		List<RedisSaleUser> up = new ArrayList<RedisSaleUser>();

		// （集合下部分）上次最终分配客服及列表至顶部的客服
		List<RedisSaleUser> below = new ArrayList<RedisSaleUser>();

		boolean sign = false;
		for (RedisSaleUser s : saleUserList) {
			if (s.getUserId().equals(allocationSaleUser.getUserId())) {
				sign = true;
				s.setSign(1);
				below.add(s);
				continue;
			}

			// sign：切割数组标记
			if (sign) {
				s.setSign(0);
				up.add(s);
			} else {
				s.setSign(0);
				below.add(s);
			}
		}

		// 重组缓存客服组，将最终分配客服的后继客服批量移至组内最前端
		up.addAll(below);
		ServiceFactory.getMessageCache().getRedisService().set(redisKey, JSON.toJSONString(up));
	}

	/**
	 * SaleUser转 ReRedisSaleUser
	 * 
	 * @param saleUser
	 * @return
	 */
	private RedisSaleUser toRedisSaleUser(SaleUser saleUser) {
		RedisSaleUser asu = new RedisSaleUser();
		asu.setUserId(saleUser.getUserId());
		asu.setActualAllocationCount(saleUser.getActualAllocationCount());
		asu.setActualRatio(saleUser.getActualRatio());
		asu.setActualValidCount(saleUser.getActualValidCount());
		asu.setAllocationCount(saleUser.getAllocationCount());
		asu.setAllocationWeight(saleUser.getAllocationWeight());
		asu.setBackCount(saleUser.getBackCount());
		asu.setBackRatio(saleUser.getBackRatio());
		asu.setBusinessGroupId(saleUser.getBusinessGroupId());
		asu.setBusinessGroupName(saleUser.getBusinessGroupName());
		asu.setCards(saleUser.getCards());
		asu.setCompanyId(saleUser.getCompanyId());
		asu.setExpiredCount(saleUser.getExpiredCount());
		asu.setFairRatio(saleUser.getFairRatio());
		asu.setFinishedCount(saleUser.getFinishedCount());
		asu.setMaxCardSize(saleUser.getMaxCardSize());
		asu.setRealName(saleUser.getRealName());
		asu.setSaleAllocationCount(saleUser.getSaleAllocationCount());
		asu.setSaleFinishedCount(saleUser.getSaleFinishedCount());
		asu.setSalesTypeId(saleUser.getSalesTypeId());
		asu.setSalesTypeName(saleUser.getSalesTypeName());
		asu.setSchoolId(saleUser.getSchoolId());
		asu.setSchoolName(saleUser.getSchoolName());
		asu.setSubjectId(saleUser.getSubjectId());
		asu.setSubjectName(saleUser.getSubjectName());
		asu.setUserWeiXinOpenId(saleUser.getUserWeiXinOpenId());
		asu.setValidCount(saleUser.getValidCount());
		asu.setWeixinPushStatus(saleUser.isOpenWeixinPush());
		return asu;
	}

}
