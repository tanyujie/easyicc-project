package cn.jesong.webcall.distribution.api.service;

import cn.jesong.webcall.cuour.cache.CacheDataLoader;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.event.SettingChangeEvent;
import cn.jesong.webcall.distribution.api.domain.DistributionResult;

import java.util.List;

/**
 * 分配名片服务提供的对外接口
 */
public interface IDistributionCardService  extends CacheDataLoader {
    /**
     * 分配名片
     * @param cardList
     * @throws Exception
     */
    DistributionResult allocationCard(List<Card> cardList, String serveName);

    /**
     * 删除本地缓存接口
     * @param companyId
     * @throws Exception
     */
    DistributionResult removeLocalCacheByCompanyId(Integer companyId);

    /**
     * 手工分配名片
     * @param companyId
     * @param cardId
     * @param userId
     * @param operatorId
     * @return
     */
    boolean userAllocationCard(int companyId, int cardId, String userId, String operatorId);

    /**
     * 清楚轮训算法
     * @param companyId
     * @param userId
     */
    void clearAlternateCache(int companyId, String userId);

    /**
     * 配置修改后，通知此方法清楚缓存
     * @param event
     */
    void onApplicationEvent(SettingChangeEvent event);

    /**
     * 清除本地缓存
     * @param companyId
     * @param userId
     */

    void clearCache(int companyId,String userId);



}
