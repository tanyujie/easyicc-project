package cn.jesong.webcall.cuour.controller.setting;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.BusinessGroup;
import cn.jesong.webcall.cuour.service.setting.BusinessGroupService;

@Controller
@RequestMapping("/setting/businessGroup")
public class BusinessGroupController extends SimpleController<Integer, BusinessGroup>{
	
	@Autowired
	private BusinessGroupService businessGroupService;

	@Override
	protected String getPrefix() {
		return "/setting/businessGroup";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, BusinessGroup> getHibernateService() {
		return this.businessGroupService;
	}

	@Override
	protected void beforeCreateOrUpdate(BusinessGroup entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
	}
	
	

}