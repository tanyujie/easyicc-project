package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.CardRuleCache;
import cn.jesong.webcall.cuour.entity.CardRule;

import java.util.concurrent.ConcurrentHashMap;

public class LocalCardRuleCache implements CardRuleCache {
	
	private ConcurrentHashMap<Integer, CardRule> cache = new ConcurrentHashMap<Integer,  CardRule>();

	@Override
	public CardRule getCardRule(int companyId) {
		return cache.get(companyId);
	}

	@Override
	public void remove(int companyId) {
		cache.remove(companyId);
	}

	@Override
	public void init(CardRule cardRule) {
		cache.put(cardRule.getCompanyId(), cardRule);
	}

}
