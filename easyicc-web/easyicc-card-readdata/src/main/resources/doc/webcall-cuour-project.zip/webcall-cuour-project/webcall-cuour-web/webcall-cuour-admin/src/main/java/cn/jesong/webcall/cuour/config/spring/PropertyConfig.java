package cn.jesong.webcall.cuour.config.spring;

import java.util.Properties;



import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import cn.jesong.webcall.cuour.util.ResourceUtil;



public class PropertyConfig extends PropertyPlaceholderConfigurer {

	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess,Properties props) throws BeansException {
		props = appendEnvProperties();
		super.processProperties(beanFactoryToProcess, props);
	}

	private Properties appendEnvProperties() {
		return ResourceUtil.getProperties();
	}
	
	

}
