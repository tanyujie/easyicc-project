package cn.jesong.webcall.cuour.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import cn.eutils.web.platform.db.SQLEso;
import cn.eutils.web.platform.db.SQLInfo;
import cn.jesong.webcall.cuour.entity.CustomerReport;
import cn.jesong.webcall.cuour.util.DateUtil;

@Service
public class ReportService {

	private final static Log _logger = LogFactory.getLog(ReportService.class);

	@Resource(name = "jdbcTemplateX")
	private JdbcTemplate jdbcTempalteX;

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	/*public List<CustomerReport> getCustomerReport(Map<String, Object> params){
		String sql = "select a.create_user_id, c.real_name, nvl2(b.chat_total, b.chat_total, 0) as chat_total , "+
					 " nvl2(b.effect_total, b.effect_total, 0) as effect_total, a.card_total, a.valid_total, a.back_total from ( "+
					 "	  select create_user_id, count(*) as card_total, sum(decode(is_valid, 1, 1, 0)) as valid_total,  "+
					 "	         sum(decode(is_back, 1, 1, 0)) as back_total "+
					 "	  from js_visitor_info  "+
					 "	  where  / company_id = {companyId} /  " + //and allocation_status="+Card.STATUS_FINISHED+
					 "	        and create_time between / {startTime} / and / {endTime} / "+
					 "			/ and ext_column8 = {subjectId} /" +
					 "			/ and ext_column9 = {schoolId} /" +
					 "	  group by create_user_id "+
					 "	) a left join( "+
					 "	  select user_id, count(*) as chat_total, sum(decode(effective, 1, 1, 0)) as effect_total from js_chat_record  "+
					 "	     where / company_id = {companyId} / "+
					 "	      and create_time between / {startTime} / and / {endTime} / "+
					 "	     group by user_id "+
					 "	) b on a.create_user_id = b.user_id" +
					 "  inner join js_user c on a.create_user_id=c.user_id";
		SQLEso eso = SQLInfo.parseSQLEso(sql, params);
		return this.jdbcTemplate.query(eso.getSQL(), eso.getParams(), new RowMapper<CustomerReport>(){

			@Override
			public CustomerReport mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				int chatTotal = rs.getInt("chat_total");
				int cardTotal = rs.getInt("card_total");
				int validTotal = rs.getInt("valid_total");
				int backTotal = rs.getInt("back_total");
				int effectTotal = rs.getInt("effect_total");
				return new CustomerReport(rs.getString("create_user_id"), rs.getString("real_name"), effectTotal, chatTotal, cardTotal, validTotal, backTotal);
			}
			
		});
	}*/
	public List<CustomerReport> getCustomerReport(Map<String, Object> params, String startTime, String endTime) {

		//主数据
		List<CustomerReport> list = getCustomerReportInfo(params);
		//_logger.info("ReportService:主数据:" + JSON.toJSON(list));

		//分库数据参数
		Integer companyId = Integer.parseInt(params.get("companyId") + "");
		String tableMonth = DateUtil.getCurDate();
		if (startTime != null && !"".equals(startTime))
			tableMonth = startTime.split(" ")[0];

		String[] strings = tableMonth.split("-");
		tableMonth = strings[0] + strings[1];

		StringBuffer userIds = new StringBuffer();
		for (CustomerReport cr : list) {
			userIds.append("'" + cr.getCreateUserId() + "',");
		}
		String userStr = userIds.toString().substring(0, userIds.toString().length() - 1);

		//分库数据（对话数）
		List<CustomerReport> listChatRecord = getCustomerReportRecord(tableMonth, companyId, userStr, startTime, endTime);
		//_logger.info("ReportService:分库数据:" + JSON.toJSON(listChatRecord));

		//合并数据
		List<CustomerReport> retrunList = new ArrayList<CustomerReport>();
		for (CustomerReport cr : list) {
			for (CustomerReport c : listChatRecord) {
				if (cr.getCreateUserId().equals(c.getCreateUserId())) {
					CustomerReport newCr = new CustomerReport(cr.getCreateUserId(), cr.getRealName(), c.getEffectTotal(), c.getChatTotal(), cr.getCardTotal(), cr.getValidTotal(), cr.getBackTotal());
					retrunList.add(newCr);
				}
			}
		}
		//_logger.info("ReportService:分库数据:" + JSON.toJSON(retrunList));

		return retrunList;
	}

	//主数据
	public List<CustomerReport> getCustomerReportInfo(Map<String, Object> params) {
		StringBuffer sqlBuffer = new StringBuffer();
		sqlBuffer.append("select a.create_user_id, c.real_name, a.card_total, a.valid_total, a.back_total from ( ");
		sqlBuffer.append("select create_user_id, count(*) as card_total, sum(decode(is_valid, 1, 1, 0)) as valid_total,");
		sqlBuffer.append("sum(decode(is_back, 1, 1, 0)) as back_total ");
		sqlBuffer.append("from js_visitor_info ");
		sqlBuffer.append("where  / company_id = {companyId} / ");
		sqlBuffer.append("and create_time between / {startTime} / and / {endTime} / ");
		sqlBuffer.append("/ and ext_column8 = {subjectId} / ");
		sqlBuffer.append("/ and ext_column9 = {schoolId} / ");
		sqlBuffer.append("group by create_user_id ) A ");
		sqlBuffer.append("inner join js_user c on a.create_user_id=c.user_id");

		SQLEso eso = SQLInfo.parseSQLEso(sqlBuffer.toString(), params);
		//_logger.info("ReportService:getCustomerReportInfo:" + eso.getSQL() + "," + JSON.toJSON(eso.getParams()));
		return this.jdbcTemplate.query(eso.getSQL(), eso.getParams(), new RowMapper<CustomerReport>() {

			@Override
			public CustomerReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				int cardTotal = rs.getInt("card_total");
				int validTotal = rs.getInt("valid_total");
				int backTotal = rs.getInt("back_total");
				return new CustomerReport(rs.getString("create_user_id"), rs.getString("real_name"), 0, 0, cardTotal, validTotal, backTotal);
			}

		});
	}

	//分库对话数
	public List<CustomerReport> getCustomerReportRecord(String tableMonth, Integer companyId, String userStr, String startTime, String endTime) {
		StringBuffer sqlBuffer = new StringBuffer();
		sqlBuffer.append("select user_id, count(*) as chat_total, sum(decode(effective, 1, 1, 0)) as effect_total ");
		sqlBuffer.append("  from  js_chat_record_" + tableMonth);
		sqlBuffer.append("  partition (\"C_" + companyId + "\")  ");
		sqlBuffer.append("  where company_id = ?  ");
		sqlBuffer.append("  and  create_time  between  to_date(?,'yyyy-MM-dd hh24:mi:ss')  and  to_date(?,'yyyy-MM-dd hh24:mi:ss')  ");
		sqlBuffer.append("  and  user_id  in (" + userStr + ")  ");
		sqlBuffer.append("  group by user_id");

		//_logger.info("ReportService:getCustomerReportRecord:" + sqlBuffer.toString() + ",companyId:" + companyId + "," + startTime + "," + endTime);
		return this.jdbcTempalteX.query(sqlBuffer.toString(), new Object[] { companyId, startTime, endTime }, new RowMapper<CustomerReport>() {

			@Override
			public CustomerReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				int chatTotal = rs.getInt("chat_total");
				int effectTotal = rs.getInt("effect_total");
				return new CustomerReport(rs.getString("user_id"), "", effectTotal, chatTotal, 0, 0, 0);
			}

		});
	}

}
