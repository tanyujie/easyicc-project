package cn.jesong.webcall.cuour.controller.setting;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.controller.SimpleController;
import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.BackType;
import cn.jesong.webcall.cuour.service.setting.BackTypeService;

@Controller
@RequestMapping("/setting/backType")
public class BackTypeController extends SimpleController<Integer, BackType>{
	
	@Autowired
	private BackTypeService backTypeService;

	@Override
	protected String getPrefix() {
		return "/setting/backType";
	}

	@Override
	protected Object getQueryParams(HttpServletRequest request) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", OnLine.getCurrentUserDetails().getCompanyId());
		return params;
	}

	@Override
	protected HibernateDAO<Integer, BackType> getHibernateService() {
		return backTypeService;
	}

	@Override
	protected void beforeCreateOrUpdate(BackType entity) {
		entity.setCompanyId(OnLine.getCurrentUserDetails().getCompanyId());
	}
	
	

}
