package cn.jesong.webcall.cuour;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DistributionStarterApplication {

    private static final Logger logger = LoggerFactory.getLogger(DistributionStarterApplication.class);

    public DistributionStarterApplication() {
        logger.info("read start");
    }

    public static void main(String[] args) {
/*      不依赖spring启动dubbo
        System.out.println("read run");
        com.alibaba.dubbo.container.Main.main(args);*/
    	//System.out.println("启动参数:"+args[0]);
        ApplicationContext applicationContext =
                new ClassPathXmlApplicationContext("classpath:cuour-application.xml");

    }
}
