package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.ScheduingCache;
import cn.jesong.webcall.cuour.cache.entity.SchedulingTime;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.SimpleDateFormat;
import java.util.*;

public class LocalScheduingCache implements ScheduingCache {
	
	private final static Log _logger = LogFactory.getLog(LocalScheduingCache.class);
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private Map<Integer, Map<String, List<SchedulingTime>>> caches = new HashMap<Integer, Map<String, List<SchedulingTime>>>();

	@Override
	public void init(int companyId, List<SchedulingTime> schedulingTimes) {
		Map<String, List<SchedulingTime>> cache = this.caches.get(companyId);
		if(cache == null){
			cache = new HashMap<String, List<SchedulingTime>>();
			this.caches.put(companyId, cache);
		}
		for(SchedulingTime t : schedulingTimes){
			List<SchedulingTime> list = cache.get(t.getUserId());
			if(list == null){
				list = new ArrayList<SchedulingTime>();
				cache.put(t.getUserId(), list);
			}
			list.add(t);
		}
	}

	@Override
	public void remove(int companyId) {
		this.caches.remove(companyId);
	}

	@Override
	public boolean isInWorkTime(int companyId, String userId, Date time) {
		Map<String, List<SchedulingTime>> cache = this.caches.get(companyId);
		List<SchedulingTime> list = null;
		if(cache != null){
			list = cache.get(userId);
			if(list != null){
				for(SchedulingTime t : list){
					if(time.after(t.getStartTime()) && time.before(t.getEndTime())){
						return true;
					}
				}
			}
		}
		if(cache == null){
			_logger.warn(String.format("公司[%s]的客服[%s]的缓存不存在", companyId, userId));
		}
		if(list == null || list.isEmpty()){
			_logger.warn(String.format("公司[%s]的客服[%s]无排班计划", companyId, userId));
		}else{
			StringBuilder sb = new StringBuilder("回电时间").append(formatter.format(time)).append("不在公司").append(companyId).append("的客服").append(userId).append("的排班计划");
			for(SchedulingTime s : list){
				sb.append(formatter.format(s.getStartTime())).append("~").append(formatter.format(s.getEndTime())).append("   ");
			}
			_logger.warn(sb.toString());
		}
		return false;
	}

	

}
