package cn.jesong.webcall.cuour.util;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateUtil {
	// 取得系统当前时间,格式为yyyy-mm-dd
	public static String getCurDate() {
		Calendar rightNow = Calendar.getInstance();
		int year = rightNow.get(Calendar.YEAR);
		int month = rightNow.get(Calendar.MONTH) + 1;
		String monthStr = "" + month;
		if(month < 10) {
			monthStr = 0 + monthStr;
		}
		int day = rightNow.get(Calendar.DATE);
		String dayStr = "" + day;
		if(day < 10) {
			dayStr = 0 + dayStr;
		}
		return year + "-" + monthStr + "-" + dayStr;
	}

	public static Date getCurrentDate() {
		return Calendar.getInstance().getTime();
	}

	// 取得系统当前时间,格式为yyyy-mm-dd
	public static String getCurrentDate1() {
		Calendar rightNow = Calendar.getInstance();
		int year = rightNow.get(Calendar.YEAR);
		int month = rightNow.get(Calendar.MONTH) + 1;
		int day = rightNow.get(Calendar.DATE);
		int hour = rightNow.get(Calendar.HOUR_OF_DAY);
		int minute = rightNow.get(Calendar.MINUTE);
		return year + "" + month + "" + day + "" + hour + "" + minute;
	}

	// 取得系统当前时间前n个月的相对应的一天

	public static String getNMonthBeforeCurrentDay(int n) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, -n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);

	}

	// 取得系统当前时间后n个月的相对应的一天
	public static String getNMonthAfterCurrentDay(int n) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);

	}

	// 取得系统当前时间前n天,格式为yyyy-mm-dd
	public static String getNDayBeforeCurrentDate(int n) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DAY_OF_MONTH, -n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);
	}

	// 取得系统当前时间后n天,格式为yyyy-mm-dd
	public static String getNDayAfterCurrentDate(int n) {
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DAY_OF_MONTH, n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);
	}

	// ---------------------------------------------------------------------
	// 取过去一个时间对应的系统当年的一天
	public static String getCurrentDateAfterPastDate(String sPastDate) {
		if (sPastDate != null && !sPastDate.equals("")) {
			Date date = null;
			try {
				date = switchStringToDate(sPastDate);
			} catch (Exception ex) {
			}
			Calendar c = Calendar.getInstance();
			c.setTime(date);
			int iPastYear = c.get(Calendar.YEAR);
			Calendar c1 = Calendar.getInstance();
			int iCurrentYear = c1.get(Calendar.YEAR);
			c.add(Calendar.YEAR, iCurrentYear - iPastYear);
			return "" + c.get(Calendar.YEAR) + "-"
					+ (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DATE);
		} else {
			return null;
		}
	}

	// -----------------------------------------------------------------
	// 将一个日期字符串转化成日期
	public static Date switchStringToDate(String sDate) throws Exception {
		Date date = null;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			date = df.parse(sDate);
			return date;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	public static Date stringToDate(String sDate) throws Exception {
		Date date = null;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			date = df.parse(sDate);
			return date;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	// 输入两个字符串型的日期，比较两者的大小
	public static boolean compareTwoDateBigOrSmall(String fromDate,
			String toDate) {
		Date dateFrom = null;
		try {
			dateFrom = switchStringToDate(fromDate);
		} catch (Exception ex) {
		}
		Date dateTo = null;
		try {
			dateTo = switchStringToDate(toDate);
		} catch (Exception ex1) {
		}
		if (dateFrom.before(dateTo)) {
			return true;
		} else {
			return false;
		}
	}

	// 将一个日期字符串转化成Calendar
	public static Calendar switchStringToCalendar(String sDate) {
		Date date = null;
		try {
			date = switchStringToDate(sDate);
		} catch (Exception ex) {
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c;
	}

	// 将一个日期转化成Calendar
	public static Calendar switchStringToCalendar(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c;
	}

	// ------------------------------------------------------------------------
	// 取得某个时间前n个月的相对应的一天
	public static String getNMonthBeforeOneDay(String sDate, int n) {
		Calendar c = switchStringToCalendar(sDate);
		c.add(Calendar.MONTH, -n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);

	}

	// 取得某个时间后n个月的相对应的一天
	public static String getNMonthAfterOneDay(String sDate, int n) {
		Calendar c = switchStringToCalendar(sDate);
		c.add(Calendar.MONTH, n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);

	}

	// 取得某个时间前n天,格式为yyyy-mm-dd
	public static String getNDayBeforeOneDate(String sDate, int n) {
		Calendar c = switchStringToCalendar(sDate);
		c.add(Calendar.DAY_OF_MONTH, -n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);
	}

	// 取得某个时间后n天,格式为yyyy-mm-dd
	public static String getNDayAfterOneDate(String sDate, int n) {
		Calendar c = switchStringToCalendar(sDate);
		c.add(Calendar.DAY_OF_MONTH, n);
		return "" + c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1)
				+ "-" + c.get(Calendar.DATE);
	}

	// 判断系统当前时间是不是润年
	public static boolean isRunNian() {
		Calendar rightNow = Calendar.getInstance();
		int year = rightNow.get(Calendar.YEAR);
		if (0 == year % 4 && (year % 100 != 0 || year % 400 == 0)) {
			return true;
		} else {
			return false;
		}

	}

	// 得到系统当前月份
	public static int getMonthOfCurrentDate() {
		Calendar rightNow = Calendar.getInstance();

		int month = rightNow.get(Calendar.MONTH) + 1;

		return month;
	}

	public static String formatDateToStringByType(Date newDate,
			String formatType) {
		String sDate = null;
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatType);
			sDate = simpleDateFormat.format(newDate);
			// System.out.println(newDate);
			// System.out.println(sDate);
		} catch (NullPointerException e) {

		} catch (IllegalArgumentException e) {

		} catch (Exception e) {

		}
		return sDate;
	}
	
	 /* 
     * 将时间转换为时间戳
     */    
    public static String dateToStamp(String s) throws ParseException {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(s);
        long ts = date.getTime();
        res = String.valueOf(ts);
        return res;
    }
    
    /* 
     * 将时间戳转换为时间
     */
    public static String stampToDate(String s){
        String res;
        if(s != null && !"".equals(s) && !"null".equals(s)) {
        	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMM");
            long lt = new Long(s);
            Date date = new Date(lt);
            res = simpleDateFormat.format(date);
            res = "_" + res;
        } else {
        	res = "";
        }
        
        return res;
    }
    
    public static String stampToDate2(String s) throws ParseException {
        String res;
        if(s != null && !"".equals(s)) {
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	   	    Date date = sdf.parse(s);
	   	    long startDay = (long) (date.getTime());
	   	    res = DateUtil.stampToDate("" + startDay);
        } else {
        	res = "";
        }
        
        return res;
    }

    public static String escapeJson(String string){
		if (string == null || string.length() == 0){
			return string;
		}
        char b,c = 0;
        int len = string.length();
        StringBuilder sb = new StringBuilder(len+4);
        String t;
      
        for (int i=0;i<len;i ++){
            b = c;
            c = string.charAt(i);
            switch (c){
	            case '\\':
	            	sb.append("\\\\");
	                break;
	            case '\'':
	                sb.append("\\'");
	                break;
	            case '/':
	                if (b == '<')sb.append("\\");
	                sb.append(c);
	                break;
	            case '\b':
	            	sb.append("\\b");
	                break;
	            case '\t':
	                sb.append("\\t");
	                break;
	            case '\n':
	                sb.append("\\n");
	                break;
	            case '\f':
	                sb.append("\\f");
	                break;
	            case '\r':
	                sb.append("\\r");
	                break;
	            default:
	                if (c <' '||(c >='\u0080'&&c <'\u00a0')||(c >='\u2000'&& c <'\u2100')){
	                    t = "000" + Integer.toHexString(c);
	                    sb.append("\\u"+t.substring(t.length()-4));
	                }else{
	                	sb.append(c);
	                }
            }
        }
      
        System.out.println(sb.toString());
        try{return sb.toString();}finally{sb=null;}
	}
    
    public static String getCurrentTime() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(new Date());
	}
    
	public static void main(String args[]) throws Exception {
//		String s = "2019-01-08 19:38:23";
//
//		String e = DateUtil.stampToDate2(s);
//		System.out.println(e);
		
//		 String string = "2016-10-24 21:59:06";
//	     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//	     Date date = sdf.parse(string);
//	     long startDay = (long) (date.getTime());
//	     //   String res = sdf.format(date);
//	        System.out.println(DateUtil.stampToDate("" + startDay));
		
		System.out.println(escapeJson("<adfdf>\r\nadfdf\"\'</dfdf>"));
	}

}
