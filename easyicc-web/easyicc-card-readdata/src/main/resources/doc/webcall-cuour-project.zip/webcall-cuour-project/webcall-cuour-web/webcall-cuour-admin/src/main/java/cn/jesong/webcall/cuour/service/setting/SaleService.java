package cn.jesong.webcall.cuour.service.setting;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.entity.Sales;
import cn.jesong.webcall.cuour.service.SettingService;

@Service
public class SaleService extends SettingService<String, Sales>{
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Override
	protected Class<Sales> getEntityClass() {
		return Sales.class;
	}

	@Override
	protected String getTemplateQuerySQL() {
		return "from Sales where / companyId = {companyId} /"
				+" / and schoolId = {schoolId} / "
				+" / and subjectId = {subjectId} / "
				+" / and businessGroupId = {businessGroupId} / "
				+" / and salesTypeId = {salesTypeId} / ";
	}
	
	public List<Map<String, Object>> getCouldSettingUser(int companyId){
		String sql = "select a.user_id, a.real_name, a.nick_name "+
					 " from js_user a "+
					 " where a.company_id=? and not exists( "+
					 "   select 1 from js_cuour_sales b where a.company_id=b.company_id and a.user_id=b.user_Id "+
					 " )";
		return this.jdbcTemplate.queryForList(sql, companyId);
	}
	
	public List<Map<String, Object>> getUsers(int companyId){
		String sql = "select user_id, real_name, nick_name from js_user where company_id=?";
		return this.jdbcTemplate.queryForList(sql, companyId);
	}
	
	public List<Map<String, Object>> getSales(int companyId){
		String sql = "select a.user_id, a.real_name, a.nick_name "+
				 " from js_user a "+
				 " where a.company_id=? and exists( "+
				 "   select 1 from js_cuour_sales b where a.company_id=b.company_id and a.user_id=b.user_Id "+
				 " )";
		return this.jdbcTemplate.queryForList(sql, companyId);
	}
}
