package cn.jesong.webcall.cuour.cache.local;

import cn.jesong.webcall.cuour.cache.SubjectUserCache;
import cn.jesong.webcall.cuour.cache.entity.CompanyTotal;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.entity.Card;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocalSubjectUserCache implements SubjectUserCache {
	
	private Log _logger = LogFactory.getLog(LocalSubjectUserCache.class);
	
	private Map<Integer, List<SaleUser>> caches = new HashMap<Integer, List<SaleUser>>();
	
	private Map<Integer, CompanyTotal> totalCaches = new HashMap<Integer, CompanyTotal>();
	
	@Override
	public List<SaleUser> getUsersOfSubjectId(int companyId, int subjectID, int schoolId) {
		List<SaleUser> list = new ArrayList<SaleUser>();
		List<SaleUser> users = this.caches.get(companyId);
		if(users != null){
			for(SaleUser user : users){
				if(user.getSubjectId() == subjectID && user.getSchoolId() == schoolId){
					list.add(user);
				}
			}
		}
		return list;
	}
	
	@Override
	public List<SaleUser> getAllSaleUsers(int companyId) {
		List<SaleUser> users = this.caches.get(companyId);
		return users == null ? new ArrayList<SaleUser>() : users;
	}

	@Override
	public void allocationCard(SaleUser user, Card card) {
		user.allocationCard(card);
		if(!card.isSaleCard()){
			CompanyTotal total = this.totalCaches.get(user.getCompanyId());
			total.addAllocation(user.getBusinessGroupId(), 1);
			this.calculateRatio(user.getCompanyId());
			_logger.info(String.format("[%s]分配1个名片[%s]给客服[%s], 当前分配情况：权重[%s], 分配量[%s], 退回量[%s], 有效量[%s]",user.getCompanyId(), card.getId(),
					user.getUserId(),user.getAllocationWeight(), user.getAllocationCount(), user.getBackCount(), user.getValidCount()));
		}else{
			_logger.info(String.format("[%s]分配1个高意向名片[%s]给客服[%s]",user.getCompanyId(), card.getId(), user.getUserId()));
		}
	}
	
	@Override
	public void userAllocationCard(int companyId, Card card, String userId) {
		SaleUser user = this.getUser(companyId, userId);
		if(user != null){
			this.allocationCard(user, card);
			this.calculateRatio(companyId);
		}
	}

	@Override
	public void remove(int companyId) {
		this.caches.remove(companyId);
		this.totalCaches.remove(companyId);
	}

	@Override
	public void init(int companyId, List<SaleUser> users/*, List<Card> cards*/) {
		this.caches.put(companyId, users);
		CompanyTotal total = new CompanyTotal();
		Map<String, SaleUser> index = new HashMap<String, SaleUser>();
		for(SaleUser user : users){
			total.addWeight(user.getBusinessGroupId(), user.getAllocationWeight());
			total.addAllocation(user.getBusinessGroupId(), user.getAllocationCount());
			index.put(user.getUserId(), user);
		}
		this.totalCaches.put(companyId, total);
		
		/*for(Card card : cards){
			SaleUser user = index.get(card.getUserId());
			if(user != null){
				user.initAddCard(card);
				if(card.getAllocationStatus() == Card.STATUS_FINISHED){
					user.finished(card.getId());
				}
			}
		}*/
		this.calculateRatio(companyId);
	}
	
	private void calculateRatio(int companyId){
		List<SaleUser> users = this.caches.get(companyId);
		CompanyTotal total = this.totalCaches.get(companyId);
		for(SaleUser u : users){
			if(total.getTotalWeight(u.getBusinessGroupId())>0){
				u.setFairRatio(this.getRatio(u.getAllocationWeight(), total.getTotalWeight(u.getBusinessGroupId())));
			}
			if(total.getAllocationTotal(u.getBusinessGroupId()) > 0){
				u.setActualRatio(this.getRatio(u.getAllocationCount(), total.getAllocationTotal(u.getBusinessGroupId())));
			}
		}
	}
	
	private double getRatio(int s1, int s2){
		BigDecimal b1 = new BigDecimal(s1 * 100);
		BigDecimal b2 = new BigDecimal(s2);
		BigDecimal ratio = b1.divide(b2, 2, BigDecimal.ROUND_HALF_UP);
		return ratio.doubleValue();
	}
	
	@Override
	public SaleUser getUser(int companyId, String userId){
		List<SaleUser> users = this.caches.get(companyId);
		SaleUser u = null;
		if(users != null){
			for(SaleUser user : users){
				if(user.getUserId().equals(userId)){
					u = user;
					break;
				}
			}
		}
		return u;
	}

	@Override
	public void backCard(int companyId, int cardId, String userId) {
		SaleUser user = this.getUser(companyId, userId);
		if(user != null){
			user.back(cardId);
		}
	}
	
	@Override
	public void finished(int companyId, int cardId, String userId, boolean isSaleCard){
		SaleUser user = this.getUser(companyId, userId);
		if(user != null){
			user.finished(cardId, isSaleCard);
		}
	}

	@Override
	public void expired(int companyId, int cardId, String userId){
		SaleUser user = this.getUser(companyId, userId);
		if(user==null)
			return;
		
		user.setExpiredCount(user.getExpiredCount() + 1);
	}

	
}
