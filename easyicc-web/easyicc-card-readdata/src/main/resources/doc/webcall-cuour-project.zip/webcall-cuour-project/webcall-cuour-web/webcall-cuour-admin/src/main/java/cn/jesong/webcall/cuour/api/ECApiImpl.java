package cn.jesong.webcall.cuour.api;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.secret.SecretFactory;
import cn.jesong.webcall.cuour.service.CardPushLogService;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.HttpClientUtil;

/**
 * EC接口
 * @author zhanglu
 *
 */
public class ECApiImpl implements ThirdApiInterface {

	private final static Log logger = LogFactory.getLog(ECApiImpl.class);

	@Autowired
	private CardPushLogService service;

	/**
	 * ActionConfig 配置信息
	 * VisitorCardData 名片数据模型
	 * template tpl模板
	 */
	@Override
	public String httpPost(ActionConfig ac, String template) throws Exception{

		if (ac == null) {
			logger.info("----------------------------->推送失败，第三方接口配置信息为空!");
			return null;
		}
		String url = ac.getInterfaceUrl();
		String res = null;

		if (StringUtils.isEmpty(url)) {
			logger.info("----------------------------->推送失败，第三方接口配置信息URL为空!");
			return res;
		}
		SecretFactory instance = SecretFactory.getInstance(ac.getThirdPlatform());
		if (instance == null) {
			logger.info("----------------------------->未找到秘钥工厂类型！");
		}
		String token = instance.getGenerator().generatorKeyStr(ac);
		if (StringUtils.isEmpty(token)) {
			logger.info("----------------------------->推送失败，第三方接口token获取失败!");
			return res;
		}

		/*String optUserId = CardUtil.getValue(ac.getConfig(), "optUserId");
		JSONObject data = JSON.parseObject(template);
		if (data.containsKey("optUserId"))
			data.put("optUserId", optUserId);
		if (data.containsKey("followUserId"))
			data.put("followUserId", optUserId);
		if (data.containsKey("f_gender")) {
			if (data.getInteger("f_gender") != 0 && data.getInteger("f_gender") != 1) {
				data.put("f_gender", 0);
			} else {
				data.put("f_gender", data.getInteger("f_gender") == 0 ? 1 : 2);
			}
		} else {
			data.put("f_gender", 0);
		}*/
		String charset = CardUtil.getValue(ac.getConfig(), "charset");
		if (charset == null) {
			charset = "UTF-8";
		}

		String corpId = CardUtil.getValue(ac.getConfig(), "corpId");
		url = url + "?Authorization=" + token + "&CORP_ID=" + corpId;

		logger.info("----------------------------->提交数据：" + template);
		res = HttpClientUtil.httpPost(url, template, charset);
		return res;
	}
}
