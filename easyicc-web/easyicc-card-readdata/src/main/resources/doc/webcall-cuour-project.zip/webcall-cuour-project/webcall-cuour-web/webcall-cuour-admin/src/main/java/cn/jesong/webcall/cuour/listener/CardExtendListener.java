package cn.jesong.webcall.cuour.listener;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.service.CardExtendService;
import cn.jesong.webcall.cuour.service.WeChatNotifyExtendService;

@Component
public class CardExtendListener implements AllocationListener {
	
	@Resource(name="sendDataService")
	private CardExtendService cardExtendService;

	@Resource(name="weixinService")
	private WeChatNotifyExtendService weixinService;
	
	/**
	 * 名片分配前的处理
	 * @param card
	 */
	@Override
	public void before(Card card) {
		try {
			ActionConfig ac = cardExtendService.getActionConfig(card.getCompanyId());
			
			if(ac==null||ac.getStatus()!=1)
				return;
			
			if(ac.getCmd()!=null&&"before".equals(ac.getCmd()))//配置为分配之前,默认分配之后
			{
				this.cardExtendService.action(ac,card);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * 名片分配后的处理
	 * @param card
	 * @param allocation
	 */
	@Override
	public void after(Card card, boolean allocation) {
		if(allocation) {
			try {
				ActionConfig ac = cardExtendService.getActionConfig(card.getCompanyId());
				
				if(ac==null||ac.getStatus()!=1)
					return;
				
				if(ac.getCmd()!=null&&"before".equals(ac.getCmd()))//配置为分配之前,默认分配之后
					return;
				
				this.cardExtendService.action(ac,card);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
