package cn.jesong.webcall.cuour.service;

import java.net.URI;
import java.net.URL;

import javax.annotation.Resource;

import net.sf.json.JSONArray;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.jesong.webcall.cuour.api.DefaultApiImpl;
import cn.jesong.webcall.cuour.api.ThirdApiFactory;
import cn.jesong.webcall.cuour.api.ThirdApiInterface;
import cn.jesong.webcall.cuour.api.pattern.ApiPatternFactory;
import cn.jesong.webcall.cuour.api.pattern.IApiPattern;
import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.entity.VisitorCardData;
import cn.jesong.webcall.cuour.util.DateUtil;
import cn.jesong.webcall.cuour.util.KeyUtil;
import cn.jesong.webcall.cuour.util.SslClient;
import cn.jesong.webcall.resource.ChatRecordDetail;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.message.BasicHeader;

@Service
public class ThirdApiInvokeService {

	private final static Log _logger = LogFactory.getLog(ThirdApiInvokeService.class);

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate template;

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate templateX;

	@Autowired
	private CardPushLogService service;

	public static void main(String[] args) throws Exception {
		ThirdApiInvokeService ps = new ThirdApiInvokeService();
		//String url = "http://cn828.800app.com/uploadfile/staticresource/257790/269129/sy_AddLeads.aspx";
		String url = "http://cn828.800app.com/uploadfile/staticresource/257790/269129/sy_AddLeads.aspx";
		String oid = "257790";
		String mKey = KeyUtil.getKey(oid);
		//
		url += "?oid=" + oid;
		url += "&mKey=" + mKey;
		/*StringBuilder info = new StringBuilder();
		info.append("{");
		info.append("\"crmzdy_88232948\": \"01000000003981306798359584623714\","); // 姓名
		info.append("\"crm_holder\": \"梁静莉\","); // 性别
		info.append("\"crmzdy_80974415\": \"13955812677\","); // 电话
		info.append("\"crm_name\": \"亳州\","); // QQ
		
		
		info.append("\"crmzdy_80974418\": \"\","); // 微信
		info.append("\"crmzdy_88070094\": \"\","); // 回电时间
		info.append("\"crmzdy_88232342\": \"2019-03-20 15:48:59\","); // 备注
		
		info.append("\"crmzdy_88232295\": \"2019-03-20 16:05:48\","); // 学历
		
		info.append("\"crmzdy_80979018\": \"0\","); // 层级
		info.append("\"crmzdy_81253707\": \"4.经济师\","); // 业务组
		info.append("\"crmzdy_88167326\": \"8.全国网校\","); // 搜索词
		
		info.append("\"crmzdy_80974439\": \"0\","); // 意向校区
		
		info.append("\"crmzdy_80979020\": \"\","); // 项目
		info.append("\"crmzdy_88232284\": \"liumingyan\","); // 学员意向班型
		
		info.append("\"crmzdy_88232306\": \"\","); // 名片创建者
		info.append("\"crmzdy_88232317\": \"\","); // 名片创建时间
		
		info.append("\"ciphertext\": \""+info.toString()+"\",");
		
		info.append("}");*/
		/*String info = VisitorCardData.test();

		System.out.println(info);
		
		url += "&ciphertext=" + URLEncoder.encode(info.toString(),"UTF-8");
		System.out.println(url);
		
		//	System.out.println(info.toString());
		String res = ps.httpPost(url, info.toString(), "GBK");

		System.out.println(res);*/
	}

	/**
	 * 名片数据推送第三方
	 * @param ac
	 * @param card
	 * @param data
	 * @return
	 */
	public String invoke(ActionConfig ac, VisitorCardData card, String data) {
		_logger.info("-------------------------------------->新版推送接口日志");
		_logger.info("-------------------------------------->新版推送data:" + data);
		String res = null;
		ThirdApiInterface instance = ThirdApiFactory.getInstance(ac);
		if (instance != null) {
			try {
				res = instance.httpPost(ac, data);
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				res = null;
			}
			if (instance instanceof DefaultApiImpl) {
				IApiPattern instance2 = ApiPatternFactory.getInstance(ac);
				if (instance2 != null) {
					boolean matching = instance2.isMatching(ac, res);
					service.saveLog(ac, card, res, matching);
				} else {
					_logger.info("-------------------------------------->DefaultApiImpl() 未配置匹配算法");
				}
				return res;
			}
			if (res != null) {
				IApiPattern instance2 = ApiPatternFactory.getInstance(ac);
				if (instance2 != null) {
					boolean matching = instance2.isMatching(ac, res);
					service.saveLog(ac, card, res, matching);
				} else {
					_logger.info("-------------------------------------->未配置匹配算法");
				}

			}
		} else {
			_logger.info("-------------------------------------->未配置工厂信息");
		}

		if (res == null) {
			//推送未成功，可能和程序出错有关
			service.saveLog(ac, card, "推送未成功，可能和程序出错有关!", false);
		}
		return res;
	}

	private String httpPost(String apiInvokeUrl, String data, String charset) {

		if (charset == null || charset.trim().length() == 0) {
			charset = "UTF-8";
		}

		try {
			URL url = new URL(apiInvokeUrl);
			//2019-03-05注释掉以下代码，因为会丢失端口
			// URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(),
			//	url.getQuery(), null);

			//2019-03-05  换成新方法创建URI，支持端口
			URI uri = new URI(url.getProtocol(), null, url.getHost(), url.getPort(), url.getPath(), url.getQuery(), null);
			_logger.info("Third推送第三方:time:"+DateUtil.getCurrentTime()+",url:"+apiInvokeUrl);
			HttpClient client;

			if ("https".equals(url.getProtocol())) {
				client = new SslClient();
				
			} else {
				client = new DefaultHttpClient();
				
			}

			HttpPost post = new HttpPost(uri);
			post.addHeader("Content-Type", "application/json");
			StringEntity s = new StringEntity(data, charset);
			s.setContentEncoding("UTF-8");
			s.setContentType("text/json;charset=UTF-8");
			post.setEntity(s);

			HttpResponse rsp = client.execute(post);

			
			if (rsp.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				HttpEntity entity = rsp.getEntity();
				String res = EntityUtils.toString(entity);
				
				_logger.info("向第三方推送crm信息----------》uri：" + uri);
				return res;
			} else {
				// jsonObject = JSONObject.fromObject("{}");
				_logger.info("---------------------》Third结束向第三方推送crm信息推送未成功！endTime:" + DateUtil.getCurrentTime());
				_logger.info("---------------------》Third返回code码：" + rsp.getStatusLine().getStatusCode()+ ",endTime:" + DateUtil.getCurrentTime());
			}
			// logger.info("消息推送模板连接接口成功：返回结果："+rsp.getStatusLine().getStatusCode());

		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}

		return null;
	}

}
