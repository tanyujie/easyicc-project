package cn.jesong.webcall.cuour.controller.sale;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.eutils.web.platform.permission.user.OnLine;
import cn.jesong.webcall.cuour.service.setting.SchoolService;
import cn.jesong.webcall.cuour.service.setting.SubjectService;

@Controller
@RequestMapping("/sale/url")
public class SaleURLController {

	private final static String PREFIX = "/sale/url";
	
	@Autowired
	private SubjectService subjectService;
	
	@Autowired
	private SchoolService schoolService;
	
	@RequestMapping("/index")
	public String index(ModelMap model) throws Exception{
		int companyId = OnLine.getCurrentUserDetails().getCompanyId();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		model.put("subjects", subjectService.getListByTemplate(params));
		model.put("schooles", schoolService.getListByTemplate(params));
		return PREFIX + "/index";
	}
	
}
