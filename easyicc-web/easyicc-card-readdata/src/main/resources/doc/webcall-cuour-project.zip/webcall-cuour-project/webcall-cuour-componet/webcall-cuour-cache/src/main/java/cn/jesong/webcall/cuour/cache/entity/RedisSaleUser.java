package cn.jesong.webcall.cuour.cache.entity;

import java.io.Serializable;
import java.text.Collator;
import java.util.Locale;

/**
 * redis缓存中销售信息
 * @author Administrator
 *
 */
public class RedisSaleUser extends SaleUser implements Serializable,Comparable<RedisSaleUser> {

	private static final long serialVersionUID = 1L;

	//分配标记 0默认 1当前客服为上次分配客服
	private Integer sign;

	//上次轮循时是否已分配过 是true 否false
	private boolean allocated;

	public RedisSaleUser() {
	}

	public RedisSaleUser(Integer sign, boolean allocated) {
		this.sign = sign;
		this.allocated = allocated;
	}

	@Override
	public String toString() {
		return "RedisSaleUser [sign=" + sign + ", allocated=" + allocated + ", getSaleAllocationCount()=" + getSaleAllocationCount() + ", getSaleFinishedCount()=" + getSaleFinishedCount()
				+ ", getActualValidCount()=" + getActualValidCount() + ", getActualAllocationCount()=" + getActualAllocationCount() + ", getMaxCardSize()=" + getMaxCardSize() + ", getBackRatio()="
				+ getBackRatio() + ", getFairRatio()=" + getFairRatio() + ", getActualRatio()=" + getActualRatio() + ", getRealName()=" + getRealName() + ", getAllocationWeight()="
				+ getAllocationWeight() + ", getSchoolName()=" + getSchoolName() + ", getSubjectName()=" + getSubjectName() + ", getBusinessGroupName()=" + getBusinessGroupName()
				+ ", getSalesTypeName()=" + getSalesTypeName() + ", getCards()=" + getCards() + ", getValidCount()=" + getValidCount() + ", getBackCount()=" + getBackCount()
				+ ", getAllocationCount()=" + getAllocationCount() + ", getFinishedCount()=" + getFinishedCount() + ", getExpiredCount()=" + getExpiredCount() + ", isOpenWeixinPush()="
				+ isOpenWeixinPush() + ", getUserWeiXinOpenId()=" + getUserWeiXinOpenId() + ", getUserId()=" + getUserId() + ", getCompanyId()=" + getCompanyId() + ", getSchoolId()=" + getSchoolId()
				+ ", getSubjectId()=" + getSubjectId() + ", getBusinessGroupId()=" + getBusinessGroupId() + ", getSalesTypeId()=" + getSalesTypeId() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	public Integer getSign() {
		return sign;
	}

	public void setSign(Integer sign) {
		this.sign = sign;
	}

	public boolean isAllocated() {
		return allocated;
	}

	public void setAllocated(boolean allocated) {
		this.allocated = allocated;
	}

	@Override
	public int compareTo(RedisSaleUser o) {
		return Collator.getInstance(Locale.CHINESE).compare(this.getUserId(), o.getUserId());
	}
	
	

}
