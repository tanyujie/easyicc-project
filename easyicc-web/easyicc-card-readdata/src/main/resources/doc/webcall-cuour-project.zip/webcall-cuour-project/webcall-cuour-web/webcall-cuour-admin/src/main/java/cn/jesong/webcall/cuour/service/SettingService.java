package cn.jesong.webcall.cuour.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import cn.jesong.webcall.cuour.dao.HibernateDAO;
import cn.jesong.webcall.cuour.entity.CompanySetting;
import cn.jesong.webcall.cuour.event.SettingChangeEvent;
import org.springframework.transaction.annotation.Transactional;

public abstract class SettingService<ID extends java.io.Serializable, E extends CompanySetting> extends HibernateDAO<ID, E>{

	@Autowired  
	private ApplicationContext applicationContext;
	
	@Override
    @Transactional
	public ID save(E obj) {
		ID id = super.save(obj);
		this.onSettingChanged(obj);
		return id;
	}

	@Override
    @Transactional
	public void saveOrUpdate(E obj) {
		super.saveOrUpdate(obj);
		this.onSettingChanged(obj);
	}

	@Override
    @Transactional
	public void delete(E obj) {
		super.delete(obj);
		this.onSettingChanged(obj);
	}
	
	private void onSettingChanged(E obj){
		CompanySetting cs = (CompanySetting)obj;
		this.onSettingChanged(cs.getCompanyId());
	}
	
	protected final void onSettingChanged(int companyId){
		this.applicationContext.publishEvent(new SettingChangeEvent(companyId));
	}
	
}
