package cn.jesong.webcall.cuour.redis;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.jesong.webcall.cuour.service.RedisService;
import redis.clients.jedis.ShardedJedisPool;

public class MessageCache {
	
	private final static Log _logger = LogFactory.getLog(MessageCache.class);
	
	private IRedisService redisService;
	
	public MessageCache(ShardedJedisPool pool){
		//Properties props = ConfigLoader.getInstance().load();
		//Properties p = ConfigLoader.getInstance().load("live", "visitor");
		redisService = new RedisService(pool);
	}
	
	public IRedisService getRedisService(){
		return redisService;
	}
}
