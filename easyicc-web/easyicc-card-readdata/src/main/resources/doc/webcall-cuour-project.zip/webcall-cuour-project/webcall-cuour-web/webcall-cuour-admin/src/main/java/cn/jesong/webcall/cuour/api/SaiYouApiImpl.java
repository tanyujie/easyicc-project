package cn.jesong.webcall.cuour.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.secret.SecretFactory;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.HttpClientUtil;
import cn.jesong.webcall.cuour.util.KeyUtil;

public class SaiYouApiImpl implements ThirdApiInterface{
	
	private final static Log _logger = LogFactory.getLog(SaiYouApiImpl.class);

	@Override
	public String httpPost(ActionConfig ac, String data) throws Exception{
		if(ac == null){
			_logger.info("----------------------------->推送失败，第三方接口配置信息为空!");
			return null;
		}
		String url = ac.getInterfaceUrl();
		String res = null;
		if (url != null && !"".equals(url)) {
			//String oid = "257790";
			SecretFactory instance = SecretFactory.getInstance(ac.getThirdPlatform());
			if(instance == null){
				_logger.info("----------------------------->未找到秘钥工厂类型！");
			}
			String mKey = instance.getGenerator().generatorKeyStr(ac);//KeyUtil.getKey(oid);//换成工厂生成秘钥
			if(mKey == null){
				//此处为了兼容
				mKey = KeyUtil.getKey("257790");
			}
			String oid = CardUtil.getValue(ac.getConfig(), "oid");
			if(oid == null){
				//此处为了兼容
				oid = "257790";
			}
			
			url += "?oid=" + oid;
			url += "&mKey=" + mKey;
			String charset = CardUtil.getValue(ac.getConfig(), "charset");//"GBK"; 
			if(charset == null){
				//此处为了兼容
				charset = "GBK";
			}
			res = HttpClientUtil.httpPost(url, data, charset);
		}
		return res;
	}

}
