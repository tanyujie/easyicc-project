package cn.jesong.webcall.cuour.cache;

import cn.jesong.webcall.cuour.entity.CardRule;

public interface CardRuleCache{
	
	public CardRule getCardRule(int companyId);
	
	public void remove(int companyId);
	
	public void init(CardRule cardRule);
}
