package cn.jesong.webcall.cuour.cache.entity;

import java.util.concurrent.locks.ReentrantLock;

public class Lock {

	private int companyId;
	
	private ReentrantLock lock = new ReentrantLock();
	
	public Lock(int companyId){
		this.companyId = companyId;
	}
	
	public int getCompanyId(){
		return this.companyId;
	}
	
	public void lock(){
		this.lock.lock();
	}
	
	public void unlock(){
		this.lock.unlock();
	}
	
	
}
