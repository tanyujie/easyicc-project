package cn.jesong.webcall.cuour.entity;

import javax.persistence.*;

/**
 * 微信信息
 * @author hanjianxin
 *
 */
@Entity
@Table(name = "js_card_weixin_info")
public class WeixinInfo implements CompanySetting {
	/**
	 * id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "js_card_weixin_info_id_seq")
	@SequenceGenerator(name = "js_card_weixin_info_id_seq", sequenceName = "js_card_weixin_info_id_seq", allocationSize = 1)
	private int id;
	
	/**
	 * userid
	 */
	@Column(name = "user_id", nullable = true)
	private String userId;
	
	/**
	 * openid
	 */
	@Column(name = "open_id", nullable = true)
	private String openid;
	
	/**
	 * 用户名
	 */
	@Column(name = "user_name", nullable = true)
	private String userName;
	
	/**
	 * 微信昵称
	 */
	@Column(name = "nick_name", nullable = true)
	private String nickName;
	
	/**
	 * 状态0：关闭,1：启用
	 */
	@Column(name = "status", nullable = false)
	private Integer status;
	
	/**
	 * 发送时机: allocation_after,名片分配后，allocation_before，名片分配前
	 */
	@Column(name = "send_opportunity", nullable = false)
	private String sendOpportunity;
	
	/**
	 * 公司id
	 */
	@Column(name = "company_id", nullable = false)
	private Integer companyId;
	
	/**
	 * 公司name
	 */
	@Column(name = "company_name", nullable = false)
	private String companyName;
	
	/**
	 * 是否删除
	 */
	@Column(name = "is_delete", nullable = false)
	private int isDelete;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getSendOpportunity() {
		return sendOpportunity;
	}

	public void setSendOpportunity(String sendOpportunity) {
		this.sendOpportunity = sendOpportunity;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}

}
