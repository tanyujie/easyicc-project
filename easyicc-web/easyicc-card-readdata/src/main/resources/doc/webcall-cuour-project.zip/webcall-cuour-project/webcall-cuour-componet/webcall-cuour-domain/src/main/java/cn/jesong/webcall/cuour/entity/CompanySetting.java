package cn.jesong.webcall.cuour.entity;

public interface CompanySetting {

	public Integer getCompanyId();
	
}
