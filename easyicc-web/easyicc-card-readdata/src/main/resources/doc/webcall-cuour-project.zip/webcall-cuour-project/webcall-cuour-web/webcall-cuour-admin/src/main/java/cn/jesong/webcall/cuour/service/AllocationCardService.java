package cn.jesong.webcall.cuour.service;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;


import cn.jesong.webcall.distribution.api.service.IDistributionCardService;
import cn.jesong.webcall.pushdata.api.service.IPushdataService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import net.kinfe.util.properties.ConfigLoader;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;

import cn.jesong.webcall.core.client.CoreClient;
import cn.jesong.webcall.cuour.cache.CacheDataLoader;
import cn.jesong.webcall.cuour.cache.CacheFactory;
import cn.jesong.webcall.cuour.cache.entity.SaleUser;
import cn.jesong.webcall.cuour.cache.entity.SchedulingTime;
import cn.jesong.webcall.cuour.common.enums.NoDistributeTimeTypeEnum;
import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.entity.CardLog;
import cn.jesong.webcall.cuour.entity.CardRule;
import cn.jesong.webcall.cuour.entity.School;
import cn.jesong.webcall.cuour.entity.Subject;
import cn.jesong.webcall.cuour.event.SettingChangeEvent;
import cn.jesong.webcall.cuour.listener.AllocationListenerService;
import cn.jesong.webcall.cuour.redis.ServiceFactory;
import cn.jesong.webcall.cuour.service.setting.CardRuleService;
import cn.jesong.webcall.logic.UserMgrException;
import cn.jesong.webcall.object.UserSession;
import cn.jesong.webcall.resource.User;
import org.springframework.util.CollectionUtils;

@Service
public class AllocationCardService implements CacheDataLoader, ApplicationListener<SettingChangeEvent>{
	
	private final static Log _logger = LogFactory.getLog(AllocationCardService.class);
	
	private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private final static SimpleDateFormat formatter2 = new SimpleDateFormat("yyyyMMdd");
	
	private final static SimpleDateFormat formatter3 = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
	
	private final static SimpleDateFormat formatter4 = new SimpleDateFormat("HH:mm");
	
	private final static String SYSTEMID = "system";
	
	private final static String RKP = "JESONG:CUOUR:SYSTEM:";
	
	private ScheduledExecutorService scheduledExecutor = Executors.newScheduledThreadPool(2);
	
	private ExecutorService allocationExecutor = Executors.newCachedThreadPool();
	
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CacheFactory cacheFactory;
	
	@Autowired
	private CardRuleService cardRuleService;
	
	@Autowired
	private CardLogService cardLogService;
	
	@Autowired
	private AllocationListenerService allocationListenerService;
	
	@Autowired
	private NotifyService notifyService;
	
	@Autowired
	private FiltrationSaleUserService filtrationSaleUserService;
	
	private String serverName;
    @Autowired
    private IDistributionCardService distributionCardService;

    @Autowired
    private IPushdataService pushdataService;
	
//	@PostConstruct
//	public void init(){
//
//	   this.serverName	= ConfigLoader.getInstance().load().getProperty("clusterName");
//
//	   _logger.info("名片分配serverName:" + this.serverName);
//
//		scheduledExecutor.scheduleWithFixedDelay(new Runnable(){
//
//			@Override
//			public void run() {
//				synchronized(AllocationCardService.this){
//					String time = formatter4.format(new Date());
//					List<CardRule> list = cardRuleService.getList("from CardRule " +
//							" where useAllocation = 1 and serverName = ?", new Object[]{serverName});
//					for(CardRule cr: list){
//						if(cr.getResetTime() != null && !cr.getResetTime().equals("") && time.equals(cr.getResetTime())){
//							_logger.info("重置["+cr.getCompanyId()+"]");
//							cacheFactory.remove(cr.getCompanyId());
//						}
//					}
//				}
//			}
//
//		}, 60, 60, TimeUnit.SECONDS);
//		scheduledExecutor.scheduleWithFixedDelay(new Runnable(){
//			@Override
//			public void run() {
//				//此处加锁， 为了防止重新初始化导致的并发
//				try{
//					synchronized(AllocationCardService.this){
//						String time = formatter2.format(new Date());
//						//_logger.debug("分配开始:"+time);
//
//						//
//						/*int count = updateBeforeCard();
//						if(count > 0){
//							_logger.info("更新"+count+"条过期数据到人工分配");
//						}*/
//						//找出需要分配的名片、需要关联名片分配配置表
//						long _start = System.currentTimeMillis();
//						List<Card> cards = getAllWaitForAllocationCards();
//						_logger.info("获取可分配名片数:"+cards.size()+" 使用时间"+(System.currentTimeMillis() - _start)+"ms");
//						if(cards.size() > 0){
//							//CountDownLatch latch = new CountDownLatch(cards.size());
//							for(Card card : cards){
//								//判断是否初始化, 此处是单线程， 不用考虑并发问题
//								cacheFactory.checkInit(card.getCompanyId(), AllocationCardService.this, time);
//								allocationExecutor.execute(new AllocationTask(cacheFactory.getCardRuleCache().getCardRule(card.getCompanyId()), card));
//							}
//							/*try {
//								latch.await();
//							} catch (InterruptedException e) {
//							}*/
//							_logger.info("分配任务执行完成， 一共分配"+cards.size());
//						}
//						List<Card> expiredCards = getExpiredCards();
//						if(expiredCards.size() > 0){
//							//CountDownLatch latch = new CountDownLatch(cards.size());
//							for(Card card : expiredCards){
//								if(!card.isSaleCard()){
//									allocationExecutor.execute(new ExpiredTask(card));
//								}
//							}
//							/*try {
//								latch.await();
//							} catch (InterruptedException e) {
//							}*/
//							_logger.info("回收超期数据:"+expiredCards.size());
//						}
//
//					}
//				}catch(Throwable e){
//					_logger.error(e.getMessage(), e);
//				}
//			}
//		}, 120, 120, TimeUnit.SECONDS);
//	}
	
	@Transactional
	private boolean expired(Card c){
		Date now = new Date();
		String sql = "update js_visitor_info set allocation_status = ?, is_back = 0, is_expired = 1, user_id = ?, modify_identity = ?, back_user_id = ?, back_time = ? where id = ? and modify_identity= ? ";
		int count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, "", UUID.randomUUID().toString(), SYSTEMID, now, c.getId(), c.getModifyIdentity());
		if(count > 0){
			this.createCardLog(c.getCompanyId(), c.getId(), c.getUserId(), CardLog.ALLOCATION_TYPE_EXPIRED, SYSTEMID, now);
			this.cacheFactory.getSubjectUserCache().expired(c.getCompanyId(), c.getId(), c.getUserId());
			this.notifyService.notifyWaitAllocation(c.getCompanyId(), "您有一个名片需要分配");
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 设置无效
	 * @param companyId
	 * @param cardId
	 * @return
	 */
	public boolean setNotValidate(int companyId, int cardId){
		//synchronized(this){
			String time = formatter2.format(new Date());
			cacheFactory.checkInit(companyId, this, time);
			Card c = this.getCard(cardId);
			if(c != null && c.getCompanyId() == companyId && c.getIsBack() == 1 && c.getAllocationStatus() == Card.STATUS_WAIT_USE_ALLOCATION){
				String sql = "update js_visitor_info set is_valid = 0, is_expired = 0, is_back=0,  allocation_status = ? where id = ? and modify_identity = ?";
				int count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, cardId, c.getModifyIdentity());
				if(count > 0){
					return true;
				}
			}
			return false;
		//}
	}
	
	/**
	 * 名片退回
	 * @param companyId
	 * @param cardId
	 * @param userId
	 * @throws Exception 
	 */
	@Transactional
	public boolean back(int companyId, int cardId, String userId, int backType, String desp) throws Exception{
		//synchronized(this){
			List<CardLog> logs = this.cardLogService.getList("from CardLog where cardId = ? and allocationType = ?", cardId, CardLog.ALLOCATION_TYPE_BACK);
			if(logs != null && logs.size() > 0){
				throw new Exception("该名片已经被退回过一次， 不能再退回!");
			}else{
				Date now = new Date();
				String time = formatter2.format(now);
				cacheFactory.checkInit(companyId, this, time);
				Card c = this.getCard(cardId);
				if(c.isSaleCard()){
					throw new Exception("该名片为高意向名片， 不能退回!");
				}
				if(c != null && c.getUserId().equals(userId) && c.getCompanyId() == companyId){
					String sql = "update js_visitor_info set allocation_status = ?, is_back = 1, is_expired = 0, back_type = ?, back_desp = ?,  user_id = ?, modify_identity = ?, back_user_id = ?, back_time = ? where id = ? and modify_identity= ? ";
					int count = this.jdbcTemplate.update(sql, Card.STATUS_WAIT_USE_ALLOCATION, backType, desp, "", UUID.randomUUID().toString(), c.getUserId(), now, cardId, c.getModifyIdentity());
					if(count > 0){
						this.cacheFactory.getSubjectUserCache().backCard(companyId, cardId, userId);
						this.createCardLog(companyId, cardId, userId, CardLog.ALLOCATION_TYPE_BACK, userId, now);
						this.notifyService.notifyWaitAllocation(c.getCompanyId(), "您有一个名片需要分配");
					}
					return true;
				}
				return false;
			}
		//}
	}
	
	@Transactional
	public boolean finished(int companyId, int cardId, String userId, String desp){
		//synchronized(this){
			String time = formatter2.format(new Date());
			cacheFactory.checkInit(companyId, this, time);
			Card c = this.getCard(cardId);
			if(c != null && c.getUserId().equals(userId) && c.getCompanyId() == companyId){
				String sql = "update js_visitor_info set allocation_status = ?, is_back = 0, is_expired = 0, finish_desp = ?,  user_id = ?, modify_identity = ? where id = ? and modify_identity= ? ";
				int count = this.jdbcTemplate.update(sql, Card.STATUS_FINISHED, desp, userId, UUID.randomUUID().toString(), cardId, c.getModifyIdentity());
				if(count > 0){
					this.cacheFactory.getSubjectUserCache().finished(companyId, cardId, userId, c.isSaleCard());
					if(c.isSaleCard()){
						this.createCardLog(companyId, cardId, userId, CardLog.ALLOCATION_TYPE_SALE_FINIHSED, userId, new Date());
					}else{
						this.createCardLog(companyId, cardId, userId, CardLog.ALLOCATION_TYPE_FINISHED, userId, new Date());
					}
				}
				return true;
			}
			return false;
		//}
	}
	
	public Card getCard(int cardId){
		List<Card> list = this.jdbcTemplate.query("select * from js_visitor_info where id = ?", new Object[]{cardId}, new CardRowMapper());
		if(list != null && !list.isEmpty()){
			return list.get(0);
		}else{
			return null;
		}
	}
	
	public Card getCard(int companyId,String staticId){
		List<Card> list = this.jdbcTemplate.query("select * from js_visitor_info where company_id = ? and visitor_static_id = ?", new Object[]{companyId,staticId}, new CardRowMapper());
		if(list != null && !list.isEmpty()){
			return list.get(0);
		}else{
			return null;
		}
	}
	
	/**
	 * 更新名片校区
	 * @param cardId
	 * @param modifyIdentity
	 * @param subjectId
	 * @param schoolId
	 * @return
	 */
	public boolean updateCard(int cardId, String modifyIdentity, int subjectId, int schoolId){
		//extColumn8项目 extColumn9校区
		String sql = "update js_visitor_info set ext_column8 = ?, ext_column9 = ?, modify_identity = ? where id = ? and modify_identity= ? ";
		int len = this.jdbcTemplate.update(sql, subjectId, schoolId, UUID.randomUUID().toString(), cardId, modifyIdentity);
		return len > 0 ?  true : false;
	}
	
	/**
	 * 手工分配名片
	 * @param companyId
	 * @param cardId
	 * @param userId
	 * @param operatorId
	 */
	public boolean userAllocationCard(int companyId, int cardId, String userId, String operatorId){
        return distributionCardService.userAllocationCard( companyId,  cardId,  userId,  operatorId);
		//synchronized(this){
//			String time = formatter2.format(new Date());
//			cacheFactory.checkInit(companyId, this, time);
//			Card c = this.getCard(cardId);
//			if(c != null && c.getAllocationStatus() == Card.STATUS_WAIT_USE_ALLOCATION){
//				int i = this.updateCard(cardId, userId, Card.STATUS_USE_ALLOCATIONED, c.getModifyIdentity());
//				if(i>0){
//					this.cacheFactory.getSubjectUserCache().userAllocationCard(companyId, c, userId);
//					this.createCardLog(companyId, cardId, userId, CardLog.ALLOCATION_TYPE_USER, operatorId, new Date());
//					c.setAllocationStatus(Card.STATUS_USE_ALLOCATIONED);
//					c.setUserId(userId);
//					this.allocationListenerService.after(c, true);
//					return true;
//				}
//			}
//			return false;
		//}		
	}
	


	

	

	

	
	private void createCardLog(int companyId, int cardId, String userId, int allocationType, String operatorId, Date time){
		CardLog log = new CardLog();
		log.setAllocationType(allocationType);
		log.setCompanyId(companyId);
		log.setCardId(cardId);
		log.setUserId(userId);
		log.setOperatorUserId(operatorId);
		log.setAllocationTime(time);
		this.cardLogService.save(log);
	}
	
	public List<SaleUser> getAllSaleUsers(int companyId){
		//synchronized(this){
			String time = formatter2.format(new Date());
			cacheFactory.checkInit(companyId, this, time);
			return this.cacheFactory.getSubjectUserCache().getAllSaleUsers(companyId);
		//}
	}
	
	public Map<String, String> getStatus(int companyId) throws UserMgrException, Exception{
		Map<String, String> map = new HashMap<String, String>();
		List<UserSession> sessions = CoreClient.getUserMgr(companyId).getCustomers(companyId);
		for(UserSession s : sessions){
			String status = "offline";
			if(s.getStatus() != UserSession.STATUS_OFFLINE){
				if(s.getRunningStatus() == 1 || (s.getRunningStatus() == 2 && s.isAutoBussy())){
					status = "online";
				}else if(s.getRunningStatus() == 2){
					status = "buzy";
				}else if(s.getRunningStatus() == 3){
					status = "leave";
				}
			}
			map.put(s.getUserId(), status);
		}
		return map;
	}
	
	public List<SaleUser> getCanAllocationSaleUser(int companyId, int subjectId, int schoolId){
		//synchronized(this){
			String time = formatter2.format(new Date());
			cacheFactory.checkInit(companyId, this, time);
			List<SaleUser> users = this.cacheFactory.getSubjectUserCache().getUsersOfSubjectId(companyId, subjectId, schoolId);
			_logger.info(String.format("公司[%s]-手动分配可用客服:初始分配客服[%s]", companyId, logUser(users)));
			//return users;
			/*List<SaleUser> list = new ArrayList<SaleUser>();
			try {
				List<UserSession> sessions = CoreClient.getUserMgr(companyId).getCustomers(companyId);
				Set<String> onlineIds = new HashSet<String>();
				for(UserSession s : sessions){
					if(s.getStatus() == UserSession.STATUS_ONLINE){
						onlineIds.add(s.getUserId());
					}
				}
				for(SaleUser user : users){
					if(onlineIds.contains(user.getUserId())){
						list.add(user);
					}
				}
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
			}
			return list;*/
			return this.filterOnLineSaleUsers(companyId, users);
		//}
	}
	public List<SaleUser> filterOnLineSaleUsers(int companyId, List<SaleUser> users){
		List<SaleUser> list = new ArrayList<SaleUser>();
		try {
			List<UserSession> sessions = CoreClient.getUserMgr(companyId).getCustomers(companyId);
			Set<String> onlineIds = new HashSet<String>();
			CardRule cardRule = this.cacheFactory.getCardRuleCache().getCardRule(companyId);

			for(UserSession s : sessions){
				
				// needOnLine必须在线才能分配 1开启 0未开启
				if (cardRule.getNeedOnLine() == 1) {
					
					// isOnlineAllocation在线分配模式 0 在线分配(只有在线的状态可以进行名片的分配) 1在线分配(在线.忙碌.离开的状态可以进行名片的分配)
					if (cardRule.getIsOnlineAllocation() == 0) {
						if (s.getStatus() == UserSession.STATUS_ONLINE && (s.getRunningStatus() == 1 || s.getRunningStatus() == 0)) {
							onlineIds.add(s.getUserId());
						}
					} else {
						if (s.getStatus() == UserSession.STATUS_ONLINE) {
							onlineIds.add(s.getUserId());
						}
					}
				} else {
					onlineIds.add(s.getUserId());
				}
			}
			
			for(SaleUser user : users){
				if(onlineIds.contains(user.getUserId())){
					//_logger.info("[" + user.getCompanyId() + "," + user.getUserId()+"]可以被分配");
					_logger.info(String.format("[%s][%s]可以被分配, 当前分配情况：权重[%s], 分配量[%s], 退回量[%s], 有效量[%s]", user.getCompanyId(),
							user.getUserId(),user.getAllocationWeight(), user.getAllocationCount(), user.getBackCount(), user.getValidCount()));
					list.add(user);
				}
			}
			_logger.info(String.format("公司[%s]-手动分配可用客服:最终可分配客服[%s]", companyId, logUser(list)));
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
		}
		return list;
	}
	
	private boolean autoAllocation(Card card){
		boolean allocationFlag = this.allocation(card);
		if(!allocationFlag){
			_logger.info("名片【"+card.getId()+"】未找到可分配的销售, 转人工分配");
			this.updateCard(card.getId(), "", Card.STATUS_WAIT_USE_ALLOCATION, card.getModifyIdentity());
		}
		return allocationFlag;
	}
	
	public boolean allocation(int cardId){
		Card card = this.getCard(cardId);
		boolean allocationFlag = false;
		if(card != null && card.getAllocationStatus() == Card.STATUS_WAIT_USE_ALLOCATION){
			allocationFlag = this.allocation(card);
		}
		return allocationFlag;
	} 
	
	/**
	 * 分配给创建者模式
	 * @param card
	 * @return
	 */
	private boolean allocationToCreator(Card card){
		int i = this.updateCard(card.getId(), card.getCreateUserId(), Card.STATUS_SYSTEM_ALLOCATIONED, card.getModifyIdentity());
		
		if(i > 0){
			card.setUserId(card.getCreateUserId());
			card.setAllocationStatus(Card.STATUS_SYSTEM_ALLOCATIONED);
			//this.cacheFactory.getSubjectUserCache().allocationCard(allocationUsers.get(0), card);
			this.createCardLog(card.getCompanyId(), card.getId(), card.getCreateUserId(), CardLog.ALLOCATION_TYPE_SYSTEM, SYSTEMID, new Date());
			_logger.info(String.format("[%s]分配名片[%s]给创建者%s",card.getCompanyId(), card.getId(), card.getCreateUserId()));
		}
		this.allocationListenerService.after(card, i>0);
		return i>0;
	}
	
	private String logUser(List<SaleUser> allocationUsers) {
		
		if(allocationUsers == null)
			return "[]";
		
		if(allocationUsers.size() < 1)
			return "[]";
		
		StringBuffer sb = new StringBuffer();
		for(SaleUser s : allocationUsers) {
			sb.append(s.getUserId());
			sb.append(",");
		}
		return sb.toString();
	}
	
	/**
	 * 选择可分配客服
	 * @param card
	 * @return
	 */
	@Transactional
	private boolean allocation(Card card){
		cacheFactory.getLockCache().getLock(card.getCompanyId()).lock();
		try{
			
			//取出与名片校区、项目一致的销售
			List<SaleUser> allocationUsers = cacheFactory.getSubjectUserCache().getUsersOfSubjectId(card.getCompanyId(), card.getSubjectId(), card.getSchooleId());
			boolean allocationFlag = false;
			if(allocationUsers != null && !allocationUsers.isEmpty()){
				
				_logger.info(String.format("公司[%s]-分配可用客服:初始分配客服[%s]", card.getCompanyId(), logUser(allocationUsers)));
				
				CardRule rule = cacheFactory.getCardRuleCache().getCardRule(card.getCompanyId());
				Date callbackTime = card.getCallbackTime();
				Date createTime = card.getCreateTime();
				
				//可分配客服集合
				List<SaleUser> saleUsersList = new ArrayList<SaleUser>();
				//获取当前在线客服集合
				Set<String> onlineIds = filtrationSaleUserService.getOnlieIds(rule.getCompanyId(), rule);
				
				for (SaleUser saleUser : allocationUsers) {
					//过滤不可分配客服
					boolean info = filtrationSaleUserService.filtration(rule, saleUser, callbackTime, createTime, onlineIds);
					if (info)
						saleUsersList.add(saleUser);
				}
				_logger.info(String.format("公司[%s]-分配可用客服:最终可分配客服[%s]", card.getCompanyId(), logUser(saleUsersList)));
				
				if(!saleUsersList.isEmpty()){
					
					//根据当前算法类型获取当前分配销售客服
					SaleUser saleUser = AllocationSaleUserFactory.getInstance(rule).allocationSaleUser(card, saleUsersList);

					//修改访客信息
					int i = this.updateCard(card.getId(), saleUser.getUserId(), Card.STATUS_SYSTEM_ALLOCATIONED, card.getModifyIdentity());
					
					if(i > 0){
						allocationFlag = true;
						//取可分配客服List<SaleUser>进行权重排序后第一位
						card.setUserId(saleUser.getUserId());
						card.setAllocationStatus(Card.STATUS_SYSTEM_ALLOCATIONED);
						this.cacheFactory.getSubjectUserCache().allocationCard(saleUser, card);
						this.createCardLog(card.getCompanyId(), card.getId(), saleUser.getUserId(), CardLog.ALLOCATION_TYPE_SYSTEM, SYSTEMID, new Date());
						
						//notifyWithPopMessage(card.getCompanyId(), allocationUsers.get(0).getUserId());
						// 将分配后的用户，调用800接口
						//sendDataService.action(card);
						
						// 发送微信通知
						//new WeixinCardExtendServiceImpl(card);
						//weixinService.action(card);
					}
					this.allocationListenerService.after(card, i>0);
					
				}
			}
			return allocationFlag;
		}finally{
			cacheFactory.getLockCache().getLock(card.getCompanyId()).unlock();
		}
	}
	
	
	/*private void notifyWithPopMessage(int companyId, String userId){
		this.notifyService.notifyAfterAllocation(companyId, userId, "您有一个名片等待处理");
	}*/
	
	/**
	 * 更新名片信息
	 * @param cardId
	 * @param userId
	 * @param status 人工分配3;系统分配1;高意向名片分配6
	 * @param identity
	 * @return
	 */
	private int updateCard(int cardId, String userId, int status, String identity){
		if(status == Card.STATUS_USE_ALLOCATIONED || status == Card.STATUS_SYSTEM_ALLOCATIONED || status == Card.STATUS_SALE_ALLOCATIONED){
			String sql = "update js_visitor_info set allocation_status = ?, user_id = ?, is_back = 0, is_expired = 0, modify_identity = ?, allocation_time = ? where id = ? and modify_identity= ? ";
			return this.jdbcTemplate.update(sql, status, userId, UUID.randomUUID().toString(), new Date(), cardId, identity);
		}else{
			String sql = "update js_visitor_info set allocation_status = ?, user_id = ?, is_back = 0, is_expired = 0, modify_identity = ? where id = ? and modify_identity= ? ";
			return this.jdbcTemplate.update(sql, status, userId, UUID.randomUUID().toString(), cardId, identity);
		}
	}
	
	private boolean exists(int companyId, String mobile, Date createTime){
		
		if(mobile == null || mobile.equals("")){
			return false;
		}else{
			String sql = "select count(*) as total from js_visitor_info where company_id=?  and mobile=? and create_time between ? and ? ";
			Calendar start = Calendar.getInstance();
			start.setTime(createTime);
			//start.add(Calendar.DAY_OF_YEAR, -1);
			// update by lcy at 2020-03-16 之前默认是三个小时
			CardRule cardRule = this.cacheFactory.getCardRuleCache().getCardRule(companyId);
			if(null!=cardRule && null!= cardRule.getNoDistributeTimeType() && null!= cardRule.getNoDistributeTime()){
				//默认是三小时之内的不再提醒
				int time = -3;
				if(cardRule.getNoDistributeTimeType() == NoDistributeTimeTypeEnum.HOUR.getType()){
					time = -cardRule.getNoDistributeTime();
				}else if (cardRule.getNoDistributeTimeType() == NoDistributeTimeTypeEnum.DAY.getType()){
					time = -cardRule.getNoDistributeTime()*24;
				}
				start.add(Calendar.HOUR_OF_DAY, time);
			} else {
				//如果没有配置，则还是默认3小时内
				start.add(Calendar.HOUR_OF_DAY, -3);
			}
//			start.add(Calendar.HOUR_OF_DAY, -3);
			Calendar end = Calendar.getInstance();
			end.setTime(createTime);
			end.add(Calendar.SECOND, -1);
			int count = this.jdbcTemplate.queryForObject(sql, new Object[]{companyId, mobile, start, end}, Integer.class);/*.query(sql, , new ResultSetExtractor<Integer>(){
	
				@Override
				public Integer extractData(ResultSet rs) throws SQLException,
						DataAccessException {
					return rs.getInt("total");//
				}
				
			});*/
			return count > 0 ? true : false;
		}
	}
	


	@Override
	public CardRule getCardRule(int companyId) {
		return this.cardRuleService.get(companyId);
	}
	
	private Map<String, Integer> getSaleUserBack(int companyId, String time) throws DataAccessException, ParseException{
		String sql = "select user_id, count(*) as total from js_cuour_card_log " +
						"where company_id = ? and allocation_type = ? "+
						"		and allocation_time between ? and ? group by user_id";
		final Map<String, Integer> map = new HashMap<String, Integer>();
		this.jdbcTemplate.query(sql, 
				new Object[]{companyId, CardLog.ALLOCATION_TYPE_BACK, formatter3.parse(time+" 00:00:00"), formatter3.parse(time+" 23:59:59")}, 
				new RowCallbackHandler(){
					@Override
					public void processRow(ResultSet rs) throws SQLException {
						String userId = rs.getString("user_id");
						int total = rs.getInt("total");
						map.put(userId, total);
					}
		});
		return map;
	}
	
	private Map<String, Integer> getSaleUserActualAllocation(int companyId, String time) throws DataAccessException, ParseException{
		String sql = "select user_id, count(*) as total from js_cuour_card_log " +
						"where company_id = ? and (allocation_type = ? or allocation_type = ?) " +
						"		and allocation_time between ? and ? group by user_id";
		final Map<String, Integer> map = new HashMap<String, Integer>();
		this.jdbcTemplate.query(sql, 
				new Object[]{companyId, CardLog.ALLOCATION_TYPE_SYSTEM, CardLog.ALLOCATION_TYPE_USER, formatter3.parse(time+" 00:00:00"), formatter3.parse(time+" 23:59:59")}, 
				new RowCallbackHandler(){
					@Override
					public void processRow(ResultSet rs) throws SQLException {
						String userId = rs.getString("user_id");
						int total = rs.getInt("total");
						map.put(userId, total);
					}
		});
		return map;
	}
	
	public List<SaleUser> getSaleUser(int companyId, Date startTime, Date endTime){
		String sql = "select a.user_id, a.company_id, a.school_id, a.subject_id, a.business_group_id, a.sales_type_id, a.max_card_size," +
						   " i.real_name, b.name as school_name, c.name as subject_name, "+
					       " d.name as business_group_name, e.name as sales_type_name, e.weight as allocation_weight, " +
					       " nvl(h.total, 0) as total, nvl(h.back, 0) as back, nvl(h.finished, 0) as finished, "+
					       " nvl(h.expired, 0) as expired, nvl(h.saleallocation, 0) as saleallocation, nvl(h.salefinished, 0) as salefinished from js_cuour_sales a "+
					"inner join js_cuour_school b on a.school_id=b.id "+
					"inner join js_cuour_subject c on a.subject_id=c.id "+
					"inner join js_cuour_business_group d on a.business_group_id=d.id "+
					"inner join js_cuour_sale_type e on a.sales_type_id=e.id "+
					"left join ( "+
				    	"select g.user_id, sum(decode(allocation_type, 1, 1, 0)) + sum(decode(allocation_type, 2, 1, 0)) as total, "+
				             "sum(decode(allocation_type, 3, 1, 0)) as back, sum(decode(allocation_type, 4, 1, 0)) as finished, sum(decode(allocation_type, 5, 1, 0)) as expired, "+
				             "sum(decode(allocation_type, 6, 1, 0)) as saleallocation, sum(decode(allocation_type, 7, 1, 0)) as salefinished "+
				             "from js_cuour_card_log g "+
				             //"inner join js_visitor_info f on f.id = g.card_id and f.company_id = g.company_id "+
				             "where g.company_id = ? and (g.allocation_time between ? and ?) "+
				             "group by g.user_id "+
				    ") h on h.user_id = a.user_id "+
				    "inner join js_user i on i.user_id=a.user_id "+
					"where a.company_id = ?";
		long _t1 = System.currentTimeMillis();
		List<SaleUser> saleUsers =  this.jdbcTemplate.query(sql, new Object[]{
					companyId, startTime, endTime, companyId}, new RowMapper<SaleUser>(){
			
				@Override
				public SaleUser mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					SaleUser s = new SaleUser();
					s.setUserId(rs.getString("user_id"));
					s.setRealName(rs.getString("real_name"));
					s.setCompanyId(rs.getInt("company_id"));
					s.setSchoolId(rs.getInt("school_id"));
					s.setSchoolName(rs.getString("school_name"));
					s.setSubjectId(rs.getInt("subject_id"));
					s.setSubjectName(rs.getString("subject_name"));
					s.setBusinessGroupId(rs.getInt("business_group_id"));
					s.setBusinessGroupName(rs.getString("business_group_name"));
					s.setSalesTypeId(rs.getInt("sales_type_id"));
					s.setMaxCardSize(rs.getInt("max_card_size"));
					s.setSalesTypeName(rs.getString("sales_type_name"));
					s.setAllocationWeight(rs.getInt("allocation_weight"));
					s.setAllocationCount(rs.getInt("total"));
					s.setActualAllocationCount(s.getAllocationCount());
					s.setBackCount(rs.getInt("back"));
					s.setFinishedCount(rs.getInt("finished"));
					s.setExpiredCount(rs.getInt("expired"));
					s.setValidCount(s.getAllocationCount() - s.getBackCount());
					s.setActualValidCount(s.getValidCount());
					s.setSaleAllocationCount(rs.getInt("saleallocation"));
					s.setSaleFinishedCount(rs.getInt("salefinished"));
					return s;
				}
				
			});
			
		long _t2 = System.currentTimeMillis();
		_logger.info("SQLQuery-getSaleUser[startTime:"+formatter3.format(startTime)+" endTime"+formatter3.format(endTime)+" companyId:"+companyId+"]["+sql+"] : "+(_t2-_t1)+"ms");
		for(SaleUser s : saleUsers){
			//load wechat notify config
			try {
				User user = CoreClient.getUserMgr(s.getCompanyId()).getUser(s.getUserId());
				if(user != null) {
					String notifyOpenId = user.getExtendConfigProperty("notifyOpenId");
					String notifyUserNickName = user.getExtendConfigProperty("notifyUserNickName");
					String notifyIsOpen = user.getExtendConfigProperty("notifyIsOpen");
					
					
//						_logger.info("user wx push config userId=" +s.getUserId() + ",status=" + notifyIsOpen + ",openId=" + notifyOpenId );
					
					s.setWeixinPushStatus("true".equals(notifyIsOpen));
					s.setUserWeiXinOpenId(notifyOpenId);
				}else{
					_logger.info(s.getUserId()+"------------"+user);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				_logger.error(e.getMessage(), e);
			}
			
			//end
		}
		long _t3 = System.currentTimeMillis();
		_logger.info("CoreClient-getSaleUser : "+(_t3-_t2)+"ms");
		return saleUsers;
	}

	@Override
	public List<SaleUser> getSaleUser(int companyId, String time ,Boolean isUserReset) {
		try {
			CardRule cr = this.cacheFactory.getCardRuleCache().getCardRule(companyId);
			if(cr != null && cr.getResetTime() != null && !cr.getResetTime().equals("")){
				
				Date now = new Date();
				Date resetTime = formatter3.parse(time+" "+cr.getResetTime()+":00");
				if(now.after(resetTime)){
					List<SaleUser> list =  this.getSaleUser(companyId,isUserReset? now:resetTime, formatter3.parse(time+" 23:59:59"));
					Map<String, Integer> map = this.getSaleUserActualAllocation(companyId, time);
					Map<String, Integer> validMap = this.getSaleUserBack(companyId, time);
					for(SaleUser u : list){
						Integer total = map.get(u.getUserId());
						if(total != null){
							u.setActualAllocationCount(total);
							u.setActualValidCount(total - u.getBackCount());
							Integer back = validMap.get(u.getUserId());
							if(back != null){
								u.setActualValidCount(total - back);
							}
						}
						
					}
					return list;
					
				}
				
			}
			return this.getSaleUser(companyId, formatter3.parse(time+" 00:00:00"), formatter3.parse(time+" 23:59:59"));
			
		} catch (ParseException e) {
			_logger.error(e.getMessage(), e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ArrayList<SaleUser>();
	}
	
	@Override
	public List<SchedulingTime> getSchedulingTimes(int companyId, String time) {
		String sql = "select a.company_id, a.user_id, to_date(a.scheduling_time|| b.start_time, 'yyyymmddhh24:mi:ss') as start_time, "+
						 "to_date(a.scheduling_time|| b.end_time, 'yyyymmddhh24:mi:ss') as end_time "+
					 "from js_scheduling_user a "+
					 "inner join js_scheduling b on a.scheduling_id = b.id and a.company_id = b.company_id "+
					 "where a.company_id=? and scheduling_type=1 and a.scheduling_time=?";
		return this.jdbcTemplate.query(sql, new Object[]{companyId, time}, new RowMapper<SchedulingTime>(){

			@Override
			public SchedulingTime mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				SchedulingTime st = new SchedulingTime();
				st.setCompanyId(rs.getInt("company_id"));
				st.setUserId(rs.getString("user_id"));
				st.setStartTime(new Date(rs.getTimestamp("start_time").getTime()));
				st.setEndTime(new Date(rs.getTimestamp("end_time").getTime()));
				return st;
			}
			
		});
	}
	
	public static void main(String[] args){
		//String application = "classpath*:cuour-application.xml";
		//new ClassPathXmlApplicationContext(application);
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//注意月份是MM
        Date createTime = new Date();
		try {
			//2020-02-19 23:37:46
			//2020-02-19 22:27:57
			//2020-02-19 19:04:30
			createTime = simpleDateFormat.parse("2020-02-19 23:37:46");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

			Calendar start = Calendar.getInstance();
			start.setTime(createTime);
			//start.add(Calendar.DAY_OF_YEAR, -1);
			start.add(Calendar.HOUR_OF_DAY, -3);
			Calendar end = Calendar.getInstance();
			end.setTime(createTime);
			end.add(Calendar.SECOND, -1);
			
		System.out.println(start.getTime());
		System.out.println(end.getTime());
		
		
	}

	/*@Override
	public List<Card> getAllocationedCards(int companyId, String time) {
		String sql = "select a.* from js_visitor_info a " +
						" where a.company_id = ? and nvl2(ext_column8, 0, 1)=0 and nvl2(ext_column9, 0, 1)=0 and nvl2(ext_column10, 0, 1)=0 "+
						" and to_char(a.allocation_time,'yyyymmdd') = ? "+
						" and (allocation_status =  "+ Card.STATUS_SYSTEM_ALLOCATIONED
							+" or  allocation_status = " + Card.STATUS_USE_ALLOCATIONED 
							+" or  allocation_status = " + Card.STATUS_SALE_ALLOCATIONED 
							+" or allocation_status = "+Card.STATUS_FINISHED+")" +
						" order by a.company_id, a.create_time";
		return this.jdbcTemplate.query(sql, new Object[]{companyId, time}, new CardRowMapper());
	}*/
	
	final class CardRowMapper implements RowMapper<Card>{

		@Override
		public Card mapRow(ResultSet rs, int rowNum) throws SQLException {
			Card card = new Card();
			card.setId(rs.getInt("id"));
			card.setCompanyId(rs.getInt("company_id"));
			card.setName(rs.getString("name"));
			try {
				String subjectId = rs.getString("ext_column8");
				if(subjectId != null && NumberUtils.isNumber(subjectId)){
					card.setSubjectId(Integer.parseInt(subjectId));
				}
				String schoolId = rs.getString("ext_column9");
				if(schoolId != null && NumberUtils.isNumber(schoolId)){
					card.setSchooleId(Integer.parseInt(schoolId));
				}
				String callbackTime = rs.getString("ext_column10");
				if(callbackTime != null && !callbackTime.equals("")){
					card.setCallbackTime(formatter.parse(rs.getString("ext_column10")));
				}
			} catch (Exception e) {
				//_logger.error("名片错误的数据格式["+card.getId()+"]:"+e.getMessage(), e);
			}
			card.setAllocationTime(rs.getTimestamp("allocation_time"));
			card.setIsValid(rs.getInt("is_valid"));
			card.setIsBack(rs.getInt("is_back"));
			card.setAllocationStatus(rs.getInt("allocation_status"));
			card.setModifyIdentity(rs.getString("modify_identity"));
			card.setUserId(rs.getString("user_id"));
			if(card.getAllocationStatus() == Card.STATUS_FINISHED){
				card.setFinished(1);
			}
			card.setMobile(rs.getString("mobile"));
			Date createTime = rs.getTimestamp("create_time");
			card.setCreateTime(createTime == null ? new Date() :createTime);
			
			card.setCreateUserId(rs.getString("create_user_id"));
			
			card.setSaleId(rs.getString("ext_column6"));
			
			if(card.getCallbackTime() == null){
				card.setCallbackTime(card.getCreateTime());
			}
			card.setQq(rs.getString("qq"));
			card.setMsn(rs.getString("msn"));
			card.setChatUrl(rs.getString("chat_url"));
			card.setFirstUrl(rs.getString("first_url"));
			card.setReferUrl(rs.getString("refer"));
			return card;
		}
	}

	@Override
	public void onApplicationEvent(SettingChangeEvent event) {
		synchronized(this){
			_logger.info(String.format("公司【%s】配置发生改变", event.getCompanyId()));
			this.cacheFactory.remove(event.getCompanyId());
            distributionCardService.removeLocalCacheByCompanyId(event.getCompanyId());
            pushdataService.removeLocalCacheByCompanyId(event.getCompanyId());
		}
	}
	
	public void clearCache(int companyId,String userId){
		//synchronized(this){
        String time = formatter2.format(new Date());
        _logger.info("公司id为："+ companyId +", userId为：  "+userId +" 时间为："+new Date()+",开始清理分配名片缓存！");
        cacheFactory.checkInit(companyId, this, time,true);
        distributionCardService.clearCache(companyId,userId);
        pushdataService.clearCache(companyId,userId);

		//}
	}
	
	/**
	 * 清除轮循算法缓存
	 * @param companyId
	 * @param userId
	 */
	public void clearAlternateCache(int companyId,String userId){
		CardRule cardRule = this.cardRuleService.get(companyId);
		String redisKey = RKP + "_" + companyId + "_" + cardRule.getDefaultSubjectId() + "_" + cardRule.getDefaultSchoolId() + "_allot";
		ServiceFactory.getMessageCache().getRedisService().remove(redisKey);
		
		List<Subject> subjectList = this.jdbcTemplate.query("select * from js_cuour_subject where company_id = ?", new Object[]{companyId}, new SubjectRowMapper());
		List<School> schoolList = this.jdbcTemplate.query("select * from js_cuour_school where company_id = ?", new Object[]{companyId}, new SchoolRowMapper());
		
		for(Subject subject : subjectList) {
			for(School school : schoolList) {
				redisKey = RKP + "_" + companyId + "_" + subject.getId() + "_" + school.getId() + "_allot";
				ServiceFactory.getMessageCache().getRedisService().remove(redisKey);
			}
		}
	}
	
	class SubjectRowMapper implements RowMapper<Subject>{
		@Override
		public Subject mapRow(ResultSet rs, int rowNum) throws SQLException {
			Subject s = new Subject();
			s.setId(rs.getInt("id"));
			s.setCompanyId(rs.getInt("company_id"));
			s.setDesp(rs.getString("desp"));
			s.setName(rs.getString("name"));
			return s;
		}
	}
	
	class SchoolRowMapper implements RowMapper<School>{
		@Override
		public School mapRow(ResultSet rs, int rowNum) throws SQLException {
			School s = new School();
			s.setId(rs.getInt("id"));
			s.setCompanyId(rs.getInt("company_id"));
			s.setDesp(rs.getString("desp"));
			s.setName(rs.getString("name"));
			return s;
		}
	}
    /**
     * 新版的筛选分配客服方法，改进的地方是降最耗时的CoreClient.getUserMgr 由两个变为1个
     * @param companyId
     * @param subjectId
     * @param schoolId
     * @return
     */
    public Map<String,Object> getCanAllocationSaleUserAndStatus(int companyId, int subjectId, int schoolId,List<SaleUser> saleUserList,Map<String, String> statusMap){
        Map<String,Object> resultMap = Maps.newHashMap();

        try{
            List<UserSession> sessions = CoreClient.getUserMgr(companyId).getCustomers(companyId);

            saleUserList.addAll(getCanAllocationSaleUserBySessions(companyId, subjectId, schoolId, sessions));

            statusMap.putAll(getStatusBySession(sessions));


        }catch(Exception e){
            _logger.error(e.getMessage(), e);
        }

        return resultMap;
    }
    public List<SaleUser> getCanAllocationSaleUserBySessions(int companyId, int subjectId, int schoolId,List<UserSession> sessions){
        //synchronized(this){
        String time = formatter2.format(new Date());
        cacheFactory.checkInit(companyId, this, time);
        List<SaleUser> users = this.cacheFactory.getSubjectUserCache().getUsersOfSubjectId(companyId, subjectId, schoolId);
        _logger.info(String.format("公司[%s]-手动分配可用客服:初始分配客服[%s]", companyId, logUser(users)));
        return this.filterOnLineSaleUsersBySessions(companyId, users,sessions);
    }

    public List<SaleUser> filterOnLineSaleUsersBySessions(int companyId, List<SaleUser> users,List<UserSession> sessions){
        List<SaleUser> list = Lists.newArrayList();
        try {
            Set<String> onlineIds = Sets.newHashSet();
            CardRule cardRule = this.cacheFactory.getCardRuleCache().getCardRule(companyId);

            for(UserSession s : sessions){
                // needOnLine必须在线才能分配 1开启 0未开启
                if (cardRule.getNeedOnLine() == 1) {

                    // isOnlineAllocation在线分配模式 0 在线分配(只有在线的状态可以进行名片的分配) 1在线分配(在线.忙碌.离开的状态可以进行名片的分配)
                    if (cardRule.getIsOnlineAllocation() == 0) {
                        if (s.getStatus() == UserSession.STATUS_ONLINE && (s.getRunningStatus() == 1 || s.getRunningStatus() == 0)) {
                            onlineIds.add(s.getUserId());
                        }
                    } else {
                        if (s.getStatus() == UserSession.STATUS_ONLINE) {
                            onlineIds.add(s.getUserId());
                        }
                    }
                } else {
                    onlineIds.add(s.getUserId());
                }
            }

            for(SaleUser user : users){
                if(onlineIds.contains(user.getUserId())){
                    //_logger.info("[" + user.getCompanyId() + "," + user.getUserId()+"]可以被分配");
                    _logger.info(String.format("[%s][%s]可以被分配, 当前分配情况：权重[%s], 分配量[%s], 退回量[%s], 有效量[%s]", user.getCompanyId(),
                            user.getUserId(),user.getAllocationWeight(), user.getAllocationCount(), user.getBackCount(), user.getValidCount()));
                    list.add(user);
                }
            }
            _logger.info(String.format("公司[%s]-手动分配可用客服:最终可分配客服[%s]", companyId, logUser(list)));
        } catch (Exception e) {
            _logger.error(e.getMessage(), e);
        }
        return list;
    }

    /**
     *
     * @param sessions
     * @return
     * @throws UserMgrException
     * @throws Exception
     */
    public Map<String, String> getStatusBySession(List<UserSession> sessions) throws UserMgrException, Exception{
        Map<String, String> map = Maps.newHashMap();
        if(CollectionUtils.isEmpty(sessions)){
            return map;
        }
        for(UserSession s : sessions){
            String status = "offline";
            if(s.getStatus() != UserSession.STATUS_OFFLINE){
                if(s.getRunningStatus() == 1 || (s.getRunningStatus() == 2 && s.isAutoBussy())){
                    status = "online";
                }else if(s.getRunningStatus() == 2){
                    status = "buzy";
                }else if(s.getRunningStatus() == 3){
                    status = "leave";
                }
            }
            map.put(s.getUserId(), status);
        }
        return map;
    }
}

