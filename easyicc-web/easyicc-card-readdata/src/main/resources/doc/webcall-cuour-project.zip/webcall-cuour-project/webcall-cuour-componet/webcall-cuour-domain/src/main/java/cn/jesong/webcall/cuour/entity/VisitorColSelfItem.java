package cn.jesong.webcall.cuour.entity;

public class VisitorColSelfItem {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private int selfId;
    private String itemName;

    public VisitorColSelfItem() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getSelfId() {
        return this.selfId;
    }

    public void setSelfId(int selfId) {
        this.selfId = selfId;
    }

    public String getItemName() {
        return this.itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
}
