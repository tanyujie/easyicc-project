package cn.jesong.webcall.cuour.secret;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.Response;

import cn.jesong.webcall.cuour.entity.ActionConfig;
import cn.jesong.webcall.cuour.util.CardUtil;
import cn.jesong.webcall.cuour.util.KeyUtil;

/**
 * 获取tq token实现
 * @author zhanglu
 *
 */
public class CardTQImpl implements CardAuxiliaryInterface {

	private final static Log _logger = LogFactory.getLog(CardTQImpl.class);

	@Override
	public String generatorKeyStr(ActionConfig config) throws Exception{
		String keyStr = null;
		if (config != null && config.getConfig() != null && config.getConfig().trim().length() > 0) {

			String configStr = config.getConfig();

			//管理员数据账号 adminUin=8008115
			//密钥 appSecret=kuakao2019
			//获取token getTokenUrl=http://kkvip.kuakao.com/webservice/getAccessToken
			String adminUin = CardUtil.getValue(configStr, "adminUin");
			String appSecret = CardUtil.getValue(configStr, "appSecret");
			String getTokenUrl = CardUtil.getValue(configStr, "getTokenUrl");

			if (StringUtils.isEmpty(adminUin) || StringUtils.isEmpty(appSecret)) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "]未配置ActionConfig信息!");
				return null;
			}

			long ctime = System.currentTimeMillis() / 1000;
			String sign = KeyUtil.encryption(adminUin + "$" + appSecret + "$" + ctime);
			sign = sign.toUpperCase();
			String url = getTokenUrl + "?admin_uin=" + adminUin + "&ctime=" + ctime + "&sign=" + sign;
			
			JSONObject s = new JSONObject();
			s.put("admin_uin", adminUin);
			s.put("ctime", ctime);
			s.put("sign", sign);
			
			_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "请求Token:" + url);

			//String info = HttpClientUtil.httpPost(getTokenUrl, JSON.toJSONString(s), "UTF-8");
			//String info = HttpClientUtil.httpPost(url, JSON.toJSONString(s), null, "application/x-www-form-urlencoded;charset=utf-8");
			String info = post(url, null, null, "application/x-www-form-urlencoded");
			if (StringUtils.isEmpty(info)) {
				_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "请求密钥失败!");
				return null;
			}

			JSONObject tq = JSON.parseObject(info);
			if (tq.containsKey("access_token"))
				keyStr = tq.getString("access_token").replace(" ", "");

			_logger.info("----------------------------->公司Id为[" + config.getCompanyId() + "请求密钥结果：" + info);
		}
		return keyStr;
	}

	/**
	 * 发送请求
	 * @param url
	 * @param s
	 * @param accessToken
	 * @param contentType
	 * @return
	 * @throws IOException
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	private static String post(String url, String s, String accessToken, String contentType) throws Exception{
		AsyncHttpClient http = new AsyncHttpClient();
		AsyncHttpClient.BoundRequestBuilder builder = http.preparePost(url);

		if (StringUtils.isNotEmpty(accessToken))
			builder.addHeader("Authorization", accessToken);

		builder.setBodyEncoding("UTF-8");

		if (StringUtils.isNotEmpty(s))
			builder.setBody(s);

		if (StringUtils.isNotEmpty(contentType))
			builder.setHeader("contentType", contentType);

		Future<Response> f;
		String body = "";
		f = builder.execute();
		body = f.get().getResponseBody("UTF-8");
		http.close();
		return body;
	}

}
