package cn.jesong.webcall.cuour.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.jesong.webcall.cuour.entity.Card;
import cn.jesong.webcall.cuour.service.NotifyService;

@Component
public class AllocationNotifyListener implements AllocationListener{
	
	@Autowired
	private NotifyService notifyService;

	@Override
	public void before(Card card) {
	}

	@Override
	public void after(Card card, boolean allocation) {
		if(allocation){
			this.notifyService.notifyAfterAllocation(card.getCompanyId(), card.getUserId(), "您有一个名片等待处理");
		}
	}

}
