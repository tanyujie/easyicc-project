package cn.jesong.webcall.cuour.entity;

import java.util.List;

/**
 * 新东方推送数据
 * @author zl
 *
 */
public class XdfBean {
	
	//appId	是	string	应用ID（参考上面API接口规范文档）
	private String appId;
	//method	是	string	调用方法（crmDataServiceImpl.saveBigMarketResourceTo91）
	private String method;
	//timestamp	是	string	调用时间戳，Epoch格式，系统接受的时间差不超过10分钟（如：2017-12-27 11:18:21）
	private String timestamp;
	//sign	是	string	签名（具体签名规则，参考上面API接口规范文档）
	private String sign;
	//recourceList	是	List	资源数据集合
	private List<XdfRecourceBean> recourceList;
	
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public List<XdfRecourceBean> getRecourceList() {
		return recourceList;
	}
	public void setRecourceList(List<XdfRecourceBean> recourceList) {
		this.recourceList = recourceList;
	}
	
	
	
	
	
}
